package TP1;

public class Instance {
	int[] timeTraitement;
	int[] weight;
	int[] date;
	
	public Instance(int[] tt,int[] w,int[] d){
		timeTraitement= tt;
		weight= w;
		date= d;
	}
	
	
	public Instance transfo (int[] ordre){
		int[] time = new int[timeTraitement.length];
		int[] weght = new int[weight.length];
		int[] dat = new int[date.length];
		int cpt =0;
		
		for (int a : ordre){
			
			time[cpt]= timeTraitement[a];
			weght[cpt]= weight[a];
			dat[cpt]= date[a];
			
			cpt++;
		}
		
		return new Instance(time,weght,dat);
	}
	
	
	public int[] getTimeTraitement(){
			return timeTraitement;
	}
	
	public int[] getWeight(){
		return weight;
	}
	
	public int[] getDate(){
		return date;
			
	}

}
