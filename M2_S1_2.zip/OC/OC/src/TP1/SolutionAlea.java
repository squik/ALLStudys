package TP1;

import java.util.ArrayList;

public class SolutionAlea {
	
	
	public static int[] solution(Instance i){
		ArrayList<Integer> res = new ArrayList<Integer>() ;
		int[] resultat = new int[i.date.length];
		int cpt =0;
		for (int nb=0 ;nb<i.date.length;nb++){
			res.add(nb);
		}
		
		while(!res.isEmpty()){
			int rand = (int) (Math.random() * res.size());
			
			int choix = res.get(rand);
			
			resultat[cpt]=choix;
			res.remove(rand);
			cpt++;
		}
		

		return resultat;
		
	}

}
