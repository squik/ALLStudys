package TP1;

public class F {
	
	public static int fSomme (Instance instance){
		int temps = 0 ;
		int res = 0;
		
		for (int i =0 ;i<instance.date.length;i++){
			temps+= instance.timeTraitement[i];
			res+= instance.weight[i] * Math.max(temps-instance.date[i], 0);
		}		
		return res;		
	}
	
	public static int fSomme (Instance instance,int[] ordre){
		int temps = 0 ;
		int res = 0;
		
		for (int i : ordre){
			temps+= instance.timeTraitement[i];
			res+= instance.weight[i] * Math.max(temps-instance.date[i], 0);
		}		
		return res;		
	}
	

}
