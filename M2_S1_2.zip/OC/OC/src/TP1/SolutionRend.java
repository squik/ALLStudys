package TP1;

import java.util.ArrayList;

public class SolutionRend {

	public static int[] solution(Instance i){
		
		ArrayList<Integer> res = new ArrayList<Integer>() ;
		int temps =0;
		int[] resultat = new int[i.date.length];
		int elementPris =0;
		for (int nb=0 ;nb<i.date.length;nb++){
			res.add(nb);
		}
		
		while(!res.isEmpty()){
			
			ArrayList<Integer> listMin = new ArrayList<Integer>();
			int max =-1;
			
			for (int cpt =0 ; cpt < res.size();cpt++){
			
				if (max ==-1){
					max =i.weight[cpt] * Math.max(temps-i.date[cpt], 0);
					listMin.add(res.get(cpt));
				}else{
					
					if (max ==i.weight[cpt] * Math.max(temps-i.date[cpt], 0) ){
						listMin.add(res.get(cpt));
					}
					if ( max < i.weight[cpt] * Math.max(temps-i.date[cpt], 0)){
						listMin = new ArrayList<Integer>();
						max = i.date[res.get(cpt)];
						listMin.add(res.get(cpt));
					}
				
				}
			
			}
			
			
			while(!listMin.isEmpty()){
				
				
				int choix =  (int) (Math.random() * listMin.size());
				int element = listMin.get(choix);
				resultat[elementPris]=element;
				
				
				temps += i.timeTraitement[element] ;
				
				
				listMin = new ArrayList<Integer>();
				listMin.add(element);
				
				res.removeAll(listMin);
				listMin = new ArrayList<Integer>();			
				
				
				elementPris++;
			}
		}
		
		
		return resultat;
		
	}
	
	
}
