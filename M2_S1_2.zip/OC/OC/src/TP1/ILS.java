package TP1;

import java.io.IOException;

public class ILS {
	
	
	public static Instance ILS(int nbInstance,int kopt) throws IOException{
		
		Instance i = SearchInstance.search(nbInstance,100);
		
		
		i= i.transfo(SolutionAlea.solution(i));
		
		
		int[] voi2 = {2,0,1};
		
		
		i = i.transfo(VND.VND(false, -1, -1, 0, voi2, 2, i));

		int cptAction = 0;
		
		Instance ibis = null;
		
		while(cptAction < 20){
			System.out.println(cptAction);
			
			
			ibis = Perturbation(i,kopt);
			ibis = ibis.transfo(VND.VND(false, -1, -1, 0, voi2, 2, ibis));		
			i = Accepter(i,ibis);	
			
			++cptAction;
		}
		
		return i;
	}
	
	
	public static Instance Perturbation(Instance i,int k){
		
		int[] ordre = new int[i.date.length];
		
		
		
		for (int nb=0 ;nb<i.date.length;nb++){
			ordre[nb]=nb;
		}
		
		if (k <2) return i.transfo(ordre);
		
		int nb1 = (int) (Math.random() * ordre.length);
		int nb2 = (int) (Math.random() * ordre.length);
		
		while (k > 1){
			
			
			if(nb1<nb2){
				ordre = HillClimbing.echange(ordre, nb1, nb2);
			}else {
				ordre = HillClimbing.echange(ordre, nb2, nb1);
			}
			
			nb1 = nb2;
			nb2 = (int) (Math.random() * ordre.length);
			k--;
			
		}
		

		
		
		return i.transfo(ordre);
	}
	
	public static Instance Accepter(Instance i1,Instance i2){
		
		if(F.fSomme(i1) > F.fSomme(i2)){
			return i1;
		}
		
		return i2;
	}
	

}
