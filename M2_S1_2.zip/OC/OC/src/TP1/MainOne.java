package TP1;

import java.io.IOException;
import java.util.ArrayList;

public class MainOne {

	
	public static void main(String[] args) throws IOException {
		
		
		Instance i = SearchInstance.search(24,100);
		Instance i2 = SearchInstance.search(1000,"22");
		int[] ordreAlea = SolutionAlea.solution(i);
		int[] ordreEDD = SolutionEDD.solution(i);
		int[] ordreMDD =SolutionMDD.solution(i);
		int[] ordreRend =SolutionRend.solution(i);
		System.out.println(" sans traitement => "+F.fSomme(i));
		System.out.println(" alea => "+F.fSomme(i,ordreAlea));

		System.out.println(" EDD  => "+F.fSomme(i,ordreEDD));
		
		System.out.println(" MDD  => "+F.fSomme(i,ordreMDD));
	
		System.out.println(" Rend  => "+F.fSomme(i,ordreRend));
	
		
		System.out.print("\n\n TS \n");
		
		
		
		Instance i5 = SearchInstance.search(24,100);
		System.out.println(i5);
		
		ArrayList<int[]> tabou = new ArrayList<int[]>();
		ArrayList<Integer> deb = new ArrayList<Integer>();
		ArrayList<Integer> fin = new ArrayList<Integer>();
		
		long debut = System.currentTimeMillis();			
		Instance ordreTS = TS.TS(24, 0,tabou,deb,fin);			
		long diff = System.currentTimeMillis()-debut;
		
		System.out.print("TIME : ");
		System.out.println(diff);
		
		System.out.print("=> : ");
		System.out.println(F.fSomme(ordreTS));
		System.out.print("deviation : ");
		System.out.println(100*(float) (F.fSomme(ordreTS)-744287)/744287);

		
		
		
		System.out.println("FIN");
		
	}
	
}
