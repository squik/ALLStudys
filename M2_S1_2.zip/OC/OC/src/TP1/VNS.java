package TP1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class VNS {
	
	
	public static Instance VNS(int nbInstance,int[] kvoisin) throws IOException{
		
		Instance i = SearchInstance.search(nbInstance,100);
		
		int[] ordre = SolutionEDD.solution(i);
		i= i.transfo(ordre);
		
		ArrayList<ArrayList<int[]>> voisin = VND.voisin(ordre, kvoisin);
		
		
		
		int cptAction = 0;
		int k = 1;
		
		Instance ibis = SearchInstance.search(nbInstance,100);
		
		while(cptAction < 20){
			System.out.println(cptAction);
			
			if(k > kvoisin.length-1){
				k=1;
			}
			
			ordre = solutionRand(voisin,k);
			ibis = ibis.transfo(ordre);
			
			ibis = ibis.transfo(VND.VND(false, -1, -1, 0, kvoisin, 2, ibis));		
			if(F.fSomme(i)>F.fSomme(ibis)){
				i=ibis;
				voisin = VND.voisin(ordre, kvoisin);
				k=1;
			}else{
				++k;
			}
			
			++cptAction;
		}
		
		return i;
		
	}
	
	public static int[] solutionRand(ArrayList<ArrayList<int[]>> voisin ,int k){
		
		if (k > voisin.size()-1){
			return null;
		}
		ArrayList<int[]> ordreChoix = voisin.get(k);
		Collections.shuffle(voisin);
		
		return ordreChoix.get(0);
		
	}
	
	

}
