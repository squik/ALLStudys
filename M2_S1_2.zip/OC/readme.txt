
HILL CLIMBING


ss 0 => 

ss 1 => 

v 0 => 

v 1 => 

v 2 => 

s 0 =>

s 1 =>

s 2 => 

ordre d'aparition  (0 -> 17 *2 colonne)

 ss	v	s
 0	0	0
 0	0	1
 0	0	2
 0	1	0
 0	1	1
 0	1	2
 0	2	0
 0	2	1
 0	2	2
 1	0	0
 1	0	1
 1	0	2
 1	1	0
 1	1	1
 1	1	2
 1	2	0
 1	2	1
 1	2	2
