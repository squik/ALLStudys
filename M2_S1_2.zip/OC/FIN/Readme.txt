Guillaume Maitrot


Le main est dans OC/src/TP1 il s'appelle BigMain.java (permet de crée tous les textes de données)

Remplacé dans BigMain.java 

"C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\wtbest100b.txt");

et 

"C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\instances\\optimal_results.txt"

	Par vous chemins

Remplacé dans SearchInstance.java 

"C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\wt100.txt"

et
 
"C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\instances\\wt_1000_"+nom+".txt"

	Par vos chemins

Les gnuplot sont dans le dossier Graph

Les donnés sont structurés selon les schémas suivants:


	BASIQUE :

		- Les fichiers avec rien entre resultat et little et Big (little/Big sont les instances)

			- 1ere colonne le numéro de l'instance
			- 2eme colonne le temps d'éxecution en Ms 

		- Les autres fichiers (MDD/EDD/Alea sont les noms des solutions et little/Big sont les instances)

			- 1eme colonee le numero d'instance 
			- 2eme colonne le cout 
			- 3eme colonne la deviance
			- 4eme colonne le temps d'execution Millis

	HillClimbing :

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis

		-Dans le nom

			-little/Big sont les instances
			-alea/EDD/MDD le mode de la solution de depart
			-insert/swap/echange le choix du voisinage
			-First/Best la stratégie de séléction

	ILS :

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis
			4eme colonne le nombre d'execution

		-Dans le nom

			-quand le nombre est un float ,le seuil est active on s'arrete que si on ne diminue plus en dessous d'un certain % (1.1 équivaut à être inferieur à 110% de la valeur du coût précedent de même 1.5 => 150%)
			- si le nombre est un entier on fait n fois ILS avant de s'arrêter

	VNS :

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis
			4eme colonne le nombre d'execution

		-Dans le nom

			-quand le nombre est un float ,le seuil est active on s'arrete que si on ne diminue plus en dessous d'un certain % (1.1 équivaut à être inferieur à 110% de la valeur du coût précedent de même 1.5 => 150%)
			- si le nombre est un entier on fait n fois VNS avant de s'arrêter



	VND :

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis

		-Dans le nom

			-little/Big sont les instances
			-alea/sans_alea une stratégie de choix aléatoire ou pas des voisinage
			-sol_alea/sol_gloutonne le mode de la solution de depart (alea ou gloutonne)
			-l'entier est le nombre d'itération
			- I@5f150435 => voi = {2,1,0};
			- I@4b6995df => voi2 = {2,0,1};


	Ma :

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis

		-Dans le nom

			-le premier nombre => taillePopulation
			-le deuxieme nombre => NbGeneration
			-le troisieme nombre => cRate
			-le quatrieme nombre => pmut

	Ga : 

		-Dans le fichier 

			1eme colonee le numero d'instance 
			2eme colonne la deviance
			3eme colonne le temps d'execution Millis

		-Dans le nom

			-le premier nombre => taillePopulation
			-le deuxieme nombre => NbGeneration
			-le troisieme nombre => NbCross
			-le quatrieme nombre => nbMutant


