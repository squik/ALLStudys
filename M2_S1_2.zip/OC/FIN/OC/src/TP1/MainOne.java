package TP1;

import java.io.IOException;
import java.util.ArrayList;

public class MainOne {

	
	public static void main(String[] args) throws IOException {
		
		
		Instance i = SearchInstance.search(1,100);
		Instance i2 = SearchInstance.search(1000,"1");

		int[] ordreAlea = SolutionAlea.solution(i);
		int[] ordreEDD = SolutionEDD.solution(i);
		int[] ordreMDD =SolutionMDD.solution(i);
		int[] ordreRend =SolutionRend.solution(i);
		System.out.println(" sans traitement => "+F.fSomme(i));
		System.out.println(" alea => "+F.fSomme(i,ordreAlea));

		System.out.println(" EDD  => "+F.fSomme(i,ordreEDD));
		
		System.out.println(" MDD  => "+F.fSomme(i,ordreMDD));
	
		System.out.println(" Rend  => "+F.fSomme(i,ordreRend));
		
		
		
		int[] ordreAlea2 = SolutionAlea.solution(i2);
		int[] ordreEDD2 = SolutionEDD.solution(i2);
		int[] ordreMDD2 =SolutionMDD.solution(i2);
		System.out.println(" sans traitement => "+F.fSomme(i2));
		System.out.println(" alea => "+F.fSomme(i2,ordreAlea2));
		
		System.out.println(" EDD  => "+F.fSomme(i2,ordreEDD2));
		
		System.out.println(" MDD  => "+F.fSomme(i2,ordreMDD2));
	
		

	
		
		System.out.print("\n\n TS \n");
		
		System.out.print("dev grand AVANT TS: ");
		System.out.println(F.fSomme(i2));
		
		Instance i5 = SearchInstance.search(24,100);
		System.out.println(i5);
		
		ArrayList<int[]> tabou = new ArrayList<int[]>();
		ArrayList<Integer> deb = new ArrayList<Integer>();
		ArrayList<Integer> fin = new ArrayList<Integer>();
		
		long debut = System.currentTimeMillis();			
		Instance ordreTS = TS.TS(i5, 0,tabou,deb,fin);			
		long diff = System.currentTimeMillis()-debut;
		
		System.out.print("TIME : ");
		System.out.println(diff);
		
		System.out.print("=> : ");
		System.out.println(F.fSomme(ordreTS));
		System.out.print("deviation : ");
		System.out.println(100*(float) (F.fSomme(ordreTS)-744287)/744287);
		
		
		System.out.print("dev grand APRES TS: ");
		System.out.println(F.fSomme(i2));

		debut = System.currentTimeMillis();		
		int[] ordreGA = GA.Ga(i5,10,5,350,200);
		diff = System.currentTimeMillis()-debut;
		
		

		
		System.out.print("TIME : ");
		System.out.println(diff);
		System.out.println(" GA => "+F.fSomme(i5,ordreGA));
		System.out.print("deviation : ");
		System.out.println(100*(float) (F.fSomme(i5,ordreGA)-744287)/744287);
		
		

		
		debut = System.currentTimeMillis();		
		int[] ordreMA = MA.Ma(i5,10,2,0.5,0.75);
		diff = System.currentTimeMillis()-debut;
		
		System.out.print("TIME : ");
		System.out.println(diff);
		System.out.println(" MA => "+F.fSomme(i5,ordreMA));
		System.out.print("deviation : ");
		System.out.println(100*(float) (F.fSomme(i5,ordreMA)-744287)/744287);
		
		
		System.out.println("FIN");
		
		

		

		System.out.println("\n VND \n");
		
		
		ArrayList<int[]> listVoisin = new ArrayList<int[]>() ;
		
		int[] voi = {2,1,0};
		int[] voi2 = {2,0,1};
		
		listVoisin.add(voi);
		listVoisin.add(voi2);
		
		
		float moyT = 0;
		float moyD =0;
		float dev = 0;
		
		int nbRun = 30;
		i2 = SearchInstance.search(1000,"1");
		System.out.print("dev grand: ");
		System.out.println(F.fSomme(i2));
		for ( int[] voisinage : listVoisin){
			
			
			for (int ss = 0 ;ss<2;ss++){
				for (int s = 0 ;s<3;s++){
					
					moyT = 0;
					moyD=0;
					for(int k =0 ; k<nbRun ;k++){
						
						debut = System.currentTimeMillis();
						int[] ordreRun= VND.VND(false,-1,-1, ss,voisinage,s,i2);
						diff = System.currentTimeMillis()-debut;
						
						
						dev = 100*(F.fSomme(i2,ordreRun)-661265390)/661265390;
						moyT+=diff ;
						moyD+= dev ;

					}
					
					// remplacer par mettre dans un fichier
					
					System.out.println( "ss : "+ss+" s = "+s);
					System.out.print("TIMEMoy : ");
					System.out.println(moyT/nbRun);
					System.out.print("deviationMoy : ");
					System.out.println(moyD/nbRun);
					
				}				
		}
			
			
		}
		
		
	}
	
	
	
	
}
