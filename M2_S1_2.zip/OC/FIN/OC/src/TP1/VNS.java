package TP1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class VNS {
	
	
	public static Instance VNS(Instance i,Instance ibis,int[] kvoisin,boolean descente,int limit,float seuil,int res) throws IOException{

		
		int[] ordre = SolutionEDD.solution(i);
		i= i.transfo(ordre);
		
		ArrayList<ArrayList<int[]>> voisin = VND.voisin(ordre, kvoisin);
		
		
		
		int cptAction = 0;
		int k = 1;
		
		long somme = 0;
		while(cptAction < limit){
			System.out.println(cptAction);
			
			if(k > kvoisin.length-1){
				k=1;
			}
			
			if (descente) {
				somme = F.fSomme(i);
			}
			
			ordre = solutionRand(voisin,k);
			ibis = ibis.transfo(ordre);
			
			ibis = ibis.transfo(VND.VND(false, -1, -1, 0, kvoisin, 2, ibis));		
			if(F.fSomme(i)>F.fSomme(ibis)){
				i=ibis;
				voisin = VND.voisin(ordre, kvoisin);
				k=1;
			}else{
				++k;
			}
			
			
			
			if(descente) {
				if(somme >seuil*F.fSomme(i)) {
					res = cptAction;
					return i ;
				}
			}
			++cptAction;
		}
		
		return i;
		
	}
	
	public static int[] solutionRand(ArrayList<ArrayList<int[]>> voisin ,int k){
		
		if (k > voisin.size()-1){
			return null;
		}
		ArrayList<int[]> ordreChoix = voisin.get(k);
		Collections.shuffle(voisin);
		
		return ordreChoix.get(0);
		
	}
	
	

}
