package TP1;

import java.util.ArrayList;
import java.util.Collections;

public class GA {
	
	
	public static ArrayList<int[]> Population(Instance i,int N){
		
		ArrayList<int[]> res = new ArrayList<int[]>();
		
		for (int cpt =0;cpt<N-2;cpt++){
			res.add(SolutionAlea.solution(i));
		}
		res.add(SolutionEDD.solution(i));
		res.add(SolutionMDD.solution(i));
		
		return res;
	}
	
	
	public static ArrayList<int[]> CrossOver(int[] parent1,int[] parent2,int nbPris1){
		
		
		ArrayList<int[]> res = new ArrayList<int[]>();
		
		if(nbPris1>parent1.length){
			res.add(parent1);
			res.add(parent2);
			return res;
		}
		
		ArrayList<Integer> listdechoix = new ArrayList<Integer>();
		for (int cpt = 0;cpt < parent1.length;cpt++){
			listdechoix.add(cpt);
		}
		
		Collections.shuffle(listdechoix);		
		
		int[] listdechoix1 = new int[nbPris1];
		int[] listdechoix2 = new int[parent1.length-nbPris1];
		
		
		for (int t =0;t<parent1.length;t++){
			
			if(t<nbPris1){
				listdechoix1[t]=listdechoix.get(t);
			}else{
				listdechoix2[t-nbPris1]=listdechoix.get(t);
			}			
		}
		
		
		int[] fils1 = new int[parent1.length];
		int[] fils2 = new int[parent1.length];
		
		
		for (int a : listdechoix1){
			fils1[a]=parent1[a];
			fils2[a]=parent2[a];
			
		}
		
		for (int b : listdechoix2){
			fils1[b]=parent2[b];
			fils2[b]=parent1[b];
		}
		
		res.add(fils1);
		res.add(fils2);
		
		
		return res;
	}
	
	public static int[] mutation(int[] parent){
		
		int position1 = (int) (Math.random()*parent.length);
		int position2 = (int) (Math.random()*parent.length);		
		
		return HillClimbing.swap(parent, position1, position2);
	}
	
	
	public static ArrayList<int[]> MAJ(Instance i,ArrayList<int[]> population,ArrayList<int[]> populationCroise, ArrayList<int[]> populationMute){
		
		ArrayList<int[]> res = new ArrayList<int[]>();
		
		res.addAll(population);
		res.addAll(populationCroise);
		res.addAll(populationMute);
		
		
		int nbElimine = populationCroise.size()+populationMute.size();
		
		
		for (int cpt = 0;cpt <nbElimine;cpt++){
			
			int[] ordre = null;
			
			
			for (int[] pop : res){
				if(ordre ==null){
					ordre = pop;
				}else{
					if(F.fSomme(i, ordre)>F.fSomme(i,pop)){
						ordre =pop;
					}
				}
			}
			res.remove(ordre);
			
		}
		
		return res;
	}
	
	public static int[] bestPop(ArrayList<int[]> population,Instance i){
		
		int[] ordre = null;
		
		
		for (int[] pop : population){
			if(ordre ==null){
				ordre = pop;
			}else{
				if(F.fSomme(i, ordre)<F.fSomme(i,pop)){
					ordre =pop;
				}
			}
		}
		
		return ordre;
	}
	
	
	public static int[] Ga(Instance i,int taillePopulation,int NbGeneration,int NbCross, int nbMutant){
		
		
		ArrayList<int[]> populationInit = Population(i,taillePopulation);
		
		for (int g=1;g<NbGeneration;g++){
			ArrayList<int[]> populationCroise = new ArrayList<int[]>();
			
			for (int n =1 ;n<NbCross;n++){
				Collections.shuffle(populationInit);
				int[] parent1 = populationInit.get(0);
				int[] parent2 = null;
				
				int cpt = 1;
				while((parent2 =populationInit.get(cpt))==parent1&&cpt<populationInit.size()-1){
					cpt++;
				}
				
				if(parent2 ==null){
					populationCroise.add(parent1);
				}else{				
				populationCroise.addAll(CrossOver(parent1,parent2,NbCross));
				}
				
			}
			
			ArrayList<int[]> populationMute = new ArrayList<int[]>();
			
			for (int m =1;m<nbMutant;m++){
				Collections.shuffle(populationInit);
				int[] parent = populationInit.get(0);
				
				populationMute.add(mutation(parent));
				
			}
			
			populationInit = MAJ(i,populationInit,populationCroise,populationMute);
			
		}
		
		
		return bestPop(populationInit,i);
	}

}
