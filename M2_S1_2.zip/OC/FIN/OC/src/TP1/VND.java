package TP1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class VND {
	
	
	
	public static int[] VND(boolean aleaChoix,int nbIteration,int nbinstance,int choixStratege,int[] choixVoisin,int modeSoluce,Instance instance) throws IOException{
		
			Instance i = instance;
		if (nbinstance!=-1){
			i = SearchInstance.search(nbinstance,100);
		}
		
		
		
		int[] ordre = null;
		
		if (modeSoluce==0){
			ordre = SolutionAlea.solution(i);
		}else{
			if(modeSoluce ==1){
				ordre = SolutionEDD.solution(i);
			}else{
				ordre =SolutionMDD.solution(i);
			}
		}
		long res = F.fSomme(i,ordre);
		
		ArrayList<ArrayList<int[]>> lesVoisins = voisin(ordre,choixVoisin);
		
		ArrayList<int[]> currentListVoisin = null;
		
		while(!lesVoisins.isEmpty()){
			
			
			int nbIt = nbIteration;
			if (aleaChoix){
				Collections.shuffle(lesVoisins);
			}
			
			
			
			
			currentListVoisin =lesVoisins.get(0);
			lesVoisins.remove(0);
			
			while(!currentListVoisin.isEmpty()){
				if(choixStratege==0){
					
					boolean notbetter = true;
					
					while(notbetter){
						
						long resOpti = res;
						int[] ordreOpti = null;
						while (!currentListVoisin.isEmpty()){
							int choix = (int) (Math.random() * currentListVoisin.size());			
							

							long res2 = F.fSomme(i,currentListVoisin.get(choix));
								
								if(nbIt<nbIteration && nbIteration !=-1){break;}
								
								nbIt++;								
								
								if(res2<resOpti ){		
								
									resOpti = res2;
									ordreOpti =currentListVoisin.get(choix);
									
								}
								currentListVoisin.remove(choix);
						}
						
						if (resOpti < res){
							ordre = ordreOpti;
							res = resOpti;
							lesVoisins = voisin(ordre,choixVoisin);
						}else{
							notbetter=false;
						}
						
					}
					
					
				}else{	
				while (!currentListVoisin.isEmpty()){
					int choix = (int) (Math.random() * currentListVoisin.size());			
						

					long res2 = F.fSomme(i,currentListVoisin.get(choix));
						
						if(nbIt<nbIteration && nbIteration !=-1){break;}
						
						nbIt++;
						if(res2<res ){		
							
							ordre = currentListVoisin.get(choix);
							lesVoisins = voisin(ordre,choixVoisin);
							res=res2;
							break;
						}else{
							currentListVoisin.remove(choix);
						}	
					
					}	
				}
				
				
				
			}
			
			
			
			
			
			
			
		}
		
		
		
		return ordre;
		
		
	}
	
	public static ArrayList<ArrayList<int[]>> voisin(int[] ordre, int[] choixVoisin){
		
		ArrayList<ArrayList<int[]>> res = new ArrayList<ArrayList<int[]>>() ;
		
		
		for (int a :choixVoisin){
			
			res.add(HillClimbing.voisin(ordre,a));
		}
		
		
		
		
		return res;		
		
		
	}
	
	

}
