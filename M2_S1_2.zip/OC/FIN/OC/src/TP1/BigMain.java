package TP1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public class BigMain {
	
	
	//debut = System.currentTimeMillis();					
	//diff = System.currentTimeMillis()-debut;
	


	public static void main(String[] args) throws IOException {
		
		
		FileInputStream flux1= new FileInputStream("C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\wtbest100b.txt");
		InputStreamReader lecture1=new InputStreamReader(flux1);
		BufferedReader buff1=new BufferedReader(lecture1);
		String ligne1 ="";
		int[] score1 = new int[125] ;
		int cpt1 = 0;
		long debut;
		long diff;
		
		
		while ((ligne1=buff1.readLine())!=null){
			
			String[] reg = ligne1.split("[^0-9]") ;
			for (String sa : reg){
				try{
					score1[cpt1]=Integer.valueOf(sa);
					
							
				}
				catch(Exception e){
					
				}
			}
			
			cpt1++;
			
		}
		
		FileInputStream flux= new FileInputStream("C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\instances\\optimal_results.txt");
		InputStreamReader lecture=new InputStreamReader(flux);
		BufferedReader buff=new BufferedReader(lecture);
		String ligne ="";
		int[] score = new int[25] ;
		int cpt = 0;
		
		while ((ligne=buff.readLine())!=null){			
			score[cpt] = Integer.valueOf(ligne);
			cpt++;
			
		}
		
		
		ArrayList<Integer> listpopulation = new ArrayList<Integer>();
		listpopulation.add(20);
		listpopulation.add(50);
		listpopulation.add(100);	
		
		ArrayList<Integer> listnbgene = new ArrayList<Integer>();
		
		listnbgene.add(5);
		listnbgene.add(10);	
		
		ArrayList<Integer> cr = new ArrayList<Integer>();
		cr.add(5);
		cr.add(10);	
		
		for (int pop : listpopulation ) {
			for (int nbgene :listnbgene ) {
				for (int crf : cr) {
					for (int crf2 : cr) {
					FileOutputStream GAfile = new FileOutputStream(new File("Ga_little_"+pop+"_"+nbgene+"_"+crf));
					
					for (int nbi =1;nbi<26;nbi++){
						Instance i = SearchInstance.search(nbi,100);
						Instance ibis = SearchInstance.search(nbi,100);
						
						
					debut = System.currentTimeMillis();		
					int[] ordreGA = GA.Ga(i,pop,nbgene,crf,crf2);
					diff = System.currentTimeMillis()-debut;
					
					
					GAfile.write((nbi+" ").getBytes());
					GAfile.write(Float.toString(100*(float) (F.fSomme(i,ordreGA)-744287)/744287).getBytes());
					GAfile.write((" ").getBytes());
					GAfile.write(Float.toString(diff).getBytes());
					GAfile.write(("\n").getBytes());

					}
					GAfile.close() ;
					}
				}
			}
		}
		
		for (int pop : listpopulation ) {
			for (int nbgene :listnbgene ) {
				for (int crf : cr) {
					for (int crf2 : cr) {
					FileOutputStream GAfile = new FileOutputStream(new File("Ga_Big_"+pop+"_"+nbgene+"_"+crf+"_"+crf2));
					
					for (int nbBi = 1;nbBi<6;nbBi++){
						Instance i2 = SearchInstance.search(1000,""+nbBi);
						Instance i2bis = SearchInstance.search(1000,""+nbBi);
						
						
					debut = System.currentTimeMillis();		
					int[] ordreGA = GA.Ga(i2,pop,nbgene,crf,crf2);
					diff = System.currentTimeMillis()-debut;
					
					
					GAfile.write((nbBi+" ").getBytes());
					GAfile.write(Float.toString(100*(float) (F.fSomme(i2,ordreGA)-744287)/744287).getBytes());
					GAfile.write((" ").getBytes());
					GAfile.write(Float.toString(diff).getBytes());
					GAfile.write(("\n").getBytes());
					}
					GAfile.close() ;
					}
				
				}
			}
		}

		
		

		ArrayList<Float> rate = new ArrayList<Float>();
		rate.add((float) 0.2);
		rate.add((float) 0.5);
		rate.add((float) 0.8);
		
		
		for (int pop : listpopulation ) {
			for (int nbgene :listnbgene ) {
				for (float crf : rate) {
					for (float crf2 : rate) {
					FileOutputStream MAfile = new FileOutputStream(new File("Ma_little_"+pop+"_"+nbgene+"_"+crf+"_"+crf2));
					
					for (int nbi =1;nbi<26;nbi++){
						Instance i = SearchInstance.search(nbi,100);
						Instance ibis = SearchInstance.search(nbi,100);
						
						
					debut = System.currentTimeMillis();		
					int[] ordreMA = MA.Ma(i,pop,nbgene,crf,crf2);
					diff = System.currentTimeMillis()-debut;
					
					
					MAfile.write((nbi+" ").getBytes());
					MAfile.write(Float.toString(100*(float) (F.fSomme(i,ordreMA)-744287)/744287).getBytes());
					MAfile.write((" ").getBytes());
					MAfile.write(Float.toString(diff).getBytes());
					MAfile.write(("\n").getBytes());
					}
					MAfile.close() ;
					}
				
				}
			}
		}
		
		
		for (int pop : listpopulation ) {
			for (int nbgene :listnbgene ) {
				for (float crf : rate) {
					for (float crf2 : rate) {
					FileOutputStream MAfile = new FileOutputStream(new File("Ma_Big_"+pop+"_"+nbgene+"_"+crf+"_"+crf2));
					
					for (int nbBi = 1;nbBi<6;nbBi++){
						Instance i2 = SearchInstance.search(1000,""+nbBi);
						Instance i2bis = SearchInstance.search(1000,""+nbBi);
						
						
					debut = System.currentTimeMillis();		
					int[] ordreMA = MA.Ma(i2,pop,nbgene,crf,crf2);
					diff = System.currentTimeMillis()-debut;
					
					
					MAfile.write((nbBi+" ").getBytes());
					MAfile.write(Float.toString(100*(float) (F.fSomme(i2,ordreMA)-744287)/744287).getBytes());
					MAfile.write((" ").getBytes());
					MAfile.write(Float.toString(diff).getBytes());
					MAfile.write(("\n").getBytes());
					}
					MAfile.close() ;
					}
				
				}
			}
		}
		
		float moyT = 0;
float moyD =0;
float dev = 0;

int nbRun = 30;

String nom = "Hill_CLimbing_little_";
		
		
		System.out.println("\n HILL climbing \n");
		
		
		float moyT = 0;
		float moyD =0;
		float dev = 0;
		
		int nbRun = 30;
		
		String nom = "Hill_CLimbing_little_";
		for (int ss = 0 ;ss<2;ss++){
			for (int v = 0 ;v<3;v++){
				for (int s = 0 ;s<3;s++){
					
					String nomsoluce ="";
					String nomAction ="";
					String nomImpr ="";
					
					if (s == 0) {
						nomsoluce ="alea_";
					}
					if (s == 1) {
						nomsoluce ="EDD_";
					}
					if (s == 2) {
						nomsoluce ="MDD_";
					}
					
					if (v == 0) {
						nomAction ="Insert_";
					}
					if (v == 1) {
						nomAction ="Swap_";
					}
					if (v == 2) {
						nomAction ="echange_";
					}
					
					if(ss==0) {nomImpr ="Best_";}
					if(ss==1) {nomImpr ="First_";}
					
					FileOutputStream HillCLimbing = new FileOutputStream(new File(nom+nomsoluce+nomAction+nomImpr));
					for (int nbi =1;nbi<26;nbi++){
						Instance i = SearchInstance.search(nbi,100);
						Instance ibis = SearchInstance.search(nbi,100);
					
					moyT = 0;
					moyD=0;
					for(int k =0 ; k<nbRun ;k++){
						
						debut = System.currentTimeMillis();
						int[] ordreRun= HillClimbing.smtWTP(i, ss,v,s);
						diff = System.currentTimeMillis()-debut;
						
						
						dev = 100*(F.fSomme(i,ordreRun)-score1[nbi-1])/score1[nbi-1];
						moyT+=diff ;
						moyD+= dev ;
					}
					
					// remplacer par mettre dans un fichier
					
					
					HillCLimbing.write((nbi+" ").getBytes());
					HillCLimbing.write(Float.toString(moyD/nbRun).getBytes());
					HillCLimbing.write((" ").getBytes());
					HillCLimbing.write(Float.toString(moyT/nbRun).getBytes());
					HillCLimbing.write(("\n").getBytes());

					}
					HillCLimbing.close() ;
				}
			}
		
		
		}
		
		System.out.println("\n VND \n");
		
		
		ArrayList<int[]> listVoisin = new ArrayList<int[]>() ;
		
		int[] voi = {2,1,0};
		int[] voi2 = {2,0,1};
		
		listVoisin.add(voi);
		listVoisin.add(voi2);
		
		ArrayList<Integer> listIteration = new ArrayList<Integer>();
		listIteration.add(10);
		listIteration.add(50);
		listIteration.add(100);
		
		for ( int[] voisinage : listVoisin){
			for (int iter :listIteration) {
			
				for (int truci = 0 ;truci<2;truci++) {
					for (int truci2 = 0 ;truci2<2;truci2++) {
					
		
					
					// remplacer par mettre dans un fichier
					
					  nom = "VND_little_";
					 String nomalea="";
					 String choixalea="";
					 if(truci2 ==0) {choixalea="sans_alea_";}
					 else {
						 choixalea="avec_alea_";
					 }
					 if(truci ==0) {
						 nomalea="sol_alea_";
					 }
					 else {
						 nomalea="sol_gloutonne";
					 }
					 
					 FileOutputStream VNDfile = new FileOutputStream(new File(nom+voisinage.toString()+"_"+choixalea+iter+"_"+nomalea));

						for (int nbi =1;nbi<26;nbi++){
							Instance i = SearchInstance.search(nbi,100);
							Instance ibis = SearchInstance.search(nbi,100);
							
							 moyT = 0;
							 moyD=0;
							for(int k =0 ; k<nbRun ;k++){
								int[] ordreRun = null;
								debut = System.currentTimeMillis();
								if(truci ==0) {
									if(truci2 ==0) { ordreRun= VND.VND(false,-1,-1, 0,voisinage,0,i);}
								else {ordreRun= VND.VND(true,-1,-1, 0,voisinage,0,i);}
								
								}else {
									if(truci2 ==0) { ordreRun= VND.VND(false,-1,-1, 0,voisinage,2,i);}
									else {ordreRun= VND.VND(true,-1,-1, 0,voisinage,2,i);}
								}
								diff = System.currentTimeMillis()-debut;
								
								
								dev = 100*(F.fSomme(i,ordreRun)-score1[nbi-1])/score1[nbi-1];
								moyT+=diff ;
								moyD+= dev ;

							}
							
					VNDfile.write((nbi+" ").getBytes());
					VNDfile.write(Float.toString(moyD/nbRun).getBytes());
					VNDfile.write((" ").getBytes());
					VNDfile.write(Float.toString(moyT/nbRun).getBytes());
					VNDfile.write(("\n").getBytes());
						}
					VNDfile.close();
			}
				}}				
		}
		
		
		
		System.out.print("\n\n ILS \n");
		
		int k_opt =20;
		
		ArrayList<Integer> listlimit = new ArrayList<Integer>();
		listlimit.add(5);
		listlimit.add(10);
		
		
		String nomils = "ILS_little_";
		for (int limit :listlimit) {
			
			
			 FileOutputStream ILSfile = new FileOutputStream(new File(nomils+limit));
		int res = 0;
			 
				for (int nbi =1;nbi<26;nbi++){
					Instance i = SearchInstance.search(nbi,100);
					Instance ibis = SearchInstance.search(nbi,100);
					
		debut = System.currentTimeMillis();
		Instance ordreILS = ILS.ILS(i, k_opt,false,limit,1,res);
		diff = System.currentTimeMillis()-debut;
		
		

		
		ILSfile.write((nbi+" ").getBytes());
		ILSfile.write(Float.toString(100*(F.fSomme(ordreILS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		ILSfile.write((" ").getBytes());
		ILSfile.write(Float.toString(diff).getBytes());
		ILSfile.write((" "+res).getBytes());
		ILSfile.write(("\n").getBytes());
				}
				ILSfile.close();
		}
		
		ArrayList<Float> listseuil = new ArrayList<Float>();
		listseuil.add((float) 1.1);
		listseuil.add((float) 1.5);
		
		for (float seuil :listseuil) {
			 FileOutputStream ILSfile = new FileOutputStream(new File(nomils+seuil));
			for (int nbi =1;nbi<26;nbi++){
				Instance i = SearchInstance.search(nbi,100);
				Instance ibis = SearchInstance.search(nbi,100);
		int res = 0;
		debut = System.currentTimeMillis();
		Instance ordreILS = ILS.ILS(i, k_opt,true,20,seuil,res);
		diff = System.currentTimeMillis()-debut;
		
		
		// remplacer par mettre dans un fichier
		ILSfile.write((nbi+" ").getBytes());
		ILSfile.write(Float.toString(100*(F.fSomme(ordreILS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		ILSfile.write((" ").getBytes());
		ILSfile.write(Float.toString(diff).getBytes());
		ILSfile.write((" "+res).getBytes());
		ILSfile.write(("\n").getBytes());

			}
			ILSfile.close();
		}		
			ArrayList<Integer> listlimit = new ArrayList<Integer>();
		listlimit.add(5);
		listlimit.add(10);
		

		
		System.out.print("\n\n VNS \n");
		
		
		int[] voiVNS = {2,0,1};
		int res=0;
		String nomvns = "VNS_little_";
		for (float seuil :listseuil) {
			FileOutputStream VNSfile = new FileOutputStream(new File(nomvns+seuil));
		
		for (int nbi =1;nbi<26;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
		debut = System.currentTimeMillis();
		Instance ordreVNS = VNS.VNS(i,ibis, voiVNS,true,20,seuil,res);
		diff = System.currentTimeMillis()-debut;
		
		VNSfile.write((nbi+" ").getBytes());
		VNSfile.write(Float.toString(100*(F.fSomme(ordreVNS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		VNSfile.write((" ").getBytes());
		VNSfile.write(Float.toString(diff).getBytes());
		VNSfile.write((" "+res).getBytes());
		VNSfile.write(("\n").getBytes());
		
		}
		VNSfile.close();
		}
		
		for (int limit :listlimit) {
			FileOutputStream VNSfile = new FileOutputStream(new File(nomils+limit));
		
		for (int nbi =1;nbi<26;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
		debut = System.currentTimeMillis();
		Instance ordreVNS = VNS.VNS(i,ibis, voiVNS,false,limit,1,res);
		diff = System.currentTimeMillis()-debut;
		
		VNSfile.write((nbi+" ").getBytes());
		VNSfile.write(Float.toString(100*(F.fSomme(ordreVNS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		VNSfile.write((" ").getBytes());
		VNSfile.write(Float.toString(diff).getBytes());
		VNSfile.write((" "+res).getBytes());
		VNSfile.write(("\n").getBytes());
		
		}
		VNSfile.close();
		}
			
System.out.println("\n HILL climbing \n");
		
		
		moyT = 0;
		 moyD =0;
		dev = 0;
		
		 nbRun = 30;
		
		 nom = "Hill_CLimbing_Big_";
		for (int ss = 0 ;ss<2;ss++){
			for (int v = 0 ;v<3;v++){
				for (int s = 0 ;s<3;s++){
					
					String nomsoluce ="";
					String nomAction ="";
					String nomImpr ="";
					
					if (s == 0) {
						nomsoluce ="alea_";
					}
					if (s == 1) {
						nomsoluce ="EDD_";
					}
					if (s == 2) {
						nomsoluce ="MDD_";
					}
					
					if (v == 0) {
						nomAction ="Insert_";
					}
					if (v == 1) {
						nomAction ="Swap_";
					}
					if (v == 2) {
						nomAction ="echange_";
					}
					
					if(ss==0) {nomImpr ="Best_";}
					if(ss==1) {nomImpr ="First_";}
					
					FileOutputStream HillCLimbing = new FileOutputStream(new File(nom+nomsoluce+nomAction+nomImpr));
					for (int nbBi = 1;nbBi<6;nbBi++){
						Instance i2 = SearchInstance.search(1000,""+nbBi);
						Instance i2bis = SearchInstance.search(1000,""+nbBi);
					
					moyT = 0;
					moyD=0;
					for(int k =0 ; k<nbRun ;k++){
						
						debut = System.currentTimeMillis();
						int[] ordreRun= HillClimbing.smtWTP(i2, ss,v,s);
						diff = System.currentTimeMillis()-debut;
						
						
						dev = 100*(F.fSomme(i2,ordreRun)-score1[nbBi-1])/score1[nbBi-1];
						moyT+=diff ;
						moyD+= dev ;
					}
					
					// remplacer par mettre dans un fichier
					
					
					HillCLimbing.write((nbBi+" ").getBytes());
					HillCLimbing.write(Float.toString(moyD/nbRun).getBytes());
					HillCLimbing.write((" ").getBytes());
					HillCLimbing.write(Float.toString(moyT/nbRun).getBytes());
					HillCLimbing.write(("\n").getBytes());

					}
					HillCLimbing.close() ;
				}
			}
		
		
		}
		
		
		System.out.println("\n VND \n");
		
		
		listVoisin = new ArrayList<int[]>() ;
		

		
		listVoisin.add(voi);
		listVoisin.add(voi2);
		
		listIteration = new ArrayList<Integer>();
		listIteration.add(10);
		listIteration.add(50);
		listIteration.add(100);
		for ( int[] voisinage : listVoisin){
			for (int iter :listIteration) {
			
				for (int truci = 0 ;truci<2;truci++) {
					for (int truci2 = 0 ;truci2<2;truci2++) {
					
		
					
					// remplacer par mettre dans un fichier
					
					 nom = "VND_Big_";
					 String nomalea="";
					 String choixalea="";
					 if(truci2 ==0) {choixalea="sans_alea_";}
					 else {
						 choixalea="avec_alea_";
					 }
					 if(truci ==0) {
						 nomalea="sol_alea_";
					 }
					 else {
						 nomalea="sol_gloutonne";
					 }
					 
					 FileOutputStream VNDfile = new FileOutputStream(new File(nom+voisinage.toString()+"_"+choixalea+iter+"_"+nomalea));

						for (int nbBi = 1;nbBi<6;nbBi++){
							Instance i2 = SearchInstance.search(1000,""+nbBi);
							Instance i2bis = SearchInstance.search(1000,""+nbBi);
							
							moyT = 0;
							moyD=0;
							for(int k =0 ; k<nbRun ;k++){
								int[] ordreRun = null;
								debut = System.currentTimeMillis();
								if(truci ==0) {
									if(truci2 ==0) { ordreRun= VND.VND(false,-1,-1, 0,voisinage,0,i2);}
								else {ordreRun= VND.VND(true,-1,-1, 0,voisinage,0,i2);}
								
								}else {
									if(truci2 ==0) { ordreRun= VND.VND(false,-1,-1, 0,voisinage,2,i2);}
									else {ordreRun= VND.VND(true,-1,-1, 0,voisinage,2,i2);}
								}
								diff = System.currentTimeMillis()-debut;
								
								
								dev = 100*(F.fSomme(i2,ordreRun)-score1[nbBi-1])/score1[nbBi-1];
								moyT+=diff ;
								moyD+= dev ;

							}
							
					VNDfile.write((nbBi+" ").getBytes());
					VNDfile.write(Float.toString(moyD/nbRun).getBytes());
					VNDfile.write((" ").getBytes());
					VNDfile.write(Float.toString(moyT/nbRun).getBytes());
					VNDfile.write(("\n").getBytes());
						}
					VNDfile.close();
			}
				}}				
		}
		
		
		
		System.out.print("\n\n ILS \n");
		
		int k_opt =20;
		
		 listlimit = new ArrayList<Integer>();
		listlimit.add(5);
		listlimit.add(10);
		
		
		 nomils = "ILS_Big_";
		for (int limit :listlimit) {
			
			
			 FileOutputStream ILSfile = new FileOutputStream(new File(nomils+limit));
		int res = 0;
			 
			for (int nbBi = 1;nbBi<6;nbBi++){
				Instance i2 = SearchInstance.search(1000,""+nbBi);
				Instance i2bis = SearchInstance.search(1000,""+nbBi);
					
		debut = System.currentTimeMillis();
		Instance ordreILS = ILS.ILS(i2, k_opt,false,limit,1,res);
		diff = System.currentTimeMillis()-debut;
		
		

		
		ILSfile.write((nbBi+" ").getBytes());
		ILSfile.write(Float.toString(100*(F.fSomme(ordreILS)-score1[nbBi-1])/score1[nbBi-1]).getBytes());
		ILSfile.write((" ").getBytes());
		ILSfile.write(Float.toString(diff).getBytes());
		ILSfile.write((" "+res).getBytes());
		ILSfile.write(("\n").getBytes());
				}
				ILSfile.close();
		}
		
		listseuil = new ArrayList<Float>();
		listseuil.add((float) 1.1);
		listseuil.add((float) 1.5);
		
		for (float seuil :listseuil) {
			 FileOutputStream ILSfile = new FileOutputStream(new File(nomils+seuil));
				for (int nbBi = 1;nbBi<6;nbBi++){
					Instance i2 = SearchInstance.search(1000,""+nbBi);
					Instance i2bis = SearchInstance.search(1000,""+nbBi);
		int res = 0;
		debut = System.currentTimeMillis();
		Instance ordreILS = ILS.ILS(i2, k_opt,true,20,seuil,res);
		diff = System.currentTimeMillis()-debut;
		
		
		// remplacer par mettre dans un fichier
		ILSfile.write((nbBi+" ").getBytes());
		ILSfile.write(Float.toString(100*(F.fSomme(ordreILS)-score1[nbBi-1])/score1[nbBi-1]).getBytes());
		ILSfile.write((" ").getBytes());
		ILSfile.write(Float.toString(diff).getBytes());
		ILSfile.write((" "+res).getBytes());
		ILSfile.write(("\n").getBytes());

			}
			ILSfile.close();
		}		
		
		
		
		System.out.print("\n\n VNS \n");
		
		
		
		 res=0;
		 nomvns = "VNS_Big_";
		for (float seuil :listseuil) {
			FileOutputStream VNSfile = new FileOutputStream(new File(nomvns+seuil));
		
		for (int nbi =1;nbi<26;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
		debut = System.currentTimeMillis();
		Instance ordreVNS = VNS.VNS(i,ibis, voiVNS,true,20,seuil,res);
		diff = System.currentTimeMillis()-debut;
		
		VNSfile.write((nbi+" ").getBytes());
		VNSfile.write(Float.toString(100*(F.fSomme(ordreVNS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		VNSfile.write((" ").getBytes());
		VNSfile.write(Float.toString(diff).getBytes());
		VNSfile.write((" "+res).getBytes());
		VNSfile.write(("\n").getBytes());
		
		}
		VNSfile.close();
		}
		
		for (int limit :listlimit) {
			FileOutputStream VNSfile = new FileOutputStream(new File(nomils+limit));
		
		for (int nbi =1;nbi<26;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
		debut = System.currentTimeMillis();
		Instance ordreVNS = VNS.VNS(i,ibis, voiVNS,false,limit,1,res);
		diff = System.currentTimeMillis()-debut;
		
		VNSfile.write((nbi+" ").getBytes());
		VNSfile.write(Float.toString(100*(F.fSomme(ordreVNS)-score1[nbi-1])/score1[nbi-1]).getBytes());
		VNSfile.write((" ").getBytes());
		VNSfile.write(Float.toString(diff).getBytes());
		VNSfile.write((" "+res).getBytes());
		VNSfile.write(("\n").getBytes());
		
		}
		VNSfile.close();
		}
		
		FileOutputStream foslittle = new FileOutputStream(new File("Resultatlittle.txt"));
		FileOutputStream fosAlealittle = new FileOutputStream(new File("ResultatAlealittle.txt"));
		FileOutputStream fosEDDlittle = new FileOutputStream(new File("ResultatEDDlittle.txt"));
		FileOutputStream fosMDDlittle = new FileOutputStream(new File("ResultatMDDlittle.txt"));
		FileOutputStream fosRendlittle = new FileOutputStream(new File("ResultatRendlittle.txt"));
		for (int nbi =1;nbi<26;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
			
			foslittle.write((nbi+" ").getBytes());
			foslittle.write(Long.toString(F.fSomme(i)).getBytes());
			if(score1[nbi-1]==0){
				foslittle.write((-1+"").getBytes());
			}else{
			foslittle.write(Long.toString(100*(F.fSomme(i)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			foslittle.write((" ").getBytes());
			foslittle.write((" "+0+"\n").getBytes() );
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreAlea = SolutionAlea.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosAlealittle.write((nbi+" ").getBytes());
			fosAlealittle.write(Long.toString(F.fSomme(i,ordreAlea)).getBytes());
			fosAlealittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosAlealittle.write((-1+"").getBytes());
			}else{
			fosAlealittle.write(Long.toString(100*(F.fSomme(i,ordreAlea)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosAlealittle.write((" ").getBytes());
			fosAlealittle.write(Long.toString(diff).getBytes());		
			fosAlealittle.write(("\n").getBytes() );	
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreEDD = SolutionEDD.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosEDDlittle.write((nbi+" ").getBytes());
			fosEDDlittle.write(Long.toString(F.fSomme(i,ordreEDD)).getBytes());
			fosEDDlittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosEDDlittle.write((-1+"").getBytes());
			}else{
			fosEDDlittle.write(Long.toString(100*(F.fSomme(i,ordreEDD)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosEDDlittle.write((" ").getBytes());
			fosEDDlittle.write(Long.toString(diff).getBytes());		
			fosEDDlittle.write(("\n").getBytes() );		
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreMDD =SolutionMDD.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosMDDlittle.write((nbi+" ").getBytes());
			fosMDDlittle.write(Long.toString(F.fSomme(i,ordreMDD)).getBytes());
			fosMDDlittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosMDDlittle.write((-1+"").getBytes());
			}else{
			fosMDDlittle.write(Long.toString(100*(F.fSomme(i,ordreMDD)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosMDDlittle.write((" ").getBytes());
			fosMDDlittle.write(Long.toString(diff).getBytes());		
			fosMDDlittle.write(("\n").getBytes() );	
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreRend =SolutionRend.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosRendlittle.write((nbi+" ").getBytes());
			fosRendlittle.write(Long.toString(F.fSomme(i,ordreRend)).getBytes());
			fosRendlittle.write((" ").getBytes());
			
			if(score1[nbi-1]==0){
				fosRendlittle.write((-1+"").getBytes());
			}else{
			fosRendlittle.write(Long.toString(100*(F.fSomme(i,ordreRend)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosRendlittle.write((" ").getBytes());
			
			fosRendlittle.write(Long.toString(diff).getBytes());		
			fosRendlittle.write(("\n").getBytes() );	
			
			
			
			
		
				
				
			
			
			

		}
			
			
			
		

		
		FileOutputStream fosBig = new FileOutputStream(new File("ResultatBig.txt"));
		FileOutputStream fosAleaBig = new FileOutputStream(new File("ResultatAleaBig.txt"));
		FileOutputStream fosEDDBig = new FileOutputStream(new File("ResultatEDDBig.txt"));
		FileOutputStream fosMDDBig = new FileOutputStream(new File("ResultatMDDBig.txt"));
		FileOutputStream fosRendBig = new FileOutputStream(new File("ResultatRendBig.txt"));
		
		
		for (int nbBi = 1;nbBi<6;nbBi++){
			Instance i2 = SearchInstance.search(1000,""+nbBi);
			Instance i2bis = SearchInstance.search(1000,""+nbBi);
			
			
			fosBig.write((nbBi+" ").getBytes());
			fosBig.write(Long.toString(F.fSomme(i2)).getBytes());
			if(score[nbBi-1]==0){
				fosBig.write((-1+"").getBytes());
			}else{
			fosBig.write(Long.toString(100*(F.fSomme(i2)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosBig.write((" ").getBytes());
			fosBig.write((" "+0+"\n").getBytes() );
			
			debut = System.currentTimeMillis();
			int[] ordreAlea = SolutionAlea.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosAleaBig.write((nbBi+" ").getBytes());
			fosAleaBig.write(Long.toString(F.fSomme(i2,ordreAlea)).getBytes());
			fosAleaBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosAleaBig.write((-1+"").getBytes());
			}else{
			fosAleaBig.write(Long.toString(100*(F.fSomme(i2,ordreAlea)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosAleaBig.write((" ").getBytes());
			fosAleaBig.write(Long.toString(diff).getBytes());		
			fosAleaBig.write(("\n").getBytes() );
			
			
			debut = System.currentTimeMillis();
			int[] ordreEDD = SolutionEDD.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosEDDBig.write((nbBi+" ").getBytes());
			fosEDDBig.write(Long.toString(F.fSomme(i2,ordreEDD)).getBytes());
			fosEDDBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosEDDBig.write((-1+"").getBytes());
			}else{
			fosEDDBig.write(Long.toString(100*(F.fSomme(i2,ordreEDD)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosEDDBig.write((" ").getBytes());
			fosEDDBig.write(Long.toString(diff).getBytes());		
			fosEDDBig.write(("\n").getBytes() );
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreMDD =SolutionMDD.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosMDDBig.write((nbBi+" ").getBytes());
			fosMDDBig.write(Long.toString(F.fSomme(i2,ordreMDD)).getBytes());
			fosMDDBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosMDDBig.write((-1+"").getBytes());
			}else{
			fosMDDBig.write(Long.toString(100*(F.fSomme(i2,ordreMDD)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosMDDBig.write((" ").getBytes());
			fosMDDBig.write(Long.toString(diff).getBytes());		
			fosMDDBig.write(("\n").getBytes() );	
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreRend =SolutionRend.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosRendBig.write((nbBi+" ").getBytes());
			fosRendBig.write(Long.toString(F.fSomme(i2,ordreRend)).getBytes());
			fosRendBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosRendBig.write((-1+"").getBytes());
			}else{
			fosRendBig.write(Long.toString(100*(F.fSomme(i2,ordreRend)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosRendBig.write(Long.toString(diff).getBytes());		
			fosRendBig.write(("\n").getBytes() );
			
			
			
			
			
			
			
			
			
		}
		
		foslittle.close() ;
		fosAlealittle.close() ;
		fosEDDlittle.close()  ;
		fosMDDlittle.close() ;
		fosRendlittle.close() ;
		fosBig.close() ;
		fosAleaBig.close() ;
		fosEDDBig.close()  ;
		fosMDDBig.close() ;
		fosRendBig.close() ;
		
		
	}
	
}
