package TP1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class MA {
	
	
	public static int[] Ma(Instance i,int taillePopulation,int NbGeneration,double cRate,double pmut) throws IOException{
		
		ArrayList<int[]> populationInit = GA.Population(i,taillePopulation);
	
		
		
		for (int g=1;g<NbGeneration;g++){
			ArrayList<int[]> populationO = new ArrayList<int[]>();
			
			for (int k = 1;k<cRate*taillePopulation;k++){
					int[] O = null;
					Collections.shuffle(populationInit);
					int[] parent1 = populationInit.get(0);
					int[] parent2 = null;
					
					int cpt = 1;
					while((parent2 =populationInit.get(cpt))==parent1&&cpt<populationInit.size()-1){
						cpt++;
					}
					
					if(parent2 ==null){
						O= parent1;
					}else{
						O = CrossOver(parent1,parent2);
						
					}
					if(Math.random()<pmut){
						O = Mutation(O);
					}
					O = HillClimbing.smtWTP(Instance.transfo(O), 0, 0, 1);
					populationO.add(O);
			}
			populationInit = Remplacement(i,populationInit,populationO);
			
			
		}
		return GA.bestPop(populationInit,i);
	
	}

	private static ArrayList<int[]> Remplacement(Instance i,
			ArrayList<int[]> populationInit, ArrayList<int[]> populationO) {
		
		return GA.MAJ(i, populationInit, populationO, new ArrayList<int[]>()) ;
	}

	private static int[] Mutation(int[] o) {
		int deb = (int) (Math.random() * o.length);;
		int fin = (int) (Math.random() * o.length);;
		return HillClimbing.swap(o, deb, fin);
		
	}

	private static int[] CrossOver(int[] parent1, int[] parent2) {
		int[] res = new int[parent1.length];
		
		int rand = (int) (Math.random() * parent1.length);
		
		
		for(int i =0 ; i<parent1.length;i++){
			
			if(i < rand){
				res[i]=parent1[i];
			}else{
				res[i]=parent2[i];
			}
			
		}
		
		return res;
	}

}
