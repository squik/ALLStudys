package TP1;

public class F {
	
	public static long fSomme (Instance instance){
		long temps = 0 ;
		long res = 0;
		
		for (int i =0 ;i<instance.date.length;i++){
			temps+= instance.timeTraitement[i];
			res+= instance.weight[i] * Math.max(temps-instance.date[i], 0);
		}		
		return res;		
	}
	
	public static long fSomme (Instance instance,int[] ordre){
		long temps = 0 ;
		long res = 0;
		
		for (int i : ordre){
			temps+= instance.timeTraitement[i];
			res+= instance.weight[i] * Math.max(temps-instance.date[i], 0);
		}		
		return res;		
	}
	

}
