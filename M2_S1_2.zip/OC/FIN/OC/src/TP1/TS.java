package TP1;

import java.io.IOException;
import java.util.ArrayList;

public class TS {

	
	public TS(){
		
	}
	
	public static Instance TS(Instance i,int choixvoisin,ArrayList<int[]> tabou ,ArrayList<Integer> deb,ArrayList<Integer> fin) throws IOException{
		
		
		
		
		int[] ordre = SolutionMDD.solution(i);
		i= i.transfo(ordre);	
		
		
		int cptAction = 0;
		
		
		while(cptAction < 20){
			System.out.println(cptAction);
			
			ArrayList<int[]> voisin = HillClimbing.voisin(ordre, choixvoisin);
			voisin.addAll(HillClimbing.voisin(ordre, 0));
			voisin.addAll(HillClimbing.voisin(ordre, 1));
			voisin.addAll(HillClimbing.voisin(ordre, 2));

			voisin = ReduceVoisin( voisin,tabou , deb, fin);
			if (voisin == null){
				return i;
			}
			
			ordre = bestvoisin(voisin,i);
			
			if(ordre ==null){
				return i;
			
			}
			ajouteAlea (ordre , tabou , deb, fin);
			i = i.transfo(ordre);			
			
			
			
			++cptAction;
		}
		
		return i;
		
	}
	
	public static void ajouteAlea (int[] ordre ,ArrayList<int[]> tabou ,ArrayList<Integer> deb,ArrayList<Integer> fin){
		
		int n1 = (int) Math.random() * ordre.length ;
		int n2 = (int) Math.random() * ordre.length ;
		
		int de=0;
		int fe =0;
		
		if(n1>n2){
			de = n2;
			fe =n1;
		}else{
			fe = n2;
			de =n1;
		}
		
		if(n2==n1){
			return ;
		}
		
		int[] res = new int[fe-de];
		int cpt =0;
		for (int i = de;i<fe;i++){
			res[cpt]=ordre[i];
			cpt++;
		}
		
		
		
		tabou.add(res);
		deb.add(de);
		fin.add(fe);
		
		
	}
	
	
	public static int[] bestvoisin(ArrayList<int[]> voisi,Instance i) {
		
		long  res = F.fSomme(i);
		int[] ordre = null ;
		ArrayList<int[]> voisin= (ArrayList<int[]>) voisi.clone();
		
		
		while (!voisin.isEmpty()){		
				
				int[] voisinChoisi = voisin.get(0);
				long res2 = F.fSomme(i,voisinChoisi);
				
				if(res2<res ){		
					ordre = voisin.get(0);
					res=res2;
				}else{
					voisin.remove(voisinChoisi);
				}	
			
			}	
		
		return ordre;
	}
	
	public static  boolean estPasComposante(int[] comp,ArrayList<int[]> tabou ,ArrayList<Integer> deb,ArrayList<Integer> fin){
	
		for (int i=0 ; i< tabou.size();i++){
			
			boolean res_interm = true;
			
			for(int j = deb.get(i);j< fin.get(i) ;j++ ){
				
				if(tabou.get(i)[j] != comp[j]){
						res_interm = false;
				}
				
			}
			
			if(!res_interm){
				return false;
			}
			
		}
		
		return true;
		
		
	}
	
	
	
	
	public static ArrayList<int[]> ReduceVoisin(ArrayList<int[]> voisin,ArrayList<int[]> tabou ,ArrayList<Integer> deb,ArrayList<Integer> fin){
		
		ArrayList<int[]> res = new ArrayList<int[]>();
		
		for ( int[] comp : voisin){
			if( estPasComposante(comp,tabou,deb,fin)){
				res.add(comp);
			}
		}
		
		
		return res;
		
	}
	
	

}
