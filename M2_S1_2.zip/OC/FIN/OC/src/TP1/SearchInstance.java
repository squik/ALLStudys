package TP1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class SearchInstance {
	
	
	public static Instance search(int nbInstance,int nbTaille) throws IOException{
		int[] timetraitement = new int[nbTaille];
		int[] weight = new int[nbTaille];
		int[] date = new int[nbTaille];
		
		FileInputStream flux= new FileInputStream("C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\wt100.txt");
		InputStreamReader lecture=new InputStreamReader(flux);
		BufferedReader buff=new BufferedReader(lecture);
		String ligne;
		String nbTimeTraitement ="";
		String nbWeight="";
		String nbDate="";
		
		
		int cpt = 0;
		int cpt_ligne =0;
		int launch = (nbInstance-1) *15 ;
		int stop = (nbInstance-1) *15 +14;
		while ((ligne=buff.readLine())!=null){
			
			
			if (cpt <= stop & cpt >= launch){
				
			//System.out.println(ligne);
				
				if (cpt_ligne < 5 & cpt_ligne >= 0){
					nbTimeTraitement += ligne ;
				}
				if (cpt_ligne < 10 & cpt_ligne >= 5){
					nbWeight+=ligne;
				}
				if (cpt_ligne < 15 & cpt_ligne >= 10){
					nbDate+= ligne ;
				}
				cpt_ligne++;
			}
			cpt++;
		}
		buff.close(); 
		
		
		timetraitement= transform(nbTimeTraitement,nbTaille);
		weight =transform(nbWeight,nbTaille);
		date = transform(nbDate,nbTaille);
		
		/*
		System.out.println(timetraitement[99]);
		System.out.println(weight[99]);
		System.out.println(date[99]);
		*/
		
		return new Instance(timetraitement,weight,date);
		
	}
	
	public static Instance search(int nbTaille,String nom) throws IOException{
		int[] timetraitement = new int[nbTaille];
		int[] weight = new int[nbTaille];
		int[] date = new int[nbTaille];
		
		FileInputStream flux= new FileInputStream("C:\\Users\\chad\\Downloads\\OC\\src\\TP1\\instances\\wt_1000_"+nom+".txt");
		InputStreamReader lecture=new InputStreamReader(flux);
		BufferedReader buff=new BufferedReader(lecture);
		String ligne;

		int cpt_ligne =0;
		
		
		while ((ligne=buff.readLine())!=null){
			
			if (cpt_ligne <nbTaille){
			
			timetraitement[cpt_ligne]=Integer.parseInt( ligne.split(",")[0]);
			weight[cpt_ligne]=Integer.parseInt( ligne.split(",")[1]);
			date[cpt_ligne]=Integer.parseInt( ligne.split(",")[2]);
			cpt_ligne++;
			}
		}
		
		
		return new Instance(timetraitement,weight,date);
	
	}

	public static int[] transform(String s,int nbTaille){
		int[] res = new int[nbTaille];
		String[] reg = s.split("[^0-9]") ;
		int tot = 0;
		for (String sa : reg){
			try{			
			
				res[tot]=Integer.valueOf(sa);
				tot++;			
			}
			catch(Exception e){
				
			}
		}
		return res;
		
	}

	
}
