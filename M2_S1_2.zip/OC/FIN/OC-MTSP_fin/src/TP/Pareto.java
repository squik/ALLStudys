package TP;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Pareto {
	
	
	public static ArrayList<int[]> pareto(Instance i,int nbObjectif,int nbItera) throws IOException{

	ArrayList<int[]> tabAlea = new ArrayList<int[]>();
	
	ArrayList<int[]> res =new ArrayList<int[]>();
	
	for (int k =0;k<500;k++){
		tabAlea.add(Alea.solution(i));
	}
	boolean[] max = new boolean[2];
	max[0]=true;
	max[1]=true;
	res = ONLine.onLine(i,tabAlea,max,2);

	for (int ite =0 ;ite<nbItera;ite++) {
		
		ArrayList<int[]> resinterm =new ArrayList<int[]>();
		resinterm.addAll(res);
		for(int[] resordre : res) {
			Random t = new Random();
			int a =t.nextInt(i.getTaille());
			int b =t.nextInt(i.getTaille());
			resinterm.add(HillClimbing.echange(resordre , Math.min(a, b) , Math.max(a, b)));
		}
		
		res = ONLine.onLine(i,resinterm,max,2);
	}
	
	
	
	return res;
	}
}
