package TP;

import java.util.ArrayList;

public class ONLine {
	
	
	public static ArrayList<int[]> onLine(Instance inst ,ArrayList<int[]> solution,boolean[] maxim,int nbObjectif){
		
		ArrayList<int[]> res = new ArrayList<int[]>();
		
		for (int[] sol : solution){
			
			/*boolean domine = true;
			for (int i =1; i<nbObjectif+1;i++){
				
				domine = domine && search(inst,res,sol,maxim[i-1],i) ;
				
			}
			
			if(!domine){*/
			
			    res.add(sol);
				res = MAJ(inst,res,maxim,nbObjectif,sol);
				
				
			//}
			
		}
		
		
		return res;
		
	}
	
	public static ArrayList<int[]> MAJ(Instance inst ,ArrayList<int[]> solution,boolean[] maxim,int nbObjectif,int[] sol){		
		
		ArrayList<int[]> Asupprime = new ArrayList<int[]>();
		
		for (int[] solRes : solution){
			
			if (OFFLine.equivalent(solRes, sol)){
				continue;
			}
			
			boolean domine = true;
			boolean dominited = true;
			
			for (int i =1; i<nbObjectif+1;i++){
				
				long eval = Eval.fSomme(inst, i, sol);
				long evalRes = Eval.fSomme(inst, i, solRes);
				
				if(maxim[i-1]){
					
					if(evalRes>eval){
						domine = false  ;
					}
					if(eval>evalRes){
						dominited = false  ;
					}
					
				}else{
					
					if(evalRes<eval){
						domine = false;
						
					}
					if(eval<evalRes){
						dominited = false  ;
					}
					
				}
				
				
			}
			
			if(domine){
				Asupprime.add(solRes);
			}
			if(dominited){
				Asupprime.add(sol);
			}
			
		}
		for (int[] solsupp : Asupprime){
			solution.remove(solsupp);
		}
		
		
		return solution;
		
	}
	
	
	public static boolean search(Instance inst,ArrayList<int[]> res,int[] sol,boolean maxim,int numObjectif){
		
		long eval = Eval.fSomme(inst, numObjectif, sol);
		
		for (int[] solRes : res){
			
			long evalRes = Eval.fSomme(inst, numObjectif, solRes);
			
			if(maxim){
				if(evalRes>eval){
					return true;
				}
			}else{
				if(evalRes < eval){
					return true;
				}			

			}
			
		}	
		
		return false;
	}
}
