package TP;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;






public class SearchInstance {
	
	public static Instance search(String name1,String name2,int taille) throws IOException{
	
	FileInputStream flux= new FileInputStream("C:\\Users\\chad\\Downloads\\OC-MTSP\\OC-MTSP\\src\\TP\\"+name1);
	InputStreamReader lecture=new InputStreamReader(flux);
	BufferedReader buff=new BufferedReader(lecture);
	String ligne;
	
	FileInputStream flux2= new FileInputStream("C:\\Users\\chad\\Downloads\\OC-MTSP\\OC-MTSP\\src\\TP\\"+name2);
	InputStreamReader lecture2=new InputStreamReader(flux2);
	BufferedReader buff2=new BufferedReader(lecture2);
	String ligne2;
	
	ArrayList<ArrayList<int[]>> res = new ArrayList<ArrayList<int[]>>();
	
	ArrayList<int[]> interm = new ArrayList<int[]>();
	
	int cpt = 0;
	
	for (int i =0 ;i<7;i++){
		ligne=buff.readLine();
		ligne2=buff2.readLine();
	}
	
	while ((ligne=buff.readLine())!=null){
		ligne2=buff2.readLine();	
		
		int[] obj=new int[2];
		
		obj[0] = Integer.parseInt(ligne);
		obj[1] = Integer.parseInt(ligne2);
		
		interm.add(obj);
		
		++cpt;
		if(cpt == taille){
			cpt=0;
			--taille;			
			res.add(interm);
			interm = new ArrayList<int[]>();
		}
		
	
		
	}

	
	return new Instance(res);
	}

}
