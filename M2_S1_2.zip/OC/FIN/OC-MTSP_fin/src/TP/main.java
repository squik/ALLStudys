package TP;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Instance i = SearchInstance.search("randomA100.tsp","randomB100.tsp",100);
		
		//System.out.println(i.getVal(1, 3, 2));
		
		int[] solAlea= Alea.solution(i);
		
		imprimeordre(solAlea);
		
		System.out.println(Eval.fSomme(i, 1, solAlea));
		System.out.println(Eval.fSomme(i, 2, solAlea));
		
		
		ArrayList<int[]> tabAlea = new ArrayList<int[]>();
		
		for (int k =0;k<500;k++){
			tabAlea.add(Alea.solution(i));
		}
		
		FileOutputStream AleaALL = new FileOutputStream(new File("AleaALL.txt"));
		FileOutputStream AleaOffLine = new FileOutputStream(new File("AleaOFFline.txt"));
		FileOutputStream AleaONLine = new FileOutputStream(new File("AleaONline.txt"));
		FileOutputStream Scalarfile = new FileOutputStream(new File("Scalar.txt"));
		FileOutputStream paretofile = new FileOutputStream(new File("pareto.txt"));
		
		boolean[] max = new boolean[2];
		max[0]=true;
		max[1]=true;
		
		long debut,diff;
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> tabAleaOff = OFFLine.offLine(i,tabAlea,max,2);
		diff = System.currentTimeMillis()-debut;
		
		System.out.println("timeOff : "+diff);
		
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> tabAleaON = ONLine.onLine(i,tabAlea,max,2);
		diff = System.currentTimeMillis()-debut;
		
		System.out.println("timeOn : "+diff);
		
		
		for(int[] sol1 : tabAlea ){
			
			AleaALL.write(Long.toString(Eval.fSomme(i, 1, sol1)).getBytes());
			AleaALL.write(" ".getBytes());
			AleaALL.write(Long.toString(Eval.fSomme(i, 2, sol1)).getBytes());
			AleaALL.write("\n".getBytes());
			
		}
		for(int[] sol2 : tabAleaON ){
			
			AleaONLine.write(Long.toString(Eval.fSomme(i, 1, sol2)).getBytes());
			AleaONLine.write(" ".getBytes());
			AleaONLine.write(Long.toString(Eval.fSomme(i, 2, sol2)).getBytes());
			AleaONLine.write("\n".getBytes());
	
		}
		for(int[] sol3 : tabAleaOff ){
			
			AleaOffLine.write(Long.toString(Eval.fSomme(i, 1, sol3)).getBytes());
			AleaOffLine.write(" ".getBytes());
			AleaOffLine.write(Long.toString(Eval.fSomme(i, 2, sol3)).getBytes());
			AleaOffLine.write("\n".getBytes());
	
		}
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> paretotab = Pareto.pareto( i,2,5);
		diff = System.currentTimeMillis()-debut;
		
		for(int[] paretoordre :paretotab ){
			
			paretofile.write(Long.toString(Eval.fSomme(i, 1, paretoordre)).getBytes());
			paretofile.write(" ".getBytes());
			paretofile.write(Long.toString(Eval.fSomme(i, 2, paretoordre)).getBytes());
			paretofile.write("\n".getBytes());
			
			
				
			
		}
		int[] front =new int[2];
		front[0] = 350000;
		front[1]=350000;
		System.out.println("qualite : "+Long.toString(Hypervolume.calculvolume2D(paretotab,front)));
		
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> scalartab = Scalar.Scalar( i,2);
		diff = System.currentTimeMillis()-debut;
		
		for(int[] scalarordre : scalartab ){
			
			Scalarfile.write(Long.toString(Eval.fSomme(i, 1, scalarordre)).getBytes());
			Scalarfile.write(" ".getBytes());
			Scalarfile.write(Long.toString(Eval.fSomme(i, 2, scalarordre)).getBytes());
			Scalarfile.write("\n".getBytes());
	
		}
		
	
		
		Scalarfile.close();
		AleaALL.close() ;
		AleaOffLine.close() ;
		AleaONLine.close() ;
		paretofile.close();
		
		System.out.println("skyfalll this is the end");

	}
	
	public static void imprimeordre(int[] tab){
		
		for (int t  :tab ){
			System.out.print(t+" -> ");
			}
			System.out.println();
		
		
	}

}
