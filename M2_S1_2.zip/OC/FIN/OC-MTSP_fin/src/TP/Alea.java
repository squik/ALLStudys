package TP;

import java.util.ArrayList;
import java.util.Collections;

public class Alea {
	
	
	
	public static int[] solution(Instance i){
		int[] resultat = new int[i.getTaille()];
		ArrayList<Integer> interm = new ArrayList<Integer>();

		for (int nb=1 ;nb<i.getTaille()+1;nb++){
			interm.add(nb);
		}
		Collections.shuffle(interm);
		int cpt = 0;
		
		while(!interm.isEmpty()){
			
			resultat[cpt]=interm.get(0);
			cpt++;
			interm.remove(0);
		}
		

		return resultat;
		
	}

}
