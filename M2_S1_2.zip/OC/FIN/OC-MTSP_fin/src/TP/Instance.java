package TP;
import java.util.ArrayList;


public class Instance {
	
	ArrayList<ArrayList<int[]>> matrice;
	
	
	public Instance(ArrayList<ArrayList<int[]>> mat){
		matrice = mat;
	}
	
	public int getVal(int numObj,int numDep,int numArr){
		

		try{
		return matrice.get(numDep-1).get(numArr -(numDep))[numObj-1];
		}catch(java.lang.IndexOutOfBoundsException e){
			
			
			return matrice.get(numArr-1).get(numDep -(numArr))[numObj-1];
		}
		
	}
	
	public int getTaille(){
		return matrice.size();
	}

}
