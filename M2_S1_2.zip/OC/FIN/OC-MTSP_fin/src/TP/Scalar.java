package TP;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Scalar {

	
	/*
	 * 
	 */
	
	public static ArrayList<int[]> Scalar(Instance i,int nbObjectif) throws IOException{
		

	ArrayList<int[]> tabAlea = new ArrayList<int[]>();
	
	ArrayList<int[]> res =new ArrayList<int[]>();
	
	for (int k =0;k<500;k++){
		tabAlea.add(Alea.solution(i));
	}
	
	
	ArrayList<int[]> poids = new ArrayList<int[]>();
	int[] tabpoid = new int[2] ;
	
	for(int nomb = 0;nomb<10;nomb++) {
		Random t = new Random();
		tabpoid[0]=t.nextInt();
		tabpoid[1]=t.nextInt();
		poids.add(tabpoid);
	}
	
	
		
		for (int[] poid :poids) {
			
			res.add(HillClimbing.smtWTP( i, 0,0,0,poid));
		}
	
	
	boolean[] max = new boolean[2];
	max[0]=true;
	max[1]=true;
	return ONLine.onLine(i,res,max,2);
	}
}
