package TP;

import java.util.ArrayList;

public class Hypervolume {
	
	
	public static long calculvolume2D(ArrayList<int[]> frontParetoTrieCroissantY,int[] pointDominant) {
		long res = 0;
		
		int[] points = pointDominant;
		for (int[] tab :frontParetoTrieCroissantY ) {
			
			res += (points[0]-tab[0] )*(points[1]-tab[1]);
			points[1]=tab[1];
		}
		
		
		return res;
		
	}

}
