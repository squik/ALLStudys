package TP;

import java.util.ArrayList;

public class OFFLine {
	
	
	public static ArrayList<int[]> offLine2(Instance inst ,ArrayList<int[]> solution,boolean[] maxim,int nbObjectif){
		
		ArrayList<int[]> res = (ArrayList<int[]>) solution.clone();
		ArrayList<int[]> Asupprime = new ArrayList<int[]>();
		
		for (int k = 0;k<solution.size();k++){
			
			if(k>res.size()-1){
				break;
			}
			
			for (int k2 = 0 ;k2<solution.size();k2++){
				
				if(k2>res.size()-1)				{
					break;
				}
				
				
				boolean domine = true;
				
				for (int i =1; i<nbObjectif+1;i++){
					
					long eval = Eval.fSomme(inst, i, solution.get(k));
					long evalRes = Eval.fSomme(inst, i, solution.get(k2));
					
					if(maxim[i-1]){
						
						if(evalRes>eval){
							domine = false  ;
						}				
						
					}else{
						
						if(evalRes<eval){
							domine = false;
							
						}
						
					}
										
					
				}
				
				if(domine){
					Asupprime.add(solution.get(k2));
				}
				
				
			}
			
		
			
		
			
		}
		for (int[] supp : Asupprime){
			res.remove(supp);
		}
		
		return res;
		
	}
	
	public static ArrayList<int[]> offLine(Instance inst ,ArrayList<int[]> solution,boolean[] maxim,int nbObjectif){
		
		ArrayList<int[]> res = (ArrayList<int[]>) solution.clone();
		ArrayList<int[]> Asupprime = new ArrayList<int[]>();
		
		for (int[] sol : solution){	
			Asupprime = new ArrayList<int[]>();
			
			for(int[] solRes : res){
				
				boolean domine = true;
				if(!equivalent(solRes,sol)){
					
					
					for (int i =1; i<nbObjectif+1;i++){
						
						long eval = Eval.fSomme(inst, i, sol);
						long evalRes = Eval.fSomme(inst, i, solRes);
						
						if(maxim[i-1]){
							
							if(evalRes>eval){
								domine = false  ;
							}				
							
						}else{
							
							if(evalRes<eval){
								domine = false;
								
							}
							
						}
											
						
					}
					
					if(domine){
						Asupprime.add(solRes);
					}
				}
				
			}
			
			for (int[] supp : Asupprime){
				res.remove(supp);
			}
			
		
			
		}
		
		
		return res;
		
	}
	
	public static boolean equivalent(int[] ord1,int[] ord2){
		
		if(ord1.length != ord2.length){
			return false;
		}
		
		for (int i = 0;i<ord1.length;i++){
			if(ord1[i]!=ord2[i]){
				return false;
			}
		}
		return true;
	}

}
