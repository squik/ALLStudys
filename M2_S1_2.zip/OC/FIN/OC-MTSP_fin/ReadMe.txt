

Guillaume Maitrot


./generate-gnuplot.sh ou pareto.sh sert a créer les gnuplots des données.



le main se trouve dans 

~/OC-MTSP_fin/src/TP

les donnés des Instances se trouvent dans 

~/OC-MTSP_fin/src/TP

Pour executer le main il faut modifier dans SearchInstance.java le chemin de

"C:\\Users\\chad\\Downloads\\OC-MTSP\\OC-MTSP\\src\\TP\\"+name1

et 

"C:\\Users\\chad\\Downloads\\OC-MTSP\\OC-MTSP\\src\\TP\\"+name2
