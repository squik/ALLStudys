#!/bin/bash

if [ $# -ne 3 ]
then
	echo "usage : ./generate-gnuplot.sh titre  output.png datafile1 "
	exit -1
fi

gnuplot <<EOF
set title  '$1'

set palette defined (1 "black")

set terminal png
set output '$2'
plot "$3" using 1:2 with points

EOF
