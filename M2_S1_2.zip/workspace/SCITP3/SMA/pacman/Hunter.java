package pacman;

import java.awt.Color;

import core.Agent;
import core.Position;

public class Hunter extends Agent{

	private EnvPacman env;
	private int speed = 1;
	private int tick;
	
	public Hunter(EnvPacman env, int seed, boolean trace) {
		super(env, seed, trace, "Hunter");
		this.env = (EnvPacman) env;
		this.color = Color.red;
		this.tick = 0;
	}

	@Override
	public void decide() {
		if (tick == speed){
			Position p = env.getBestPos(this);
			if (p == null) {
				return;
			}
			
			if (env.cellContent(p.getX(), p.getY())!=null){
				System.out.println("OCCUPIED" + env.cellContent(p.getX(), p.getY()));
				if (env.cellContent(p.getX(), p.getY()).getType()=="Avatar" ){
					env.gameOver();
				}
			}
			env.moveAgent(this, p.getX(), p.getY());	
			tick = 0;
		}
		else tick++;
	}

}
