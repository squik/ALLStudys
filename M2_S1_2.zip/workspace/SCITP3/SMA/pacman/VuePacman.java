package pacman;

import core.Environnement;
import core.Vue;

public class VuePacman extends Vue {

	private Avatar a;
	
	public VuePacman(Environnement env, int canvaSizeX, int canvaSizeY, boolean grid, Avatar a) {
		super(env, canvaSizeX, canvaSizeY, grid);
		this.a = a;
		this.addKeyListener(a);
	}

}
