package pacman;

import java.io.IOException;
import java.util.ArrayList;

import core.*;

public class SMAPacman extends SMA{

	private boolean gameOver = false;
	private EnvPacman env;
	private ArrayList<Agent> people;
	private Vue vue;
	
	public SMAPacman(int nbHunters, int nbWalls,
			int delay, int nbTicks, 
			int refresh, boolean grid, int canvaSizeX, 
			int canvaSizeY, int seed,int gridSizeX, int gridSizeY, boolean torus,
			boolean trace, String mode) {
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.people = new ArrayList<Agent>();
		this.env = new EnvPacman (gridSizeX, gridSizeY, torus, this);
		
		Avatar a = new Avatar(env, seed, trace);
		people.add(a);
		env.addAgent(a);
		
		for (int i = 0; i < nbHunters; i++){
			Hunter h = new Hunter(env, seed, trace);
			env.addAgent(h);
			people.add(h);
		}
		
		for (int i = 0; i < nbWalls; i++){
			Wall w = new Wall(env, seed, trace);
			env.addAgent(w);
		}
		this.vue = new VuePacman(env, canvaSizeX, canvaSizeY, grid, a);
	}

	@Override
	public void run()  {
		int step = 0;
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (!gameOver){

			for (Agent player : people){
				System.out.println(step+" : Joueur "+player+" "+player.getPosX()+" "+player.getPosY());
				player.decide();
			}
			
			try {
				vue.initPlateau(env);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (step % refresh == 0) vue.repaint();
			step += 1;

			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			env.TrouvePac();
	    }
	}

	public void gameOver(){
		System.out.println("GAME OVER");
		this.gameOver = true;
	}
	
}
