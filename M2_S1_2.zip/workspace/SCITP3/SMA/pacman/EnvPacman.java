package pacman;

import java.util.ArrayList;
import java.util.Collections;

import core.*;

public class EnvPacman extends Environnement{
	
	private SMAPacman sma;
	private int[][] dijkstra;
	private boolean approche=true;
	
	public EnvPacman(int gridSizeX, int gridSizeY, boolean torus, SMAPacman sma) {
		super(gridSizeX, gridSizeY, torus);
		this.sma = sma;
		this.dijkstra = new int[gridSizeX][gridSizeY];
	}

	public void moveAgent(Agent ag, int x2, int y2){
		int x1 = ag.getPosX();
		int y1 = ag.getPosY();
		
		//agent stay in the environnement
		ag.setPosition(x2, y2);
		addAgent(ag);
		matrice[x1][y1]=null;
	}
	
	
	public void removeAgent(Agent ag){
		matrice[ag.getPosX()][ag.getPosY()]=null;
	}
	
	public void gameOver(){
		sma.gameOver();
	}
	
	public void changeB(){
		this.approche = ! approche;
	}
	
	public Position getBestPos(Hunter h){
		ArrayList<Position> voisin = getngb(h.getPosX(), h.getPosY());
		
		Collections.shuffle(voisin);
		
		
		if(voisin.isEmpty()) return null;
		
		AcotePac(voisin,h);
		AcoteImpr(voisin);
		
		Position max =null; 
		Position min =null;
		for (Position a : voisin){
			
			if (min == null && (matrice[a.getX()][a.getY()] == null || matrice[a.getX()][a.getY()].getType()=="Avatar")){
				min = new Position(a.getX(),a.getY());
			}else {
				if(min != null){
				if(dijkstra[min.getX()][min.getY()] > dijkstra[a.getX()][a.getY()]){
					min = new Position(a.getX(),a.getY());
				}
				}
			}
			
			/*
			if (max == null && (matrice[a.getX()][a.getY()] == null || matrice[a.getX()][a.getY()].getType()=="Avatar")){
				max = new Position(a.getX(),a.getY());
			}else {
				if(max != null){
				if(dijkstra[max.getX()][max.getY()] < dijkstra[a.getX()][a.getY()]){
					max = new Position(a.getX(),a.getY());
				}
				}
			}
			*/
			
			
			if ( (min == null || dijkstra[min.getX()][min.getY()] > dijkstra[a.getX()][a.getY()]) 
					&& (matrice[a.getX()][a.getX()] == null || matrice[a.getX()][a.getX()].getType()=="Avatar")){
				min = new Position(a.getX(),a.getY());
			}
			
		}
		
		if(approche)return min ;
		return max;
	}
	
	public ArrayList<Position> getngb(int posX, int posY){
		ArrayList<Integer> ngb = new ArrayList<Integer>();
		ArrayList<Position> voisins = new ArrayList<Position>();
		int depX=0;
		int depY=0;
		for (int i = 0; i<8; i++) ngb.add(i);
		for (int ng : ngb){
			switch (ng) {			
			case 0:
				depX = -1;
				depY = -1;
				break;
			case 1:
				depX = -1;
				depY = 0;
				break;
			case 2:
				depX = -1;
				depY = 1;
				break;
			case 3:
				depX = 0;
				depY = -1;
				break;
			case 4:
				depX = 0;
				depY = 1;
				break;
			case 5:
				depX = 1;
				depY = -1;
				break;
			case 6:
				depX = 1;
				depY = 0;
				break;
			case 7:
				depX = 1;
				depY = 1;
				break;
				
			default:
				break;
			}
			
			int x2 = (posX + depX + getGridSizeX())%getGridSizeX();
			int y2 = (posY + depY + getGridSizeY())%getGridSizeY();
			
			if (matrice[x2][y2] == null || matrice[x2][y2].getType()=="Avatar"   ){
				voisins.add(new Position(x2,y2));
			}	
		}
		return voisins;
	}	

	public void addVoisins(int posX, int posY, ArrayList<Position> voisin,int cpt){
		ArrayList<Integer> ngb = new ArrayList<Integer>();
		int depX=0;
		int depY=0;
		for (int i = 0; i<8; i++) ngb.add(i);
		for (int ng : ngb){
			switch (ng) {			
			case 0:
				depX = -1;
				depY = -1;
				break;
			case 1:
				depX = -1;
				depY = 0;
				break;
			case 2:
				depX = -1;
				depY = 1;
				break;
			case 3:
				depX = 0;
				depY = -1;
				break;
			case 4:
				depX = 0;
				depY = 1;
				break;
			case 5:
				depX = 1;
				depY = -1;
				break;
			case 6:
				depX = 1;
				depY = 0;
				break;
			case 7:
				depX = 1;
				depY = 1;
				break;
				
			default:
				break;
			}
			
			int x2 = (posX + depX + getGridSizeX())%getGridSizeX();
			int y2 = (posY + depY + getGridSizeY())%getGridSizeY();
			
			
			if ( matrice[x2][y2] == null || matrice[x2][y2].getType()!="Wall"){
				if(dijkstra[x2][y2] == -1){
					voisin.add(new Position(x2,y2));
					dijkstra[x2][y2]=cpt;
				}
			}		
		}
	}	
	
	public void dijkstra(Agent a){
		for (int i=0; i<gridSizeX; i++){
			for (int j=0; j<gridSizeY; j++){
				dijkstra[i][j] = -1;
			}
		}
		ArrayList<Position> voisin = new ArrayList<Position>();
		voisin.add(new Position(a.getPosX(),a.getPosY()));
		int cpt =0;
		dijkstra[a.getPosX()][a.getPosY()]=cpt;
		while (!voisin.isEmpty()){
			ArrayList<Position> voisinInter = (ArrayList<Position>) voisin.clone();
			
			for (Position vois : voisinInter){
				addVoisins(vois.getX(),vois.getY(),voisin,cpt+1);
				
				voisin.remove(vois);
				
			}
			cpt++;
			
		}
		
		
	}
	
	public void TrouvePac(){
		
		
		
		for(int x =0 ; x<matrice.length;x++){
			for(int y =0 ; y<matrice[0].length;y++){
				Agent ag = matrice[x][y];
				if(ag != null && ag.getType()=="Avatar"){
					System.out.println(" moi "+ ag.getPosX() + " " +ag.getPosY() + " mat" + x + " " + y + " mon disj " +dijkstra[x][y] );
				}
				
			}
			
		}	
	}
	
	
	public void AcoteImpr(ArrayList<Position> voisin){
		
		for(Position p : voisin){
			
			System.out.println ( matrice[p.getX()][p.getY()] + " les valeurs " + dijkstra[p.getX()][p.getY()]);
		}
	}
	
	public void AcotePac(ArrayList<Position> voisin,Agent h){
		
		
		Agent ag =h ;
		System.out.println(" moi HUNTER "+ ag.getPosX() + " " +ag.getPosY() + " mat" +ag.getPosX() + " " +ag.getPosY()  + " mon disj " +dijkstra[ag.getPosX()][ag.getPosY() ] );
		
		for(Position p : voisin){
				ag = matrice[p.getX()][p.getY()];
				if(ag != null && ag.getType()=="Avatar"){
					System.out.println(" J'ai trouve le p");
					System.out.println(" moi HUNTER MANGE "+ ag.getPosX() + " " +ag.getPosY() + " mat" + p.getX() + " " + p.getY() + " mon disj " +dijkstra[p.getX()][p.getY()]) ;

					
				
					
				
				}
			
			
		}	
	}
	
}
