package pacman;

import java.awt.Color;

import core.Agent;
import core.Environnement;

public class Leurre extends Agent{

	
	public Leurre(Environnement env, int seed, boolean trace) {
		super(env, seed, trace, "Wall");
		this.color = Color.green;
	}

	@Override
	public void decide() {
		
	}

}
