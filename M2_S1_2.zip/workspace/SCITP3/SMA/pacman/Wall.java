package pacman;

import java.awt.Color;

import core.Agent;
import core.Environnement;

public class Wall extends Agent{

	
	public Wall(Environnement env, int seed, boolean trace) {
		super(env, seed, trace, "Wall");
		this.color = Color.gray;
	}

	@Override
	public void decide() {
		
	}

	
	
}
