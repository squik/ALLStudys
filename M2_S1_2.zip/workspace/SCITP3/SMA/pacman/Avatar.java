package pacman;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import core.Agent;
import core.Environnement;

public class Avatar extends Agent implements KeyListener{

	private int directionX=0;
	private int directionY=0;
	private boolean leurre = false;
	private Agent leurreman = null ;
	private int cptleurre = 0;
	private EnvPacman env;
	
	
	public Avatar(Environnement env, int seed, boolean trace) {
		super(env, seed, trace, "Avatar");
		this.env = (EnvPacman) env;
		this.color = Color.blue;
	}

	
	public void keyTyped(KeyEvent e) {
		//System.out.println("KEY TYPED");
		}

	
	public void keyPressed(KeyEvent e) {
		System.out.println("KEY PRESSED"+KeyEvent.getKeyText(e.getKeyCode()));
		switch(KeyEvent.getKeyText(e.getKeyCode())){
		case "Z" : {
			directionX = -1;
			directionY = 0;
			break;
		}
		case "Q" : {
			directionX = 0;
			directionY = -1;
			break;
		}
		case "S" : {
			directionX = 1;
			directionY = 0;
			break;
		}
		case "D" : {
			directionX = 0;
			directionY = 1;
			break;
		}
		case "P" : {
			leurre = true;
			cptleurre= 5;
		}
		case "E" : {
			env.changeB();
		}
		default :break;
		}
		
	}

	
	public void keyReleased(KeyEvent e) {
		//System.out.println("KEY RELEASED");
		}

	
	public void decide() {

		System.out.println("Joueur decide");
		int x1 = this.posx ;
		int y1 = this.posy; 
		int x2 = (this.posx + this.directionX + env.getGridSizeX())%env.getGridSizeX();
		int y2 = (this.posy + this.directionY + env.getGridSizeY())%env.getGridSizeY();
		
		Agent ag = env.cellContent(x2, y2);
		if (ag == null){		
			if (this.directionX !=0 || this.directionY !=0){
				env.moveAgent(this, x2, y2);
			}
		}
		else if (ag.getType() == "Hunter"){
			env.gameOver();
			return;
		}
		System.out.println("Joueur dijsktra");
		
		if(leurre){
			
			if(cptleurre == 5){
				if(leurreman ==null){
				leurreman = new Leurre(env,0,trace);
				env.addAgent(leurreman);
				}
			}
			
			env.dijkstra(leurreman);
			
			if(cptleurre ==1){
				env.dijkstra(this);
				env.removeAgent(leurreman);
				leurreman = null ;
				leurre = false;
				
			}
			cptleurre--;
			
		}else {
		
		env.dijkstra(this);}

		System.out.println("Joueur has finish");
	}

}
