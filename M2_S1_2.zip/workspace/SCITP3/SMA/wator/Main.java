package wator;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Main{
	
	public static SMAWator readProperties() throws IOException{

		// create and load default properties
		Properties defaultProps = new Properties();
	
		defaultProps.put("gridSizeX", "15");
		defaultProps.put("gridSizeY", "15");
		defaultProps.put("torus", "true");
		defaultProps.put("nbFishes", "10");
		defaultProps.put("nbSharks", "10");
		defaultProps.put("fishBreedTime", "5");
		defaultProps.put("sharkBreedTime", "5");
		defaultProps.put("sharkStarveTime", "5");
		defaultProps.put("delay", "1200");
		defaultProps.put("nbTicks", "1000000");
		defaultProps.put("refresh", "1");
		defaultProps.put("seed", "0");
		defaultProps.put("canvaSizeX", "0");
		defaultProps.put("canvaSizeY", "0");
		defaultProps.put("grid", "false");
		defaultProps.put("trace", "true");
		defaultProps.put("mode", "E");
		FileInputStream in = new FileInputStream("defaultProperties");
		defaultProps.load(in);
		in.close();
	
		int nbSharks = Integer.parseInt(defaultProps.getProperty("nbSharks"));
		int nbFishes = Integer.parseInt(defaultProps.getProperty("nbFishes"));
		int fishBreedTime = Integer.parseInt(defaultProps.getProperty("fishBreedTime"));
		int sharkBreedTime = Integer.parseInt(defaultProps.getProperty("sharkBreedTime")); 
		int sharkStarveTime = Integer.parseInt(defaultProps.getProperty("sharkStarveTime"));
	    return new SMAWator(nbSharks, nbFishes,
	    		fishBreedTime, sharkBreedTime, sharkStarveTime,
	    		Integer.parseInt(defaultProps.getProperty("gridSizeX")), Integer.parseInt(defaultProps.getProperty("gridSizeY")), Boolean.parseBoolean(defaultProps.getProperty("torus")),
	    		Boolean.parseBoolean(defaultProps.getProperty("grid")), Integer.parseInt(defaultProps.getProperty("canvaSizeX")), Integer.parseInt(defaultProps.getProperty("canvaSizeY")),
	    		Integer.parseInt(defaultProps.getProperty("delay")), Integer.parseInt(defaultProps.getProperty("nbTicks")), Integer.parseInt(defaultProps.getProperty("refresh")),
				Integer.parseInt(defaultProps.getProperty("seed")), Boolean.parseBoolean(defaultProps.getProperty("trace")), defaultProps.getProperty("mode"));
	}	
	
	public static void main(String[] args){
		//int longueur, int largeur, boolean torus, int nbAgent, int delay, int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY, boolean grid, boolean trace, String mode

		SMAWator sma=null;
		try {
			sma = readProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}