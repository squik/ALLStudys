package TP;

public class poubelle {

}
