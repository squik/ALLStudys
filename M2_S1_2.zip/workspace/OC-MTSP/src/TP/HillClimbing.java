package TP;

import java.io.IOException;
import java.util.ArrayList;



public class HillClimbing {
	
	
	public static int[] smtWTP(Instance i, int choixStratege,int choixVoisin,int modeSoluce,int[] weightnumObj) throws IOException{
		
		
		int[] ordre = null;
		
		
			ordre = Alea.solution(i);
		
		long res = Eval.fSommeAll(i,weightnumObj,ordre);
		
		ArrayList<int[]> lesVoisins = voisin(ordre,choixVoisin);
		
		if(choixStratege==0){
			
			boolean notbetter = true;
			
			while(notbetter){
				
				long resOpti = res;
				int[] ordreOpti = null;
				while (!lesVoisins.isEmpty()){
					int choix = (int) (Math.random() * lesVoisins.size());			
					

						long res2 =Eval.fSommeAll(i,weightnumObj,lesVoisins.get(choix));
						if(res2<resOpti ){		
						
							resOpti = res2;
							ordreOpti =lesVoisins.get(choix);
							
						}
						lesVoisins.remove(choix);
				}
				
				if (resOpti < res){
					ordre = ordreOpti;
					res = resOpti;
					lesVoisins = voisin(ordre,choixVoisin);
				}else{
					notbetter=false;
				}
				
			}
			
			
		}else{	
		while (!lesVoisins.isEmpty()){
			int choix = (int) (Math.random() * lesVoisins.size());			
				

			long res2 = Eval.fSommeAll(i,weightnumObj,lesVoisins.get(choix));
				if(res2<res ){		
					
					ordre = lesVoisins.get(choix);
					lesVoisins = voisin(ordre,choixVoisin);
					res=res2;
				}else{
					lesVoisins.remove(choix);
				}	
			
			}	
		}
		
		
		
		return ordre;
		
	}
	
	
	public static int[] insert(int[] ordre,int deb,int fin){
		
		if (deb == fin){
			return ordre;
		}
		
		
		int element = ordre[deb];
		
		
		if (deb < fin){
			for (int i = deb +1;i<= fin;i++){				
				ordre[i-1]=ordre[i];				
			}
			ordre[fin]=element;
		}else{
			for (int i = deb-1 ; fin<= i;i--){
				ordre[i+1]=ordre[i];
			}
			ordre[fin]=element;
		}
		
		
		
		return ordre;
		
	}
	
	
	public static int[] swap(int[] ordre,int deb ,int fin){
		
		int element = ordre[deb];
		
		ordre[deb]=ordre[fin];		
		ordre[fin]= element;		
		
		return ordre;
	}
	
	public static int[] echange(int[] ordre , int deb , int fin){
		
		
		if (deb == fin){
			return ordre;
		}
		if (fin < deb){
			return ordre;
		}
		
		ordre = swap (ordre,deb,fin);
		
		
		
		return echange(ordre,deb+1,fin-1);
	}
	
	
	public static ArrayList<int[]> voisin(int[] ordre, int choixVoisin){
		
		ArrayList<int[]> res = new ArrayList<int[]>() ;		
		
			
			
		
			
			
			if(choixVoisin==0){
				
				
				
				for(int i = 0 ;i<ordre.length-1;i++){
					for(int j =0 ;j<ordre.length;j++){
						
					if(j!=i){	
						int[] newOrdre = new int[ordre.length];
						for(int k=0;k<ordre.length;k++){
							newOrdre[k]=ordre[k];
						}
						
						res.add(insert(newOrdre,i,j));
					}
					}
					
				}
				
				
				
				
				
			}else{
				if(choixVoisin ==1){
					
					
					
					for(int i = 0 ;i<ordre.length-1;i++){
						for(int j =0 ;j<ordre.length;j++){
							if(j!=i){
								
							
							
							int[] newOrdre = new int[ordre.length];
							for(int k=0;k<ordre.length;k++){
								newOrdre[k]=ordre[k];
							}
							
							res.add(swap(newOrdre,i,j));
							}
						}
						
					}
					
					
				}else{
					
					for(int i = 0 ;i<ordre.length-1;i++){
						int[] newOrdre = new int[ordre.length];
						for(int k=0;k<ordre.length;k++){
							newOrdre[k]=ordre[k];
						}
						res.add(echange(newOrdre,i,i+1));
					}
					
				}
			}
			
		
		
		return res ;
		
	}

}
