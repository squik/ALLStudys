package TP;

public class Pareto {

	
	/*
	 * 
	 * rank domiance
	 * 
	 * nombre de domination?
	 */
	
}
