package TP;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Instance i = SearchInstance.search("randomA100.tsp","randomB100.tsp",100);
		
		//System.out.println(i.getVal(1, 3, 2));
		
		int[] solAlea= Alea.solution(i);
		
		imprimeordre(solAlea);
		
		System.out.println(Eval.fSomme(i, 1, solAlea));
		System.out.println(Eval.fSomme(i, 2, solAlea));
		
		
		ArrayList<int[]> tabAlea = new ArrayList<int[]>();
		
		for (int k =0;k<100000;k++){
			tabAlea.add(Alea.solution(i));
		}
		
		FileOutputStream AleaALL = new FileOutputStream(new File("AleaALL.txt"));
		FileOutputStream AleaOffLine = new FileOutputStream(new File("AleaOFFline.txt"));
		FileOutputStream AleaONLine = new FileOutputStream(new File("AleaONline.txt"));
		
		boolean[] max = new boolean[2];
		max[0]=true;
		max[1]=true;
		
		long debut,diff;
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> tabAleaOff = OFFLine.offLine(i,tabAlea,max,2);
		diff = System.currentTimeMillis()-debut;
		
		System.out.println("timeOff : "+diff);
		
		
		debut = System.currentTimeMillis();
		ArrayList<int[]> tabAleaON = ONLine.onLine(i,tabAlea,max,2);
		diff = System.currentTimeMillis()-debut;
		
		System.out.println("timeOn : "+diff);
		
		
		for(int[] sol1 : tabAlea ){
			
			AleaALL.write(Long.toString(Eval.fSomme(i, 1, sol1)).getBytes());
			AleaALL.write(" ".getBytes());
			AleaALL.write(Long.toString(Eval.fSomme(i, 2, sol1)).getBytes());
			AleaALL.write("\n".getBytes());
			
		}
		for(int[] sol2 : tabAleaON ){
			
			AleaONLine.write(Long.toString(Eval.fSomme(i, 1, sol2)).getBytes());
			AleaONLine.write(" ".getBytes());
			AleaONLine.write(Long.toString(Eval.fSomme(i, 2, sol2)).getBytes());
			AleaONLine.write("\n".getBytes());
	
		}
		for(int[] sol3 : tabAleaOff ){
			
			AleaOffLine.write(Long.toString(Eval.fSomme(i, 1, sol3)).getBytes());
			AleaOffLine.write(" ".getBytes());
			AleaOffLine.write(Long.toString(Eval.fSomme(i, 2, sol3)).getBytes());
			AleaOffLine.write("\n".getBytes());
	
		}
		
		/*fosBig.write(Long.toString(100*(F.fSomme(i2)-score[nbBi-1])/score[nbBi-1]).getBytes());
		
		
		*/
		
		
		AleaALL.close() ;
		AleaOffLine.close() ;
		AleaONLine.close() ;
		
		System.out.println("skyfalll this is the end");

	}
	
	public static void imprimeordre(int[] tab){
		
		for (int t  :tab ){
			System.out.print(t+" -> ");
			}
			System.out.println();
		
		
	}

}
