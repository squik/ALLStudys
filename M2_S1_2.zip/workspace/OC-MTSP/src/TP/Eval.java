package TP;


public class Eval {
	


	public static long fSomme (Instance instance,int numObj,int[] ordre){
		long res = 0;
		
		for(int i =0 ;i<ordre.length-1;i++){			
			res += instance.getVal(numObj, ordre[i], ordre[i+1]);					
		}
		
		res += instance.getVal(numObj, ordre.length, 1);
		
		return res;
	}
	public static long fSommeAll(Instance instance,int[] weightnumObj,int[] ordre){
		long res = 0;
		int cpt=0;
				for (int i :weightnumObj ){
					res += i * fSomme (instance,cpt,ordre);
					cpt += 1;
				}
		return res;
	}

}
