package TP;

public class Scalar {

	
	/*
	 * une soltuino
	 */
}
