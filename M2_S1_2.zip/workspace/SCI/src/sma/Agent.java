package sma;
/**
 * 
 * 
 * @author tommasi Maitrot
 */

import java.util.Random;

public class Agent {
	
	private int posx;
	private int posy;
	private int pasx;
	private int pasy;
	private String coul="G";
	private String name;
	private Environnement env;
	private int nbCol;
	private boolean trace;
	
	public Agent(Environnement env, int seed, boolean trace){
		this.env = env;
		Random rd = null;
		if (seed == 0) {
			rd = new Random();
		}
		else {
			rd = new Random(seed);
		}
		boolean stop =true;
		while (stop) {
			int x = rd.nextInt(env.getGridSizeX());
			int y = rd.nextInt(env.getGridSizeY());
			if( env.cellContent(x,y) == null) {
				this.posx = x;
				this.posy = y;
				this.name=""+x+"/"+y;
				stop = false;
			}
		}
		
		this.pasx = rd.nextInt(3)-1;
		if (pasx == 0){
			int[] choices = {-1,1};
			this.pasy = choices[rd.nextInt(2)];
		}
		else this.pasy = rd.nextInt(3)-1;
		this.trace = trace;
		this.nbCol = 0;
	}
		
	public void decide(){
		int x2 = this.posx + this.pasx;
		int y2 = this.posy + this.pasy;
		
		boolean coll = false;
		
		
		// comportement avec la collision d'un mur 
		if (env.isBorderX(x2)){
			this.collision();
			this.pasx *= -1;
			coll = true;
		}
		if (env.isBorderY(y2)){
			this.collision();
			this.pasy *= -1;
			coll = true;
		}
		if (coll) return;
		
		
		// fin comportement 

		x2 = (x2+env.getGridSizeX())%env.getGridSizeX();
		y2 = (y2+env.getGridSizeY())%env.getGridSizeY();
		
		Agent ag = env.cellContent(x2, y2);
		if  (ag != null){
			meetAgent(ag);
			return;
		}
		else {
			env.moveAgent(this);
		}
	}
	
	public void collision(){
		if (trace) System.out.println("Agent;"+this.name+";"+this.pasx+";"+this.pasy+";"+this.posx+";"+this.posy+";"+this.nbCol);
		this.nbCol+=1;
		this.coul="R";
	}
	
	public void meetAgent(Agent ag){
		this.collision();
		ag.collision();
		
		// comportement quand on entre en collision avec un agent 
		this.inverseDirections();
		ag.inverseDirections();
	}
	
	public String getCoul(){
		return this.coul;
	}
	
	public String getName(){
		return this.name;
	}
	
	public int getPosX(){
		return posx;
	}
	
	public int getPosY(){
		return posy;
	}

	public int getPasX(){
		return pasx;
	}
	
	public int getPasY(){
		return pasy;
	}
	
	public void setPosition(int x, int y){
		this.posx = x;
		this.posy = y;
	}
	
	public void inverseDirections(){
		this.pasx *= -1;
		this.pasy *= -1;
	}
}