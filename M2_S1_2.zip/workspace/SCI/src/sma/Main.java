package sma;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main{
	
	public static SMA readParameterFile(String file) throws IOException{

	    int longueur=38;
	    int largeur=80;
	    boolean torus=true;
	    int nbAgent=100;
	    int delay=150;
	    int nbTicks=100000;
	    int refresh=1;
	    int seed=0;
	    int canvaSizeX=0;
	    int canvaSizeY=0;
	    boolean grid=false;
	    boolean trace=true;
	    String mode="E";
	    
	    if (file != null){
		FileInputStream flux= new FileInputStream(file);
	    InputStreamReader lecture=new InputStreamReader(flux);
	    BufferedReader buff=new BufferedReader(lecture);
	
	    longueur = Integer.valueOf(buff.readLine());
	    largeur = Integer.valueOf(buff.readLine());
	    torus = Boolean.valueOf(buff.readLine());
	    nbAgent = Integer.valueOf(buff.readLine());
	    delay = Integer.valueOf(buff.readLine());
	    nbTicks = Integer.valueOf(buff.readLine());
	    refresh = Integer.valueOf(buff.readLine());
	    seed = Integer.valueOf(buff.readLine());
	    canvaSizeX = Integer.valueOf(buff.readLine());
	    canvaSizeY = Integer.valueOf(buff.readLine());
	    grid = Boolean.valueOf(buff.readLine());
	    trace = Boolean.valueOf(buff.readLine());
	    mode = buff.readLine();
	    }
	    	
		
	    return new SMA(longueur,largeur,torus,nbAgent,delay,nbTicks, refresh, seed, canvaSizeX, canvaSizeY, grid, trace, mode);
	}	
	
	public static void main(String[] args){
		//int longueur, int largeur, boolean torus, int nbAgent, int delay, int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY, boolean grid, boolean trace, String mode

		SMA sma=null;
		try {
			sma = readParameterFile("/home/m2mocad/maitrot/workspace/SCI/src/sma/Properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}