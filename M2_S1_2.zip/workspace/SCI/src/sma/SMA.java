package sma;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SMA {
	
	private Agent[] particles;
	private Environnement env;
	private Vue vue;
	private ArrayList<Integer> rdlist;
	private int delay;
	private int nbTicks;
	private int refresh;
	private boolean trace;
	private int seed;
	private String mode;
	
	public SMA(int longueur, int largeur, boolean torus, int nbAgent, int delay, int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY, boolean grid, boolean trace,String mode) {
		this.particles = new Agent[nbAgent];
		Environnement env = new Environnement (longueur, largeur, torus);
		for (int i = 0; i < nbAgent; i++){
			Agent ag = new Agent(env, seed, trace);
			env.addAgent(ag);
			particles[i] = ag;
		}
		this.env = env;
		this.vue = new Vue(env, canvaSizeX, canvaSizeY, grid);
		this.delay = delay;
		this.nbTicks = nbTicks;
		this.refresh = refresh;
		this.trace = trace;
		this.seed = seed;
		this.mode=mode;
	}
	
	
	public void run() {
		ArrayList<Integer> rdlist = new ArrayList<Integer>();
		for (int i = 0; i < particles.length; i++){
			rdlist.add(i);
		}
		Random rnd = null;
		if (seed==0) rnd = new Random();
		else rnd = new Random(seed);
		int step = 0;
		
		while (step < nbTicks) {
			
			if (this.mode == "A"){
				int choix = (int) (Math.random()* rdlist.size());
				particles[choix].decide();
			}else {
				if(this.mode == "E") Collections.shuffle(rdlist, rnd);
				
				for (int rd : rdlist){
					particles[rd].decide();
				}
			}
			//vue.vue(env.getState());
			try {
				vue.initPlateau(env);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (step % refresh == 0) {
				vue.repaint();
			}
			step += 1;
			if (trace) System.out.println("Tick;"+step);
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}