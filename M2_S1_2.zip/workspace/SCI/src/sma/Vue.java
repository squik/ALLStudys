package sma;


import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

  /* La classe contient une fonction principale           */
  /* d'utilisation en tant qu'application.                */
  /* Elle etend la classe Frame pour la creation          */
  /* d'une fenetre.                                       */
  /* Elle implemente les interfaces WindowListener et     */
  /* ActionListener                                       */
  /* la gestion des evenements fenetre et action.         */

public class Vue extends Frame implements WindowListener,
											ActionListener{
	

	  /* Objets menu                                          */
	  private MenuBar mb = new MenuBar();
	  private Menu m1 = new Menu("Fichier");
	  //private MenuItem mnj = new MenuItem("Nouveau jeu");
	  private MenuItem mq = new MenuItem("Quitter");
	  /* Chaine de caracteres affichee sur le plateau de jeu  */
	  private String message ="";
	  /* Position de la souris lors d'un clic                 */
	  private int mousex = -1;
	  private int mousey = -1;
	  /* Description du plateau de jeu                        */
	  private static Agent [][] tst;
	  private boolean grid;

	
	  /* Constructeur                                         */

	  public Vue(Environnement env, int canvaSizeX, int canvaSizeY, boolean grid) {
	  /* Appel au constructeur de la super-classe Frame       */
	  /* pour donner un titre a la fenetre                    */
	    super("Billes");
	  /* Ajout d'un ecouteur de fenetre a la fenetre          */
	  /* pour gerer les evenements fenetre                    */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface WindowListener        */
	    addWindowListener(this);
	  /* Ajout d'un ecouteur de souris a la fenetre           */
	  /* pour gerer les evenements souris                     */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface MouseListener         */
	  /* Ajout d'une barre de menu a la fenetre               */
	    setMenuBar(mb);
	  /* Ajout des menus a la barre de menu                   */
	    mb.add(m1);
	    //m1.add(mnj);
	    m1.addSeparator();
	    m1.add(mq);
	  /* Ajout d'un ecouteur d'action aux menus idoines       */
	  /* pour gerer leurs evenements d'activation             */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface ActionListener        */
	    mq.addActionListener(this);
	    //mnj.addActionListener(this);
	  /* Le blanc est la couleur de fond de la fenetre        */
	    setBackground(Color.white);
	    tst = env.getState();
	  /* Ajustement de la taille de la fenetre en fonction    */
	  /* de la taille du plateau de jeu                       */
	    if (canvaSizeX == 0 && canvaSizeY == 0) {
	    	setSize(24*env.getGridSizeY()+8,24*env.getGridSizeX()+72);
	    }
	    else {
	    	setSize(canvaSizeX, canvaSizeY);
	    }
	  /* Activation de la fenetre                             */
	    setVisible(true);
	    this.grid = grid;
	  }

	  /* Affichage du plateau de jeu                          */

	  public void paint(Graphics g) {
	    for ( int y = 0 ; y < tst.length ; y++ ) {
	      for ( int x = 0 ; x < tst[0].length ; x++ ) {
	        if (tst[y][x]==null) {
	        	if (grid) g.drawLine(12+24*x,60+24*y,12+24*x,60+24*y);
	        }else if (tst[y][x].getCoul()=="G"){
	        	g.setColor(Color.gray);
	        	g.fillOval(10+24*x,58+24*y,20,20);
	        }else if (tst[y][x].getCoul()=="R"){
	        	g.setColor(Color.red);
	        	g.fillOval(10+24*x,58+24*y,20,20);
	        }
	      }
	    }
	  }

	  /* Reactions aux evenements fenetre                     */

	  public void windowActivated(WindowEvent e) {
	  }
	  
	  public void windowClosed(WindowEvent e) {
	  }
	  
	  public void windowClosing(WindowEvent e) {
	  /* Interruption du programme                            */
	    System.exit(0);
	  }
	  
	  public void windowDeactivated(WindowEvent e) {
	  }
	  
	  public void windowDeiconified(WindowEvent e) {
	  }
	  
	  public void windowIconified(WindowEvent e) {
	  }
	  
	  public void windowOpened(WindowEvent e) {
	  }
	    
	  /* Reaction aux evenements action                       */

	  public void actionPerformed(ActionEvent e) {
	  /* Si l'entree de menu "Quitter" est utilisee           */
	    if ( e.getSource() == mq ) {
	  /* Interruption du programme                            */
	      System.exit(0); }
//	  /* Si l'entree de menu "Nouveau jeu" est utilisee       */
//	    if ( e.getSource() == mnj ) {
//	  /* Reinitialisation du jeu via la fonction nouveauJeu   */
//	      try {
//	        nouveauJeu(); }
//	      catch (IOException ioe) {} }
	  }

	  /* Fonctions d'écoute  des params                       */

	  static BufferedReader flux = new BufferedReader(new InputStreamReader(System.in));

	  /* Fonction principale                                  */

	  public Agent [][] initPlateau(Environnement env) throws IOException {
		  tst = env.getState();
		  return tst;
		  
	  }

	public void vue(Agent[][] listAg){
		
		for ( Agent[] list2 : listAg ){
			System.out.print("|");
			for (Agent ag : list2){
				if (ag == null){
					System.out.print("     ");
				}else{
					System.out.print(" "+ag.getCoul()+ag.getName()+" ");
				}
				System.out.print("|");
			}
			System.out.print("\n");
		}
		System.out.print("\n\n\n");
	}

}