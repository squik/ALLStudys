package sma;
public class Environnement {

	private int gridSizeX;
	private int gridSizeY;
	private Agent[][] matrice;
	private boolean torus;
	
	public Environnement(int longueur, int largeur, boolean torus){
		this.gridSizeY = largeur;
		this.gridSizeX = longueur;
		this.torus = torus;
		this.matrice = new Agent[longueur][largeur];
	}
	
	public void addAgent(Agent ag){
		matrice[ag.getPosX()][ag.getPosY()] = ag;
	}
	
	public boolean isTorus(){
		return torus;
	}
	
	public boolean isBorderX(int x){
		if (torus) return false;
		return (x < 0 || x == gridSizeX);
	}
	
	public boolean isBorderY(int y){
		if (torus) return false;
		return (y < 0 || y == gridSizeY);
	}
	
	public Agent cellContent(int x, int y){
		return matrice[x][y];
	}
	
	public void moveAgent(Agent ag){
		int x1 = ag.getPosX();
		int y1 = ag.getPosY();
		int x2 = (ag.getPasX()+x1+gridSizeX)%gridSizeX;
		int y2 = (ag.getPasY()+y1+gridSizeY)%gridSizeY;
		//agent stay in the environnement
		ag.setPosition(x2, y2);
		matrice[x2][y2]=matrice[x1][y1];
		matrice[x1][y1]=null;
	}
	
	public int getGridSizeY(){
		return gridSizeY;
	}
	public int getGridSizeX(){
		return gridSizeX;
	}
	public Agent[][] getState(){
		return matrice;
	}
	
}