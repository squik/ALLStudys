package TP1;

import java.io.IOException;
import java.util.ArrayList;

public class main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		
		 
		 
		// TODO Auto-generated method stub
			Instance i = SearchInstance.search(28,100);
			Instance i2 = SearchInstance.search(1000,"22");
			int[] ordreAlea = SolutionAlea.solution(i);
			int[] ordreEDD = SolutionEDD.solution(i);
			int[] ordreMDD =SolutionMDD.solution(i);
			int[] ordreRend =SolutionRend.solution(i);
			System.out.println(" sans traitement => "+F.fSomme(i));
			System.out.println(" alea => "+F.fSomme(i,ordreAlea));
			imprimeordre(ordreAlea);
			System.out.println(" EDD  => "+F.fSomme(i,ordreEDD));
			imprimeordre(ordreEDD);
			System.out.println(" MDD  => "+F.fSomme(i,ordreMDD));
			imprimeordre(ordreMDD);
			System.out.println(" Rend  => "+F.fSomme(i,ordreRend));
			imprimeordre(ordreRend);
			
			System.out.println("\n INSTANCE DIFFICILE  \n");
			
			// changer tous les int par des longs pour avoir un résultat
			
			int[] ordreAlea2 = SolutionAlea.solution(i2);
			int[] ordreEDD2 = SolutionEDD.solution(i2);
			int[] ordreMDD2 =SolutionMDD.solution(i2);
			System.out.println(" sans traitement => "+F.fSomme(i2));
			System.out.println(" alea => "+F.fSomme(i2,ordreAlea2));
			imprimeordre(ordreAlea2);
			System.out.println(" EDD  => "+F.fSomme(i2,ordreEDD2));
			imprimeordre(ordreEDD2);
			System.out.println(" MDD  => "+F.fSomme(i2,ordreMDD2));
			imprimeordre(ordreMDD2);
			
			
			
			System.out.println("\n HILL climbing \n");
			
			long debut = 0;
			long diff =0;
			float moyT = 0;
			float moyD =0;
			float dev = 0;
			
			int nbRun = 30;
			
			int score = 5988;
			int nbins = 1;
			
			Instance iH = SearchInstance.search(nbins,100);
			
			for (int ss = 0 ;ss<2;ss++){
				for (int v = 0 ;v<3;v++){
					for (int s = 0 ;s<3;s++){
						
						//System.out.println( "ss : "+s+" v = "+v+" s = "+s);
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= HillClimbing.smtWTP(i, ss,v,s);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(iH,ordreRun)-score)/score;
							moyT+=diff ;
							moyD+= dev ;
							/**
							
							System.out.println("opti = "+F.fSomme(iH,ordreRun));
							
							System.out.print("TIME : ");
							System.out.println(diff);
							System.out.print("deviation : ");
							System.out.println(dev);
							*/
						}
						
						System.out.println( "ss : "+ss+" v = "+v+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}
				}
			}
			
			for (int gj = 0 ;gj<2;gj++){
			
			System.out.println("\n VND \n");
			
			debut = 0;
			diff =0;
			moyT = 0;
			moyD =0;
			dev = 0;
			
			nbRun = 30;
			
			score = 5988;
			nbins = 1;
			
			
			int[] voi = {2,1,0};
			int[] voi2 = {2,0,1};
			if (gj==1){
				voi = voi2;
			}
			
			
			iH = SearchInstance.search(nbins,100);
			
			for (int ss = 0 ;ss<2;ss++){
					for (int s = 0 ;s<3;s++){
						
						//System.out.println( "ss : "+s+" v = "+v+" s = "+s);
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= VND.VND(false,-1,nbins, ss,voi,s,null);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(iH,ordreRun)-score)/score;
							moyT+=diff ;
							moyD+= dev ;
							/**
							
							System.out.println("opti = "+F.fSomme(iH,ordreRun));
							
							System.out.print("TIME : ");
							System.out.println(diff);
							System.out.print("deviation : ");
							System.out.println(dev);
							*/
						}
						
						System.out.println( "ss : "+ss+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}				
			}
			}
			
			System.out.print("\n\n ILS \n");
			
			Instance i3 = SearchInstance.search(1,100);
			System.out.println(i3);
			debut = System.currentTimeMillis();
			Instance ordreILS = ILS.ILS(i3, 20);
			diff = System.currentTimeMillis()-debut;
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreILS)-5998)/5998);
			
			
			System.out.print("\n\n VNS \n");
			
			
			int[] voiVNS = {2,0,1};
			
			Instance i4 = SearchInstance.search(24,100);
			Instance i4bis = SearchInstance.search(24,100);
			System.out.println(i4);
			debut = System.currentTimeMillis();
			Instance ordreVNS = VNS.VNS(i4,i4bis, voiVNS);
			diff = System.currentTimeMillis()-debut;
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreVNS)-744287)/744287);
			
			
			
			System.out.print("\n\n TS \n");
			
			
			
			Instance i5 = SearchInstance.search(1,100);
			System.out.println(i5);
			
			ArrayList<int[]> tabou = new ArrayList<int[]>();
			ArrayList<Integer> deb = new ArrayList<Integer>();
			ArrayList<Integer> fin = new ArrayList<Integer>();
			
			debut = System.currentTimeMillis();			
			Instance ordreTS = TS.TS(i5, 1,tabou,deb,fin);			
			diff = System.currentTimeMillis()-debut;
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreTS)-5998)/5998);

			
			
			
			System.out.println("FIN");
	}

	
	public static void imprimeordre(int[] tab){
		
		for (int t  :tab ){
			System.out.print(t+" -> ");
			}
			System.out.println();
		
		
	}
}
