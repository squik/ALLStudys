package TP1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public class BigMain {
	

	
	//debut = System.currentTimeMillis();					
	//diff = System.currentTimeMillis()-debut;
	


	public static void main(String[] args) throws IOException {

		FileInputStream flux1= new FileInputStream("/home/m2mocad/maitrot/workspace/OC/src/TP1/wtbest100b.txt");
		InputStreamReader lecture1=new InputStreamReader(flux1);
		BufferedReader buff1=new BufferedReader(lecture1);
		String ligne1 ="";
		int[] score1 = new int[125] ;
		int cpt1 = 0;
		long debut;
		long diff;
		
		
		while ((ligne1=buff1.readLine())!=null){
			
			String[] reg = ligne1.split("[^0-9]") ;
			for (String sa : reg){
				try{
					score1[cpt1]=Integer.valueOf(sa);
					
							
				}
				catch(Exception e){
					
				}
			}
			
			cpt1++;
			
		}
		FileOutputStream foslittle = new FileOutputStream(new File("Resultatlittle.txt"));
		FileOutputStream fosAlealittle = new FileOutputStream(new File("ResultatAlealittle.txt"));
		FileOutputStream fosEDDlittle = new FileOutputStream(new File("ResultatEDDlittle.txt"));
		FileOutputStream fosMDDlittle = new FileOutputStream(new File("ResultatMDDlittle.txt"));
		FileOutputStream fosRendlittle = new FileOutputStream(new File("ResultatRendlittle.txt"));
		
		for (int nbi =1;nbi<126;nbi++){
			Instance i = SearchInstance.search(nbi,100);
			Instance ibis = SearchInstance.search(nbi,100);
			
			foslittle.write((nbi+" ").getBytes());
			foslittle.write(Long.toString(F.fSomme(i)).getBytes());
			if(score1[nbi-1]==0){
				foslittle.write((-1+"").getBytes());
			}else{
			foslittle.write(Long.toString(100*(F.fSomme(i)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			foslittle.write((" ").getBytes());
			foslittle.write((" "+0+"\n").getBytes() );
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreAlea = SolutionAlea.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosAlealittle.write((nbi+" ").getBytes());
			fosAlealittle.write(Long.toString(F.fSomme(i,ordreAlea)).getBytes());
			fosAlealittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosAlealittle.write((-1+"").getBytes());
			}else{
			fosAlealittle.write(Long.toString(100*(F.fSomme(i,ordreAlea)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosAlealittle.write((" ").getBytes());
			fosAlealittle.write(Long.toString(diff).getBytes());		
			fosAlealittle.write(("\n").getBytes() );	
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreEDD = SolutionEDD.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosEDDlittle.write((nbi+" ").getBytes());
			fosEDDlittle.write(Long.toString(F.fSomme(i,ordreEDD)).getBytes());
			fosEDDlittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosEDDlittle.write((-1+"").getBytes());
			}else{
			fosEDDlittle.write(Long.toString(100*(F.fSomme(i,ordreEDD)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosEDDlittle.write((" ").getBytes());
			fosEDDlittle.write(Long.toString(diff).getBytes());		
			fosEDDlittle.write(("\n").getBytes() );		
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreMDD =SolutionMDD.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosMDDlittle.write((nbi+" ").getBytes());
			fosMDDlittle.write(Long.toString(F.fSomme(i,ordreMDD)).getBytes());
			fosMDDlittle.write((" ").getBytes());
			if(score1[nbi-1]==0){
				fosMDDlittle.write((-1+"").getBytes());
			}else{
			fosMDDlittle.write(Long.toString(100*(F.fSomme(i,ordreMDD)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosMDDlittle.write((" ").getBytes());
			fosMDDlittle.write(Long.toString(diff).getBytes());		
			fosMDDlittle.write(("\n").getBytes() );	
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreRend =SolutionRend.solution(i);
			diff = System.currentTimeMillis()-debut;
			
			fosRendlittle.write((nbi+" ").getBytes());
			fosRendlittle.write(Long.toString(F.fSomme(i,ordreRend)).getBytes());
			fosRendlittle.write((" ").getBytes());
			
			if(score1[nbi-1]==0){
				fosRendlittle.write((-1+"").getBytes());
			}else{
			fosRendlittle.write(Long.toString(100*(F.fSomme(i,ordreRend)-score1[nbi-1])/score1[nbi-1]).getBytes());
			}
			fosRendlittle.write((" ").getBytes());
			
			fosRendlittle.write(Long.toString(diff).getBytes());		
			fosRendlittle.write(("\n").getBytes() );	
			
			
			
			System.out.println("\n HILL climbing \n");
			
			
			float moyT = 0;
			float moyD =0;
			float dev = 0;
			
			int nbRun = 30;
			
			
			for (int ss = 0 ;ss<2;ss++){
				for (int v = 0 ;v<3;v++){
					for (int s = 0 ;s<3;s++){						
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= HillClimbing.smtWTP(i, ss,v,s);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(i,ordreRun)-score1[nbi-1])/score1[nbi-1];
							moyT+=diff ;
							moyD+= dev ;
						}
						
						// remplacer par mettre dans un fichier
						
						System.out.println( "ss : "+ss+" v = "+v+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}
				}
			}
			
			System.out.println("\n VND \n");
			
			
			ArrayList<int[]> listVoisin = new ArrayList<int[]>() ;
			
			int[] voi = {2,1,0};
			int[] voi2 = {2,0,1};
			
			listVoisin.add(voi);
			listVoisin.add(voi2);
			
			for ( int[] voisinage : listVoisin){
				
				
				for (int ss = 0 ;ss<2;ss++){
					for (int s = 0 ;s<3;s++){
						
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= VND.VND(false,-1,-1, ss,voisinage,s,i);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(i,ordreRun)-score1[nbi-1])/score1[nbi-1];
							moyT+=diff ;
							moyD+= dev ;

						}
						
						// remplacer par mettre dans un fichier
						
						System.out.println( "ss : "+ss+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}				
			}
				
				
			}
			
			int k_opt =20;
			
			
			System.out.print("\n\n ILS \n");
			
			debut = System.currentTimeMillis();
			Instance ordreILS = ILS.ILS(i, k_opt);
			diff = System.currentTimeMillis()-debut;
			
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreILS)-score1[nbi-1])/score1[nbi-1]);
			
			
			
			
			
			System.out.print("\n\n VNS \n");
			
			
			int[] voiVNS = {2,0,1};
			
			debut = System.currentTimeMillis();
			Instance ordreVNS = VNS.VNS(i,ibis, voiVNS);
			diff = System.currentTimeMillis()-debut;
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreVNS)-score1[nbi-1])/score1[nbi-1]);
			
			
			
			System.out.print("\n\n TS \n");
			
			
			
			ArrayList<int[]> tabou = new ArrayList<int[]>();
			ArrayList<Integer> deb = new ArrayList<Integer>();
			ArrayList<Integer> fin = new ArrayList<Integer>();
			
			debut = System.currentTimeMillis();			
			Instance ordreTS = TS.TS(i, 1,tabou,deb,fin);			
			diff = System.currentTimeMillis()-debut;
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreTS)-score1[nbi-1])/score1[nbi-1]);
			
			
		}
		
		
		FileInputStream flux= new FileInputStream("/home/m2mocad/maitrot/workspace/OC/src/TP1/instances/optimal_results.txt");
		InputStreamReader lecture=new InputStreamReader(flux);
		BufferedReader buff=new BufferedReader(lecture);
		String ligne ="";
		int[] score = new int[25] ;
		int cpt = 0;
		
		while ((ligne=buff.readLine())!=null){			
			score[cpt] = Integer.valueOf(ligne);
			cpt++;
			
		}
		
		FileOutputStream fosBig = new FileOutputStream(new File("ResultatBig.txt"));
		FileOutputStream fosAleaBig = new FileOutputStream(new File("ResultatAleaBig.txt"));
		FileOutputStream fosEDDBig = new FileOutputStream(new File("ResultatEDDBig.txt"));
		FileOutputStream fosMDDBig = new FileOutputStream(new File("ResultatMDDBig.txt"));
		FileOutputStream fosRendBig = new FileOutputStream(new File("ResultatRendBig.txt"));
		
		
		for (int nbBi = 1;nbBi<25;nbBi++){
			Instance i2 = SearchInstance.search(1000,""+nbBi);
			Instance i2bis = SearchInstance.search(1000,""+nbBi);
			
			
			fosBig.write((nbBi+" ").getBytes());
			fosBig.write(Long.toString(F.fSomme(i2)).getBytes());
			if(score[nbBi-1]==0){
				fosBig.write((-1+"").getBytes());
			}else{
			fosBig.write(Long.toString(100*(F.fSomme(i2)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosBig.write((" ").getBytes());
			fosBig.write((" "+0+"\n").getBytes() );
			
			debut = System.currentTimeMillis();
			int[] ordreAlea = SolutionAlea.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosAleaBig.write((nbBi+" ").getBytes());
			fosAleaBig.write(Long.toString(F.fSomme(i2,ordreAlea)).getBytes());
			fosAleaBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosAleaBig.write((-1+"").getBytes());
			}else{
			fosAleaBig.write(Long.toString(100*(F.fSomme(i2,ordreAlea)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosAleaBig.write((" ").getBytes());
			fosAleaBig.write(Long.toString(diff).getBytes());		
			fosAleaBig.write(("\n").getBytes() );
			
			
			debut = System.currentTimeMillis();
			int[] ordreEDD = SolutionEDD.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosEDDBig.write((nbBi+" ").getBytes());
			fosEDDBig.write(Long.toString(F.fSomme(i2,ordreEDD)).getBytes());
			fosEDDBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosEDDBig.write((-1+"").getBytes());
			}else{
			fosEDDBig.write(Long.toString(100*(F.fSomme(i2,ordreEDD)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosEDDBig.write((" ").getBytes());
			fosEDDBig.write(Long.toString(diff).getBytes());		
			fosEDDBig.write(("\n").getBytes() );
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreMDD =SolutionMDD.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosMDDBig.write((nbBi+" ").getBytes());
			fosMDDBig.write(Long.toString(F.fSomme(i2,ordreMDD)).getBytes());
			fosMDDBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosMDDBig.write((-1+"").getBytes());
			}else{
			fosMDDBig.write(Long.toString(100*(F.fSomme(i2,ordreMDD)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosMDDBig.write((" ").getBytes());
			fosMDDBig.write(Long.toString(diff).getBytes());		
			fosMDDBig.write(("\n").getBytes() );	
			
			
			
			
			debut = System.currentTimeMillis();
			int[] ordreRend =SolutionRend.solution(i2);
			diff = System.currentTimeMillis()-debut;
			
			fosRendBig.write((nbBi+" ").getBytes());
			fosRendBig.write(Long.toString(F.fSomme(i2,ordreRend)).getBytes());
			fosRendBig.write((" ").getBytes());
			if(score[nbBi-1]==0){
				fosRendBig.write((-1+"").getBytes());
			}else{
			fosRendBig.write(Long.toString(100*(F.fSomme(i2,ordreRend)-score[nbBi-1])/score[nbBi-1]).getBytes());
			}
			fosRendBig.write(Long.toString(diff).getBytes());		
			fosRendBig.write(("\n").getBytes() );
			
			
			
			System.out.println("\n HILL climbing \n");
			
			
			float moyT = 0;
			float moyD =0;
			float dev = 0;
			
			int nbRun = 30;
			
			
			for (int ss = 0 ;ss<2;ss++){
				for (int v = 0 ;v<3;v++){
					for (int s = 0 ;s<3;s++){						
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= HillClimbing.smtWTP(i2, ss,v,s);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(i2,ordreRun)-score[nbBi-1])/score[nbBi-1];
							moyT+=diff ;
							moyD+= dev ;
						}
						
						// remplacer par mettre dans un fichier
						
						System.out.println( "ss : "+ss+" v = "+v+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}
				}
			}
			
			System.out.println("\n VND \n");
			
			
			ArrayList<int[]> listVoisin = new ArrayList<int[]>() ;
			
			int[] voi = {2,1,0};
			int[] voi2 = {2,0,1};
			
			listVoisin.add(voi);
			listVoisin.add(voi2);
			
			for ( int[] voisinage : listVoisin){
				
				
				for (int ss = 0 ;ss<2;ss++){
					for (int s = 0 ;s<3;s++){
						
						moyT = 0;
						moyD=0;
						for(int k =0 ; k<nbRun ;k++){
							
							debut = System.currentTimeMillis();
							int[] ordreRun= VND.VND(false,-1,-1, ss,voisinage,s,i2);
							diff = System.currentTimeMillis()-debut;
							
							
							dev = 100*(F.fSomme(i2,ordreRun)-score[nbBi-1])/score[nbBi-1];
							moyT+=diff ;
							moyD+= dev ;

						}
						
						// remplacer par mettre dans un fichier
						
						System.out.println( "ss : "+ss+" s = "+s);
						System.out.print("TIMEMoy : ");
						System.out.println(moyT/nbRun);
						System.out.print("deviationMoy : ");
						System.out.println(moyD/nbRun);
						
					}				
			}
				
				
			}
			
			int k_opt =20;
			
			
			System.out.print("\n\n ILS \n");
			
			debut = System.currentTimeMillis();
			Instance ordreILS = ILS.ILS(i2, k_opt);
			diff = System.currentTimeMillis()-debut;
			
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreILS)-score[nbBi-1])/score[nbBi-1]);
			
			
			
			
			
			System.out.print("\n\n VNS \n");
			
			
			int[] voiVNS = {2,0,1};
			
			debut = System.currentTimeMillis();
			Instance ordreVNS = VNS.VNS(i2,i2bis, voiVNS);
			diff = System.currentTimeMillis()-debut;
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreVNS)-score[nbBi-1])/score[nbBi-1]);
			
			
			
			System.out.print("\n\n TS \n");
			
			
			
			ArrayList<int[]> tabou = new ArrayList<int[]>();
			ArrayList<Integer> deb = new ArrayList<Integer>();
			ArrayList<Integer> fin = new ArrayList<Integer>();
			
			debut = System.currentTimeMillis();			
			Instance ordreTS = TS.TS(i2, 1,tabou,deb,fin);			
			diff = System.currentTimeMillis()-debut;
			
			// remplacer par mettre dans un fichier
			
			System.out.print("TIME : ");
			System.out.println(diff);
			System.out.print("deviation : ");
			System.out.println(100*(F.fSomme(ordreTS)-score[nbBi-1])/score[nbBi-1]);
			
			
			
			
			
			
		}
		
		foslittle.close() ;
		fosAlealittle.close() ;
		fosEDDlittle.close()  ;
		fosMDDlittle.close() ;
		fosRendlittle.close() ;
		fosBig.close() ;
		fosAleaBig.close() ;
		fosEDDBig.close()  ;
		fosMDDBig.close() ;
		fosRendBig.close() ;
		
		
	}
	
}
