package wator;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.*;

/**
 * A Shark is randomly moving in a Sea. It can eat Fishes and birth other Sharks.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class Shark extends Agent{

	private int SharkBreedTime;
	private int SharkStarveTime;
	private int SharkAge;
	private int SharkStarve;
	private EnvSea sea;
	private Random rd;
	private String breedType;

	/**
	 * Constructor for the Shark.
	 * The Shark will be put at a random free position in its Sea.
	 * @param sea - the Environment in which the Shark lives.
	 * @param SharkBreedTime - the age of the Shark from which it can breed.
	 * @param SharkStarveTime - the time a shark can live without eating.
	 * @param seed - the random seed.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 */
	public Shark(EnvSea sea, int SharkBreedTime, int SharkStarveTime, String breedType, Random rd, boolean trace) {
		super(sea, rd, trace, "Shark");
		this.sea = sea;
		this.SharkAge = 0;
		this.SharkBreedTime = SharkBreedTime;
		this.SharkStarveTime = SharkStarveTime;
		this.SharkStarve = SharkStarveTime;
		this.color = Color.red;
		this.rd = rd;
		this.breedType = breedType;
	}
	
	/**
	 * Constructor for the Shark, with a given starting position.
	 * @param sea - the Environment in which the Shark lives.
	 * @param SharkBreedTime - the age of the Shark from which it can breed.
	 * @param SharkStarveTime - the time a shark can live without eating.
	 * @param seed - the random seed.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 * @param pos - the starting position of the Shark in the Sea.
	 */
	public Shark(EnvSea sea, int SharkBreedTime, int SharkStarveTime, String breedType, Random rd, boolean trace, Position pos) {
		super(sea, rd, trace, "Shark");
		this.sea = sea;
		this.SharkAge = 0;
		this.SharkBreedTime = SharkBreedTime;
		this.SharkStarveTime = SharkStarveTime;
		this.SharkStarve = SharkStarveTime;
		this.pos = pos;
		this.color = Color.pink;
		this.rd = rd;
		this.breedType = breedType;
	}
	
	public void giveBirth(Position pos){
		sea.birthAgent("Shark", pos);
		if (this.breedType.equals("cycle")) this.SharkAge=0;
		if (trace) System.out.println("Agent;birthShark (parent:"+this);
	}
	
	public boolean isdying(){
		return SharkStarve==0;
	}
	
	public void dieStarving(){
		if (trace) System.out.println("Agent;starvation "+this+" "+SharkAge);
		sea.deleteAgent(this);
	}
	
	public void eatFish(Fish ag){
		SharkStarve=SharkStarveTime;
		if (trace) System.out.println("Agent;Meal: "+this+" eat "+ag);
		sea.deleteAgent(ag);
	}
	
	/**
	 * If possible, moves the Sharks to a neighboring cell.
	 * If there are Fishes on neighboring cell, it moves to one of this cells randomly and eat the fish.
	 * Else, if there are empty cells, it moves to one of this cells randomly.
	 * Else, it doesn't move.
	 * @return success - a boolean indicating if the Shark succeeded to move or not.
	 */
	public boolean tryToMove(){
		Position freePos = null;
		//Construct the list of all neighboring positions.
		int gridSizeX = sea.getGridSizeX();
		int gridSizeY = sea.getGridSizeY();
		ArrayList<Position> ngb = new ArrayList<Position>();
		ngb.add(this.pos.nextPosition(1, 0, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, 0, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(0, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(1, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(0, -1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(1, -1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, -1, gridSizeX, gridSizeY));
		//Randomize it
		Collections.shuffle(ngb,rd);
		for (Position n : ngb){
			//what's on the cell ?
			Agent ag = sea.cellContent(n);
			if(ag==null){
				//nothing, remember the shark can move there if there's no fish
				freePos = n;
			}else if(ag.getType()=="Fish"){
				//a fish, the shark will eat it
				eatFish((Fish) ag);
				//and move there
				return sea.moveAgent(this, n);
			}
		}
		//there was no fish
		if(freePos != null){
			//but empty cells
			return sea.moveAgent(this, freePos);
		}
		//all cells where full of sharks
		return false;
	}

	
	@Override
	/**
	 * If the Shark didn't eat for too long, it dies.
	 * Else, it tries to eat a Fish on a neighboring cell, or if there isn't, move to an empty cell.
	 * If it eats, it moves where the Fish was.
	 * If it moved and is in age to breed, it birth an other Shark on its previous position.
	 */
	public void decide() {
		if (isdying()){
			dieStarving();
		}
		else{
			Position prevPos = this.pos;
			if (tryToMove() && SharkAge>=SharkBreedTime) giveBirth(prevPos);
			SharkStarve--;
			SharkAge++;
			this.color = Color.red;
		}
	}

}
