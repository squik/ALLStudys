package wator;

import core.*;

/**
 * Environment for the Wator program.
 * It is always torus.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class EnvSea extends Environnement {
	private SMAWator sma;
	
	public EnvSea(int gridSizeX, int gridSizeY, SMAWator sma){
		super(gridSizeX, gridSizeY, true);
		this.sma = sma;
	}
	
	public boolean moveAgent(Agent ag, Position pos){
		clearCell(ag.getPosition());
		ag.setPosition(pos);
		addAgent(ag);
		return true;
	}
	
	public void clearCell(Position pos){
		matrice[pos.getX()][pos.getY()]=null;
	}
	
	public void birthAgent(String type, Position pos){
		Agent child = sma.birthAgent(type, pos);
		if (child!=null) addAgent(child);
		
	}
	
	public void deleteAgent(Agent ag){
		clearCell(ag.getPosition());
		sma.deleteAgent(ag);
	}
	
}
