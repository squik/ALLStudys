package wator;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Main{
	
	public static SMAWator readProperties() throws IOException{

		// create and load default properties
		Properties defaultProps = new Properties();
	
		defaultProps.put("gridSizeX", "15");
		defaultProps.put("gridSizeY", "15");
		defaultProps.put("nbFishes", "10");
		defaultProps.put("nbSharks", "10");
		defaultProps.put("fishBreedTime", "5");
		defaultProps.put("sharkBreedTime", "5");
		defaultProps.put("sharkStarveTime", "5");
		defaultProps.put("delay", "10");
		defaultProps.put("nbTicks", "1000");
		defaultProps.put("refresh", "1");
		defaultProps.put("seed", "0");
		defaultProps.put("canvaSizeX", "0");
		defaultProps.put("canvaSizeY", "0");
		defaultProps.put("grid", "false");
		defaultProps.put("trace", "true");
		defaultProps.put("mode", "E");
		defaultProps.put("breedType", "cycle");
		FileInputStream in = new FileInputStream("PropertiesSea");
		defaultProps.load(in);
		in.close();
	
		int nbSharks = Integer.parseInt(defaultProps.getProperty("nbSharks"));
		int nbFishes = Integer.parseInt(defaultProps.getProperty("nbFishes"));
		int fishBreedTime = Integer.parseInt(defaultProps.getProperty("fishBreedTime"));
		int sharkBreedTime = Integer.parseInt(defaultProps.getProperty("sharkBreedTime"));
		int sharkStarveTime = Integer.parseInt(defaultProps.getProperty("sharkStarveTime"));
		int gridSizeX = Integer.parseInt(defaultProps.getProperty("gridSizeX"));
		int gridSizeY = Integer.parseInt(defaultProps.getProperty("gridSizeY"));
		boolean grid = Boolean.parseBoolean(defaultProps.getProperty("grid"));
		boolean trace= Boolean.parseBoolean(defaultProps.getProperty("trace"));
		int canvaSizeX = Integer.parseInt(defaultProps.getProperty("canvaSizeX"));
		int canvaSizeY = Integer.parseInt(defaultProps.getProperty("canvaSizeY"));
		int delay = Integer.parseInt(defaultProps.getProperty("delay"));
		int nbTicks = Integer.parseInt(defaultProps.getProperty("nbTicks"));
		int refresh = Integer.parseInt(defaultProps.getProperty("refresh"));
		int seed = Integer.parseInt(defaultProps.getProperty("seed"));
		
		// create the multi-agent system
	    return new SMAWator(nbSharks, nbFishes,
	    		fishBreedTime, sharkBreedTime, sharkStarveTime,
	    		defaultProps.getProperty("breedType"), gridSizeX, gridSizeY,
	    		grid, canvaSizeX, canvaSizeY,
	    		delay, nbTicks, refresh,
				seed, trace, defaultProps.getProperty("mode"));
	}	
	
	public static void main(String[] args){
		SMAWator sma=null;
		try {
			sma = readProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}