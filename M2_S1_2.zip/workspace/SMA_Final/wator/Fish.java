package wator;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.*;

/**
 * A Fish is randomly moving in a Sea. It can birth other Fishes and get eaten by Sharks.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class Fish extends Agent {

	private int FishBreedTime;
	private int FishAge;
	private EnvSea sea;
	private Random rd;
	private String breedType;

	/**
	 * Constructor for the Fish.
	 * The Fish will be put at a random free position in its Sea.
	 * @param sea - the Environment in which the Fish lives.
	 * @param FishBreedTime - the age of the Fish from which it can breed.
	 * @param seed - the random seed.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 */
	public Fish(EnvSea sea,int FishBreedTime, String breedType, Random rd, boolean trace) {
		super(sea, rd, trace, "Fish");
		this.sea = (EnvSea) sea;
		this.FishAge = 0;
		this.FishBreedTime = FishBreedTime;
		this.color = Color.blue;
		this.rd = rd;
		this.breedType = breedType;
	}
	
	/**
	 * Constructor for the Fish, with a given starting position.
	 * @param sea - the Environment in which the Fish lives.
	 * @param FishBreedTime - the age of the Fish from which it can breed.
	 * @param seed - the random seed.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 * @param pos - the starting position of the Fish in the Sea.
	 */
	public Fish(EnvSea sea, int FishBreedTime, String breedType, Random rd, boolean trace, Position pos) {
		super(sea, rd, trace, "Fish");
		this.sea = (EnvSea) sea;
		this.FishAge = 0;
		this.FishBreedTime = FishBreedTime;
		this.pos = pos;
		this.color = Color.green;
		this.rd = rd;
		this.breedType = breedType;
	}
	
	public void giveBirth(Position pos){
		sea.birthAgent("Fish", pos);
		if (this.breedType.equals("cycle")) this.FishAge=0;
		if (trace) System.out.println("Agent;birthFish ");
	}

	/**
	 * Move the Fish to a random neighboring free cell.
	 * If no neighboring cell is empty, the Fish doesn't move.
	 * @return success - a boolean indicating if the Fish succeeded to move or not.
	 */
	public boolean tryToMove(){
		//Construct the list of all neighboring positions.
		int gridSizeX = sea.getGridSizeX();
		int gridSizeY = sea.getGridSizeY();
		ArrayList<Position> ngb = new ArrayList<Position>();
		ngb.add(this.pos.nextPosition(1, 0, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, 0, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(0, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(1, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, 1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(0, -1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(1, -1, gridSizeX, gridSizeY));
		ngb.add(this.pos.nextPosition(-1, -1, gridSizeX, gridSizeY));
		//Randomize it
		Collections.shuffle(ngb,rd);
		for (Position n:ngb){
			if(sea.cellContent(n) ==null){
				//Move to first empty cell.
				return sea.moveAgent(this, n);
			}
		}
		//No cell is empty, don't move.
		return false;
	}
	
	@Override
	/**
	 * The Fish moves to an random empty neighboring position.
	 * If it moved and is in age to breed, it birth an other Fish on its previous position.
	 */
	public void decide() {
		Position prevPos = this.pos;
		if (tryToMove() && FishAge>=FishBreedTime) giveBirth(prevPos);
		FishAge++;
		this.color = Color.blue;
	}

}
