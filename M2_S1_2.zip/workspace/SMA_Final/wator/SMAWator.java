package wator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.*;

public class SMAWator extends SMA {

	private int nbSharks;
	private int nbFishes;
	private ArrayList<Agent> animals;
	private int fishBreedTime;
	private int sharkBreedTime;
	private int sharkStarveTime;
	private Vue vue;
	private EnvSea sea;
	private Random rd;
	private String breedType;
	
	public SMAWator(int nbSharks, int nbFishes,
			int fishBreedTime, int sharkBreedTime, int sharkStarveTime,
			String breedType, int gridSizeX, int gridSizeY,
			boolean grid, int canvaSizeX, int canvaSizeY,
			int delay, int nbTicks, int refresh,
			int seed, boolean trace, String mode){
		
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.nbFishes = nbFishes;
		this.nbSharks = nbSharks;
		this.sea = new EnvSea (gridSizeX, gridSizeY, this);
		this.animals = new ArrayList<Agent>();
		this.fishBreedTime = fishBreedTime;
		this.sharkBreedTime = sharkBreedTime;
		this.sharkStarveTime = sharkStarveTime;
		this.breedType = breedType;
		Random rd = new Random();
		if (seed != 0) rd = new Random(seed);
		this.rd = rd;
		
		for (int i = 0; i < nbSharks; i++){
			Shark ag = new Shark(sea, sharkBreedTime, sharkStarveTime, breedType, rd, trace);
			animals.add(ag);
			sea.addAgent(ag);
		}
		for (int i = 0; i < nbFishes; i++){
			Fish ag = new Fish(sea, fishBreedTime, breedType, rd, trace);
			animals.add(ag);
			sea.addAgent(ag);
		}

		this.vue = new Vue(animals, gridSizeX, gridSizeY, canvaSizeX, canvaSizeY, grid);
	}
	
	public void run() {
		    
			Random rnd = null;
			if (seed==0) rnd = new Random();
			else rnd = new Random(seed);
			
			int step = 0;
			FileOutputStream fos = null;
		    try {
		    	fos = new FileOutputStream(new File("plot/donnéesFishShark.txt"));
		    	vue.repaint();
		    	
		    	// the program run until a specified number of Tick or the death of all sharks
				while (step < nbTicks && nbSharks>0) {
					ArrayList<Agent> copylist = new ArrayList<Agent>(animals);
					
					// Run once
					if (this.mode == "A"){
						// one random animal each turn
						int choice = (int) (Math.random()* copylist.size());
						copylist.get(choice).decide();
					}else {
						// all the animals, in the same order or in different order each turn ("E")
						if(this.mode == "E") Collections.shuffle(copylist, rnd);
						for (Agent ag : copylist){
							// check if the fish wasn't eaten by a shark earlier in the turn
							if (animals.contains(ag)) ag.decide();
						}
					}
					
					// Print
					if (step % refresh == 0) vue.repaint();
					
					step += 1;

					// Save the number of fishes and sharks in an other file to plot
			        String ecrire = step +" "+nbSharks+" "+nbFishes+"\n";
			        fos.write(ecrire.getBytes());
			        
			        // Write the trace
			        if (trace) System.out.println("Tick;"+step+" nbSharks:"+nbSharks+" nbFishes:"+nbFishes + " nbAnimals:"+animals.size());
			        
			        // Sleep until next turn
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			    }
				System.out.println("nbSharks: "+nbSharks+"; nbFishes: "+nbFishes+"; Total: "+(nbFishes+nbSharks));
				System.out.println("Sea: "+sea.getGridSizeX()+"x"+sea.getGridSizeY()+"="+sea.getGridSizeX()*sea.getGridSizeY());
				if (nbSharks==0){
					System.out.println("RIP les requins !");
				}
				fos.close();
		    }catch (IOException e){} 
	}

	public Agent birthAgent(String type, Position pos){
		Agent child = null;
		if (type=="Shark") {
			child = new Shark(sea, sharkBreedTime, sharkStarveTime, breedType, rd, trace, pos);
			nbSharks++;
			animals.add(child);
		}
		else if (type=="Fish") {
			child = new Fish(sea, fishBreedTime, breedType, rd, trace, pos);
			nbFishes++;
			animals.add(child);
		}
		return child;
	}
	
	public void deleteAgent(Agent ag){
		if (ag.getType()=="Shark") 
			nbSharks--;
		else if (ag.getType()=="Fish")
			nbFishes--;
		animals.remove(ag);
	}
	
	public boolean existingAgent(Agent ag){
		return animals.contains(ag);
	}
	public ArrayList<Agent> getAnimals(){
		return animals;
	}
}
