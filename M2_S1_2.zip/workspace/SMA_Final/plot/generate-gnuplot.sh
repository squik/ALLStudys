#!/bin/bash

if [ $# -ne 1 ]
then
	echo "usage : ./generate-gnuplot.sh output.png"
	exit -1
fi

gnuplot <<EOF
set title  'population de la mer'
set xlabel 'ticks'
set ylabel 'Agent'

set palette defined (1 "black")

set terminal png
set output '$1'
plot "donnéesFishShark.txt" using 1:3 title "Fish" with line, "donnéesFishShark.txt" using 1:2 title "Shark" with line
EOF
