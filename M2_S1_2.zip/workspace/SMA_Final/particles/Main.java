package particles;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Main{

	public static SMABilles readProperties() throws IOException{
		
		// create and load default properties
		Properties defaultProps = new Properties();
	
		defaultProps.put("gridSizeX", "40");
		defaultProps.put("gridSizeY", "40");
		defaultProps.put("torus", "false");
		defaultProps.put("nbParticles", "1200");
		defaultProps.put("delay", "1500");
		defaultProps.put("nbTicks", "100");
		defaultProps.put("refresh", "1");
		defaultProps.put("seed", "0");
		defaultProps.put("canvaSizeX", "600");
		defaultProps.put("canvaSizeY", "600");
		defaultProps.put("grid", "false");
		defaultProps.put("trace", "true");
		defaultProps.put("mode", "E");
		FileInputStream in = new FileInputStream("PropertiesParticles");
		defaultProps.load(in);
		in.close();
	
		int nbParticles = Integer.parseInt(defaultProps.getProperty("nbParticles"));
		int gridSizeX = Integer.parseInt(defaultProps.getProperty("gridSizeX"));
		int gridSizeY = Integer.parseInt(defaultProps.getProperty("gridSizeX"));
		int delay = Integer.parseInt(defaultProps.getProperty("delay"));
		int nbTicks = Integer.parseInt(defaultProps.getProperty("nbTicks"));
		int refresh = Integer.parseInt(defaultProps.getProperty("refresh"));
		boolean grid = Boolean.parseBoolean(defaultProps.getProperty("grid"));
		int canvaSizeX = Integer.parseInt(defaultProps.getProperty("canvaSizeX"));
		int canvaSizeY = Integer.parseInt(defaultProps.getProperty("canvaSizeY"));
		int seed = Integer.parseInt(defaultProps.getProperty("seed"));
		boolean torus = Boolean.parseBoolean(defaultProps.getProperty("torus"));
		String mode = "E";
		boolean trace = Boolean.parseBoolean(defaultProps.getProperty("trace"));
		
		// create the multi-agent system
	    return new SMABilles(gridSizeX, gridSizeY,
	    		torus, nbParticles,
	    		delay, nbTicks, refresh, 
	    		seed, canvaSizeX, canvaSizeY, 
	    		grid,  trace, mode);
	}	
	
	public static void main(String[] args){
		SMABilles sma=null;
		try {
			sma = readProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}