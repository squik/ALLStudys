package particles;

import core.*;
/**
 * Environment for the Particles program.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class EnvParticles extends Environnement{

	public EnvParticles(int gridSizeX, int gridSizeY, boolean torus){
		super(gridSizeX, gridSizeY, torus);
	}
	
	public void moveAgent(Particle ag){
		Position prevPos = ag.getPosition();
		Position nextPos = prevPos.nextPosition(ag.getPasX(), ag.getPasY(), gridSizeX, gridSizeY);
		ag.setPosition(nextPos);
		matrice[nextPos.getX()][nextPos.getY()]=matrice[prevPos.getX()][prevPos.getY()];
		matrice[prevPos.getX()][prevPos.getY()]=null;
	}
	
	public int nombreCollision(){
		int cpt =0 ;
		for (int x = 0;x<this.gridSizeX;x++){
			for(int y=0;y<this.gridSizeY;y++){
				Particle ag =(Particle) matrice[x][y];
				if(ag !=null){
					cpt +=ag.getNbCol();					
				}
			}
		}
		return cpt;
	}
}