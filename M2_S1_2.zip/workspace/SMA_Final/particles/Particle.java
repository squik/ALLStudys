package particles;

import java.awt.Color;
import java.util.Random;
import core.*;

/**
 * A particle goes straight forward until it collisions something.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 */
public class Particle extends Agent{
	
	private int nbCol;
	private String name;
	private int pasX;
	private int pasY;
	private EnvParticles env;
	
	/**
	 * Constructor of the particles.
	 * @param env - the environment in which the particles lives.
	 * @param rd - a Random instance.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 */
	public Particle(EnvParticles env, Random rd, boolean trace){
		super(env, rd, trace, "Particle");
		this.name = "P"+this.pos;
		this.nbCol = 0;
		this.color = Color.gray;
		this.env = (EnvParticles) env;
		
		//initializes a random direction
		this.pasX = rd.nextInt(3)-1;
		if (pasX == 0){
			int[] choices = {-1,1};
			this.pasY = choices[rd.nextInt(2)];
		}
		else this.pasY = rd.nextInt(3)-1;
	}
	
	/**
	 * If there's nothing in front of it, the particle makes one step forward. 
	 * Else, it changes direction and becomes red.
	 */
	public void decide(){
		boolean collision = false;
		// comportement avec la collision d'un mur 
		if (env.isBorderX(this.pos.getX()+this.pasX)){
			this.collision();
			this.pasX *= -1;
			collision = true;
		}
		if (env.isBorderY(this.pos.getY()+this.pasY)){
			this.collision();
			this.pasY *= -1;
			collision = true;
		}
		if (collision) return;
		
		Position nextPos = this.pos.nextPosition(this.pasX, this.pasY, env.getGridSizeX(), env.getGridSizeY());
		Particle ag = (Particle) env.cellContent(nextPos);
		if  (ag != null) meetAgent(ag);
		else env.moveAgent(this);
		return;
	}
	
	/**
	 * Handles the global changes when a collision occurs.
	 * (Doesn't handle the change in direction since that depends on the collision).
	 */
	public void collision(){
		if (trace) System.out.println("Agent;"+this.name+";direction;"+this.pasX+";"+this.pasY+";position;"+this.pos+";"+this.nbCol);
		this.nbCol+=1;
		this.color=Color.red;
	}
	public int getNbCol(){
		return this.nbCol;
	}
	/**
	 * Handles the collision with an other particle.
	 * @param ag - the other particle involved in the collision
	 */
	public void meetAgent(Particle ag){
		this.collision();
		ag.collision();
		
		// comportement1 quand on entre en collision avec un agent 
		
		//this.inverseDirections();
		//ag.inverseDirections();
		
		// comportement2 
		
		int px = this.pasX;
		int py = this.pasY;
		this.setDirections(ag.pasX,ag.pasY);
		ag.setDirections(px,py);		
		
	}
	
	/**
	 * The name is generated with the starting position.
	 */
	public String getName(){
		return this.name;
	}
	
	/**
	 * One of the possible behavior when meeting an agent:
	 * changing the direction by going backwards.
	 */
	public void inverseDirections(){
		this.pasX *= -1;
		this.pasY *= -1;
	}
	
	public void setDirections(int x,int y){
		this.pasX = x;
		this.pasY = y;
	}

	public int getPasX(){
		return pasX;
	}
	
	public int getPasY(){
		return pasY;
	}
	
}