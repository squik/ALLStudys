package particles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.*;

public class SMABilles extends SMA{
	
	private ArrayList<Agent> particles;
	private Vue vue;
	
	public SMABilles(int gridSizeX, int gridSizeY, boolean torus, int nbAgent, int delay,
			int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY,
			boolean grid, boolean trace,String mode) {
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.particles = new ArrayList<Agent>(nbAgent);
		EnvParticles env = new EnvParticles (gridSizeX, gridSizeY, torus);
		Random rd = new Random();
		if (seed != 0) rd = new Random(seed);
		for (int i = 0; i < nbAgent; i++){
			Particle ag = new Particle(env, rd, trace);
			env.addAgent(ag);
			particles.add(ag);
		}
		this.env = env;
		this.vue = new Vue(particles, gridSizeX, gridSizeY, canvaSizeX, canvaSizeY, grid);
	}
	
	
	public void run() {
		FileOutputStream f =null;
		
		try {
			f= new FileOutputStream(new File("X40Y40B100.txt"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Random rnd = new Random();
		if (seed!=0) rnd = new Random(seed);
		int step = 0;
		
		while (step < nbTicks) {
			
			if (this.mode == "A"){
				int choice = (int) (Math.random()* particles.size());
				particles.get(choice).decide();
			}else {
				if(this.mode == "E") Collections.shuffle(particles, rnd);
				
				for (Agent rd : particles){
					rd.decide();
				}
			}
			
			if (step % refresh == 0) {
				vue.repaint();
			}
			step += 1;
			EnvParticles interm =(EnvParticles) env;
			if (trace) System.out.println("Tick;"+step);
			try {
				f.write((step+" "+interm.nombreCollision()+"\n").getBytes());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}