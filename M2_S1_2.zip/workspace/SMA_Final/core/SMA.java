package core;

/**
 * Abstract class for the multi-agent simulation.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public abstract class SMA {
	protected Environnement env;
	protected int delay;
	protected int nbTicks;
	protected int refresh;
	protected boolean trace;
	protected int seed;
	protected String mode;

	public SMA(int delay, int nbTicks, int refresh,
			boolean grid, int canvaSizeX, int canvaSizeY,
			int seed, boolean trace, String mode){
		this.delay = delay;
		this.nbTicks = nbTicks;
		this.refresh = refresh;
		this.seed = seed;
		this.mode = mode;
		this.trace = trace;
	}
	
	public abstract void run();
	
}
