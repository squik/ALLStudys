package core;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.JFrame;

/**
 * This class take care of the graphic interface of the program.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */

public class Vue extends JFrame implements WindowListener{
	
	private static final long serialVersionUID = 1L;
	protected ArrayList<Agent> toDraw;
	private ArrayList<Position> onScreen;
	private boolean grid;
	protected int boxSizeX;
	protected int boxSizeY;
	protected int gridSizeX;
	protected int gridSizeY;
	protected static final int spaceX = 10;
	protected static final int spaceY = 50;

	public Vue(ArrayList<Agent> agents, int gridSizeX, int gridSizeY, int canvaSizeX, int canvaSizeY, boolean grid) {
		// the argument is the window's title
	    super("SCI");
	    addWindowListener(this);
	    // set the background color
	    setBackground(Color.white);
	    this.toDraw = agents;
	    this.gridSizeX = gridSizeX;
	    this.gridSizeY = gridSizeY;
	    this.boxSizeX = canvaSizeX/gridSizeX;
    	this.boxSizeY = canvaSizeY/gridSizeY;
    	setSize(2*spaceX+canvaSizeX, spaceY+spaceX+canvaSizeY);
    	// activate the window
	    setVisible(true);
	    this.grid = grid;
	    this.onScreen = new ArrayList<Position>();
	  }

	  public void paint(Graphics g) {
		  // Draw the grid if required
		  if (grid){
			  for (int i=0; i<=gridSizeX; i++){
				  g.drawLine(spaceX+i*boxSizeX, spaceY, spaceX+i*boxSizeX, spaceY+gridSizeY*boxSizeY);
			  }
			  for (int i=0; i<=gridSizeY; i++){
				  g.drawLine(spaceX, spaceY+i*boxSizeY, spaceX+gridSizeX*boxSizeX, spaceY+i*boxSizeY);
			  }
		  }
		  // Delete the previous configuration
		  for (Position pos : onScreen) {
			  g.setColor(Color.white);
			  g.fillOval(spaceX+boxSizeX*pos.getX(),spaceY+boxSizeY*pos.getY(),boxSizeX,boxSizeY);
		  }
		  onScreen = new ArrayList<Position>();
		  // Draw the new configuration
		  for (Agent ag : toDraw) {
			  g.setColor(ag.getColor());
			  g.fillOval(spaceX+boxSizeX*ag.getPosition().getX(),spaceY+boxSizeY*ag.getPosition().getY(),boxSizeX,boxSizeY);
			  onScreen.add(ag.getPosition());
		  }
	  }


	  public void windowActivated(WindowEvent e) {}
	  
	  public void windowClosed(WindowEvent e) {}
	  
	  public void windowClosing(WindowEvent e) {
	    System.exit(0);
	  }
	  
	  public void windowDeactivated(WindowEvent e) {}
	  
	  public void windowDeiconified(WindowEvent e) {}
	  
	  public void windowIconified(WindowEvent e) {}
	  
	  public void windowOpened(WindowEvent e) {}
}