package core;

import java.util.Random;

/**
 * A Position corresponds to a x coordinate and a y coordinate in a grid.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class Position {

	private int x ;
	private int y ;
	
	/**
	 * Creates a position on given coordinates.
	 * @param x - the coordinate along the X axis.
	 * @param y - the coordinate along the Y axis.
	 */
	public Position(int x,int y){
		this.x=x;
		this.y=y;
	}
	
	/**
	 * Creates a position on random coordinates for a grid of given size.
	 * @param gridSizeX - the size of the grid along the X axis.
	 * @param gridSizeY - the size of the grid along the Y axis.
	 * @param rd - an initialized Random object.
	 */
	public Position(Random rd, int gridSizeX, int gridSizeY){
		this.x = rd.nextInt(gridSizeX);
		this.y = rd.nextInt(gridSizeY);
	}
	
	/**
	 * Return the position obtained moving toward movX and movY in the grid, considering the grid is a torus.
	 * @param movX - the direction along the X axis.
	 * @param movY - the direction along the X axis.
	 * @param gridSizeX - the size of the grid along the X axis.
	 * @param gridSizeY - the size of the grid along the Y axis.
	 */
	public Position nextPosition(int movX, int movY, int gridSizeX, int gridSizeY){
		int nextX = (this.x+movX+gridSizeX)%gridSizeX;
		int nextY = (this.y+movY+gridSizeY)%gridSizeY;
		return new Position(nextX, nextY);
	}
	
	/**
	 * Return the coordinate along the X axis.
	 * @return x
	 */
	public int getX(){
		return x;
	}		
	
	/**
	 * Return the coordinate along the Y axis.
	 * @return y
	 */
	public int getY(){
		return y;
	}
	
	@Override
	public boolean equals(Object o){
		if (o instanceof Position) {
			Position pos = (Position) o;
			return (pos.getX() == x && pos.getY() == y);
		}
		return false;
	}
	
	@Override
	public String toString(){
		return "("+x+","+y+")";
	}
}
