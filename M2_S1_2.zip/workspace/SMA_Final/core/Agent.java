package core;

import java.awt.Color;
import java.util.Random;

/**
 * The abstract class for Agents.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public abstract class Agent {
	
	protected Position pos;
	protected Color color;
	protected boolean trace;
	protected Environnement env;
	protected String type;

	public Agent(Environnement env, Random rd, boolean trace, String type){
		this.env = env;
		this.trace = trace;
		this.type = type;

		//put the Agent on a random free position
		Position newPos = new Position(rd, env.getGridSizeX(), env.getGridSizeY());
		while (env.cellContent(newPos) != null) {
			newPos = new Position(rd, env.getGridSizeX(), env.getGridSizeY());
		}
		this.pos = newPos;
	}
	
	/**
	 * Determines what the agent will do each turn.
	 * Function called by the SMA.
	 */
	public abstract void decide();
	
	public void setPosition(Position pos){
		this.pos = pos;
	}
	
	public Color getColor(){
		return color;
	}

	public Position getPosition(){
		return this.pos;
	}
	public String getType(){
		return type;
	}
}