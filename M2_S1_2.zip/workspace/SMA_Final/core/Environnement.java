package core;

/**
 * Abstract class for the Environment.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public abstract class Environnement {
	protected int gridSizeX;
	protected int gridSizeY;
	protected Agent[][] matrice;
	protected boolean torus;

	public Environnement(int gridSizeX, int gridSizeY, boolean torus){
		this.gridSizeY = gridSizeY;
		this.gridSizeX = gridSizeX;
		this.torus = torus;
		this.matrice = new Agent[gridSizeX][gridSizeY];
	}
	
	public void addAgent(Agent ag){
		matrice[ag.getPosition().getX()][ag.getPosition().getY()] = ag;
	}
	public Agent[][] getState(){
		return matrice;
	}

	public int getGridSizeY(){
		return gridSizeY;
	}
	public int getGridSizeX(){
		return gridSizeX;
	}

	public boolean isTorus(){
		return torus;
	}
	
	public boolean isBorderX(int x){
		if (torus) return false;
		return (x < 0 || x == gridSizeX);
	}
	
	public boolean isBorderY(int y){
		if (torus) return false;
		return (y < 0 || y == gridSizeY);
	}
	
	public Agent cellContent(Position pos){
		return matrice[pos.getX()][pos.getY()];
	}
	
	@Override
	public String toString(){
		String s = "";
		for (int i = 0; i<gridSizeY; i++){
			for (int j = 0; j<gridSizeX; j++){
				Agent ag = cellContent(new Position(j, i));
				if (ag==null) s+="|                    |";
				else s+="|"+ag+"|";
			}
			s+="\n";
		}
		return s;
	}
}
