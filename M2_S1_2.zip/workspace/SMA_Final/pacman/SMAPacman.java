package pacman;

import java.util.ArrayList;
import java.util.Random;

import core.*;

public class SMAPacman extends SMA{

	private boolean gameOver = false;
	private EnvPacman env;
	private ArrayList<Agent> people;
	private ArrayList<Hunter> hunters;
	private ArrayList<Wall> walls;
	private Vue vue;
	private boolean pause;
	private Random rd;
	private int percentWalls;
	private int percentDefender;
	
	public SMAPacman(int nbHunters, int percentWalls, int speedHunter, int speedAvatar,
			int percentDefender, int invincibility, boolean dijkstra,
			int delay, int nbTicks, 
			int refresh, boolean grid, int canvaSizeX, 
			int canvaSizeY, int seed,int gridSizeX, int gridSizeY, boolean torus,
			boolean trace, String mode) {
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.people = new ArrayList<Agent>();
		this.hunters = new ArrayList<Hunter>();
		this.walls = new ArrayList<Wall>();
		this.env = new EnvPacman (gridSizeX, gridSizeY, this);
		this.pause = true;
		this.percentWalls = percentWalls;
		this.percentDefender = percentDefender;
		
		this.rd = new Random();
		if(seed !=0) this.rd = new Random(seed);

		// If the game is'nt torus, we put walls around the place
		if (!torus){
			for (int i = 0; i < gridSizeX; i++){
				Wall w = new Wall(env, rd, trace, new Position(i, 0));
				env.addAgent(w);
				walls.add(w);
				w = new Wall(env, rd, trace, new Position(i, gridSizeY-1));
				env.addAgent(w);
				walls.add(w);
			}
			for (int i = 1; i < gridSizeX-1; i++){
				Wall w = new Wall(env, rd, trace, new Position(0, i));
				env.addAgent(w);
				walls.add(w);
				w = new Wall(env, rd, trace, new Position(gridSizeX-1, i));
				env.addAgent(w);
				walls.add(w);
			}
		}
		
		Avatar a = new Avatar(env, rd, trace, speedAvatar, invincibility);
		people.add(a);
		env.addAgent(a);
		
		for (int i = 0; i < nbHunters; i++){
			Hunter h = new Hunter(env, rd, trace, speedHunter);
			env.addAgent(h);
			hunters.add(h);
			people.add(h);
		}
		
		int nbWalls = (int) (gridSizeX*gridSizeY)*percentWalls/100;
		for (int i = 0; i < nbWalls; i++){
			Wall w = new Wall(env, rd, trace);
			env.addAgent(w);
			walls.add(w);
		}
		
		this.vue = new VuePacman(people, walls, env, canvaSizeX, canvaSizeY, grid, a, dijkstra);
	}

	@Override
	public void run() {
		System.out.println("PRESS SPACE TO START");
		int step = 0;
		while (!gameOver){
			while (pause){
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			ArrayList<Agent> tmpPeople = new ArrayList<>(people);
			for (Agent player : tmpPeople){
				System.out.println(step+" : Joueur "+player+" "+player.getPosition());
				player.decide();
			}
			
			int n = rd.nextInt(100);
			if (n<percentDefender) this.addDefender();
			
			if (step % refresh == 0) vue.repaint();
			
			step += 1;

			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    }
	}

	public void gameOver(){
		System.out.println("GAME OVER");
		this.gameOver = true;
	}

	public void winGame() {
		System.out.println("YOU WIN");
		this.gameOver = true;	
	}
	
	public void switchPause(){
		this.pause = !this.pause;
	}
	
	public void addDefender(){
		Defender d = new Defender(env, rd, trace, percentWalls);
		env.addAgent(d);
		people.add(d);
	}
	
	public void addWinner(){
		Winner w= new Winner(env, rd, trace);
		env.addAgent(w);
		people.add(w);
	}
	
	public void removeAgent(Agent ag){
		people.remove(ag);
		ag=null;
	}

	public void addBait(Agent leurreman) {
		people.add(leurreman);
		
	}

	public void accelerateHunters() {
		for (Hunter h:hunters) h.accelerate();
	}
	public void decelerateHunters() {
		for (Hunter h:hunters) h.decelerate();
	}

	public void decelerate() {
		delay+=10;
	}
	public void accelerate() {
		if (delay > 10) delay-=10;
	}
}
