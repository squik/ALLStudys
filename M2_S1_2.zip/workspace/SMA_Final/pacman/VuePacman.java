package pacman;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import core.*;

/**
 * The VuePacman extends Vue to add a keyListener (the Avatar), print the walls and print the number of Defender caught.
 * It can also print the results of Dikstra algorithm.
 * 
* @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class VuePacman extends Vue {

	private Avatar a;
	private int[][] dijkstra;
	private EnvPacman env;
	private ArrayList<Wall> walls;
	
	public VuePacman(ArrayList<Agent> agents, ArrayList<Wall> walls, EnvPacman env, int canvaSizeX, int canvaSizeY, boolean grid, Avatar a, boolean dijkstra) {
		super(agents, env.getGridSizeX(), env.getGridSizeY(), canvaSizeX, canvaSizeY, grid);
		this.a = a;
		this.dijkstra = null;
		if (dijkstra) this.dijkstra = env.getDijkstra();
		this.addKeyListener(a);
		this.env = env;
		this.walls = walls;
	}

	@Override
	public void paint(Graphics g){
		super.paint(g);
		g.setColor(Color.black);
		g.clearRect(spaceX/2, spaceY/2-12, 12*15, 12);
		g.drawString("Nb Defender:"+env.getCountDefenderKilled(), spaceX/2, spaceY/2);
		for (Wall wall : walls){
			  g.setColor(wall.getColor());
			  g.fillRect(spaceX+boxSizeX*wall.getPosition().getX(),spaceY+boxSizeY*wall.getPosition().getY(),boxSizeX,boxSizeY);
		}
		if (dijkstra != null){
			for (int i=0; i<gridSizeX; i++){
				for (int j=0; j<gridSizeY; j++){
					g.clearRect(spaceX+i*boxSizeX+3, spaceY+j*boxSizeY+3,12, 12);
					g.setColor(Color.black);
					g.drawString(""+dijkstra[i][j], spaceX+i*boxSizeX+3, spaceY+j*boxSizeY+15);
				}
			}
		}
	}
}
