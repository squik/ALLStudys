package pacman;

import java.awt.Color;
import java.util.Random;

import core.Agent;
import core.Position;

/**
 * A Hunter move in the direction of the Avatar, except from when the Avatar is invincible. 
 * (Or when it is fooled by a bait).
 * The game stop when it catches the Avatar.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class Hunter extends Agent{

	private EnvPacman env;
	private int speed = 2;
	private int tick;
	
	public Hunter(EnvPacman env, Random rd, boolean trace, int speed) {
		super(env, rd, trace, "Hunter");
		this.env = (EnvPacman) env;
		this.color = Color.red;
		this.tick = 0;
		this.speed = speed;
	}

	@Override
	public void decide() {
		if (tick == speed){
			Position p = env.getBestPos(this);
			if (p == null) {
				return;
			}
			if (env.cellContent(p)!=null){
				System.out.println("OCCUPIED" + env.cellContent(p));
				if (env.cellContent(p).getType()=="Avatar" ){
					env.gameOver();
				}
			}
			env.moveAgent(this, p);
			tick = 0;
		}
		else tick++;
	}

	public void accelerate() {
		if (this.speed > 1) this.speed--;
	}
	public void decelerate() {
		this.speed++;
	}
	
}
