package pacman;

import java.awt.Color;
import java.util.Random;

import core.*;

/**
* A Wall doesn't do anything except for occupying the cell.
* 
* @author Marion Tommasi, Guillaume Maitrot
*/
public class Wall extends Agent{

	
	public Wall(Environnement env, Random rd, boolean trace) {
		super(env, rd, trace, "Wall");
		this.color = Color.gray;
	}

	public Wall(Environnement env, Random rd, boolean trace, Position pos) {
		super(env, rd, trace, "Wall");
		this.color = Color.gray;
		this.pos = pos;
	}

	
	@Override
	public void decide() {
		
	}

	
	
}
