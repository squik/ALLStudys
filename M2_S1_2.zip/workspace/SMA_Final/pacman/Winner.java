package pacman;

import java.awt.Color;
import java.util.Random;

import core.*;

/**
* The Winner appears when 4 Defender have been caught.
* The game stops when the Avatar catches it.
* 
* @author Marion Tommasi, Guillaume Maitrot
*/
public class Winner extends Agent{

	public Winner(EnvPacman env, Random rd, boolean trace) {
		super(env, rd, trace, "Winner");
		this.color = Color.magenta;
	}

	@Override
	public void decide() {
		
	}

}
