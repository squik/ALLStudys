package pacman;

import java.util.ArrayList;

import core.*;

/**
 * Environment for the Pacman program.
 * It handles th computation for the Hunters best moves.
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 *
 */
public class EnvPacman extends Environnement{
	
	private SMAPacman sma;
	private int[][] dijkstra;
	private boolean invincibility;
	private int defenderKilled;
	
	public EnvPacman(int gridSizeX, int gridSizeY, SMAPacman sma) {
		super(gridSizeX, gridSizeY, true);
		this.sma = sma;
		this.dijkstra = new int[gridSizeX][gridSizeY];
		this.invincibility = false;
		this.defenderKilled = 0;
	}

	public void moveAgent(Agent ag, Position nextPos){
		Position prevPos = ag.getPosition();
		ag.setPosition(nextPos);
		addAgent(ag);
		matrice[prevPos.getX()][prevPos.getY()]=null;
	}
	
	public void gameOver(){
		sma.gameOver();
	}
	
	public Position getBestPos(Hunter h){
		ArrayList<Position> ngbs = getAccessibleNeighbors(h.getPosition());
		if(ngbs.isEmpty()) return null;
		
		Position best = null; 
		for (Position a : ngbs){
			if (invincibility) {
				if ( (best == null || dijkstra[best.getX()][best.getY()] < dijkstra[a.getX()][a.getY()])){
					best = a;
				}
			}
			else if ( (best == null || dijkstra[best.getX()][best.getY()] > dijkstra[a.getX()][a.getY()])){
				best = a;
			}
		}
		
		return best ;
	}
	
	public ArrayList<Position> getAllNgbs(Position pos){
		ArrayList<Position> allNgbs = new ArrayList<Position>();
		allNgbs.add(pos.nextPosition(1, 0, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(-1, 0, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(0, 1, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(1, 1, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(-1, 1, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(0, -1, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(1, -1, gridSizeX, gridSizeY));
		allNgbs.add(pos.nextPosition(-1, -1, gridSizeX, gridSizeY));
		return allNgbs;
	}
	
	public ArrayList<Position> getAccessibleNeighbors(Position pos){
		ArrayList<Position> allNgbs = getAllNgbs(pos);
		ArrayList<Position> accessibleNgbs = new ArrayList<Position>();
		for (Position ngb : allNgbs){
			if (matrice[ngb.getX()][ngb.getY()] == null || matrice[ngb.getX()][ngb.getY()].getType()=="Avatar"){
				accessibleNgbs.add(ngb);
			}	
		}
		return accessibleNgbs;
	}	

	public void addVoisins(Position pos, ArrayList<Position> voisin,int cpt){
		ArrayList<Position> allNgbs = getAllNgbs(pos);
		
		for (Position ngb : allNgbs){
			Agent ag = matrice[ngb.getX()][ngb.getY()];
			
			if (ag == null || ag.getType()!="Wall"){
				
				if(dijkstra[ngb.getX()][ngb.getY()] == -1){
					voisin.add(ngb);
					dijkstra[ngb.getX()][ngb.getY()]=cpt;
				}
			}
		}
	}
	
	public void dijkstra(Agent a){
		//initialization
		for (int i=0; i<gridSizeX; i++){
			for (int j=0; j<gridSizeY; j++){
				dijkstra[i][j] = -1;
			}
		}
		
		ArrayList<Position> neighbors = new ArrayList<Position>();
		neighbors.add(a.getPosition());
		int cpt =0;
		dijkstra[a.getPosition().getX()][a.getPosition().getY()]=cpt;
		
		while (!neighbors.isEmpty()){
			ArrayList<Position> toProcess = new ArrayList<Position>(neighbors);
			for (Position ngb : toProcess){
				addVoisins(ngb,neighbors,cpt+1);
				neighbors.remove(ngb);
			}
			cpt++;	
		}	
	}
	
	public void switchPause(){
		sma.switchPause();
	}
	
	public int[][] getDijkstra(){
		return dijkstra;
	}
	
	public void removeAgent(Agent ag){
		matrice[ag.getPosition().getX()][ag.getPosition().getY()]=null;
		sma.removeAgent(ag);
	}
	
	public void eatDefender(Agent ag){
		this.removeAgent(ag);
		this.invincibility = true;
		this.defenderKilled++;
		if (defenderKilled == 4) sma.addWinner();
	}
	
	public void endInvincibility(){
		this.invincibility = false;
	}

	public void winGame() {
		sma.winGame();
	}

	public int getCountDefenderKilled() {
		return defenderKilled;
	}

	public void addBait(Agent leurreman) {
		addAgent(leurreman);
		sma.addBait(leurreman);
	}

	public void accelerateHunters() {
		sma.accelerateHunters();
	}
	public void decelerateHunters() {
		sma.decelerateHunters();
	}

	public void decelerateSim() {
		sma.decelerate();
	}
	public void accelerateSim() {
		sma.accelerate();
	}
	
}
