package pacman;

import java.awt.Color;
import java.util.Random;

import core.*;

/**
* A bait attract the Hunters for a given time.
* @author Marion Tommasi, Guillaume Maitrot
*/
public class Bait  extends Agent{
	
	public Bait(Environnement env, Random rd, boolean trace) {
		super(env, rd, trace, "Bait");
		this.color = Color.green;
	}

	@Override
	public void decide() {
		
	}

}
