package pacman;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Main {
	
	public static SMAPacman readProperties() throws IOException{

		// create and load default properties
		Properties defaultProps = new Properties();
	
		defaultProps.put("gridSizeX", "15");
		defaultProps.put("gridSizeY", "15");
		defaultProps.put("torus", "true");
		defaultProps.put("nbHunters", "3");
		defaultProps.put("percentWalls", "10");
		defaultProps.put("percentDefender", "10");
		defaultProps.put("invincibility", "5");
		defaultProps.put("speedHunter", "2");
		defaultProps.put("speedAvatar", "1");
		defaultProps.put("dijkstra", "true");
		defaultProps.put("delay", "600");
		defaultProps.put("nbTicks", "1000000");
		defaultProps.put("refresh", "1");
		defaultProps.put("seed", "0");
		defaultProps.put("canvaSizeX", "600");
		defaultProps.put("canvaSizeY", "600");
		defaultProps.put("grid", "false");
		defaultProps.put("trace", "true");
		defaultProps.put("mode", "E");
		FileInputStream in = new FileInputStream("PropertiesPacman");
		defaultProps.load(in);
		in.close();
	
		int nbHunters = Integer.parseInt(defaultProps.getProperty("nbHunters"));
		int percentWalls = Integer.parseInt(defaultProps.getProperty("percentWalls"));
		int percentDefender = Integer.parseInt(defaultProps.getProperty("percentDefender"));
		int invincibility = Integer.parseInt(defaultProps.getProperty("invincibility"));
		int speedHunter = Integer.parseInt(defaultProps.getProperty("speedHunter"));
		int speedAvatar = Integer.parseInt(defaultProps.getProperty("speedAvatar"));
		boolean dijkstra = Boolean.parseBoolean(defaultProps.getProperty("dijkstra"));
		int gridSizeX = Integer.parseInt(defaultProps.getProperty("gridSizeX"));
		int gridSizeY = Integer.parseInt(defaultProps.getProperty("gridSizeX"));
		int delay = Integer.parseInt(defaultProps.getProperty("delay"));
		int nbTicks = Integer.parseInt(defaultProps.getProperty("nbTicks"));
		int refresh = Integer.parseInt(defaultProps.getProperty("refresh"));
		boolean grid = Boolean.parseBoolean(defaultProps.getProperty("grid"));
		int canvaSizeX = Integer.parseInt(defaultProps.getProperty("canvaSizeX"));
		int canvaSizeY = Integer.parseInt(defaultProps.getProperty("canvaSizeY"));
		int seed = Integer.parseInt(defaultProps.getProperty("seed"));
		boolean torus = Boolean.parseBoolean(defaultProps.getProperty("torus"));
		String mode = "E";
		boolean trace = Boolean.parseBoolean(defaultProps.getProperty("trace"));
		
		// create the multi-agent system
	    return new SMAPacman(nbHunters, percentWalls, speedHunter, speedAvatar, 
	    		percentDefender, invincibility, dijkstra,
	    		delay, nbTicks, refresh, 
	    		grid, canvaSizeX, canvaSizeY, 
	    		seed, gridSizeX, gridSizeY, 
	    		torus, trace, mode);
	}	
	
	public static void main(String[] args){

		SMAPacman sma=null;
		try {
			sma = readProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}
