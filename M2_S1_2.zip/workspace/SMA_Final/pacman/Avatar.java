package pacman;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import core.*;

/**
 * The Avatar listen to the player's order to move.
 * It die if a Hunter catches it. It becomes invincible for a short time when it catches a Defender.
 * After 4 Defender caught, it can catch a Winner to win the game. 
 * 
 * The keys it recognizes :
 * 		To move : Z,Q,S,D or Up, Left, Down, Right
 * 		To start or pause the game : Space
 * 		Others :
 * 			Y, U to accelerate or decelerate the Hunters
 * 			G, H to accelerate or decelerate itself
 * 			V, B to accelerate or decelerate the simulation
 * 			P to place a Bait
 * 
 * @author Marion Tommasi, Guillaume Maitrot
 */
public class Avatar extends Agent implements KeyListener{

	private int movX=0;
	private int movY=0;
	private EnvPacman env;
	private int speed;
	private int tick = 0;
	private int invincible;
	private int invincibility;

	private int cptleurre = 1;
	private boolean leurre = false;
	private Agent leurreman = null ;
	
	/**
	 * Constructor of the Avatar.
	 * @param env - the Environment in which the Avatar lives.
	 * @param rd - a Random instance.
	 * @param trace - a boolean that determines whether to print a trace of the execution or not.
	 */
	public Avatar(Environnement env, Random rd, boolean trace, int speed, int invincibility) {
		super(env, rd, trace, "Avatar");
		this.env = (EnvPacman) env;
		this.color = Color.yellow;
		this.speed = speed;
		this.invincible = 0;
		this.invincibility = invincibility;
	}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void keyPressed(KeyEvent e) {
		System.out.println("KEY PRESSED"+KeyEvent.getKeyText(e.getKeyCode()));
		switch(KeyEvent.getKeyText(e.getKeyCode())){
		case "Espace" : {
			env.switchPause();
			break;
		}
		case "Y" : {
			env.accelerateHunters();
			break;
		}
		case "U" : {
			env.decelerateHunters();
			break;
		}
		case "G" : {
			if (this.speed > 1) this.speed--;
			break;
		}
		case "H" : {
			this.speed++;
			break;
		}
		case "V" : {
			env.accelerateSim();
			break;
		}
		case "B" : {
			env.decelerateSim();
			break;
		}
		case "Q" : {
			movX = -1;
			movY = 0;
			break;
		}
		case "Gauche" : {
			movX = -1;
			movY = 0;
			break;
		}
		case "Z" : {
			movX = 0;
			movY = -1;
			break;
		}
		case "Haut" : {
			movX = 0;
			movY = -1;
			break;
		}
		case "D" : {
			movX = 1;
			movY = 0;
			break;
		}
		case "Droite" : {
			movX = 1;
			movY = 0;
			break;
		}
		case "S" : {
			movX = 0;
			movY = 1;
			break;
		}
		case "Bas" : {
			movX = 0;
			movY = 1;
			break;
		}
		case "P" : {
			leurre = true;
			cptleurre= 50;
		}
		default :break;
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void decide() {
		if (tick == speed){
			Position nextPos = pos.nextPosition(movX, movY, env.getGridSizeX(), env.getGridSizeY());
			Agent ag = env.cellContent(nextPos);
			if (ag == null){
				if (this.movX !=0 || this.movY !=0){
					env.moveAgent(this, nextPos);
				}
			}
			else if (ag.getType() == "Hunter"){
				if (invincible==0) env.gameOver();
				return;
			}
			else if (ag.getType() == "Defender"){
				env.eatDefender(ag);
				env.moveAgent(this, nextPos);
				this.invincible = invincibility;
				this.color = Color.CYAN;
			}
			else if (ag.getType() == "Winner"){
				env.winGame();
			}
			if (invincible>0){
				invincible--;
				if (invincible==0) {
					env.endInvincibility();
					this.color = Color.yellow;
				}
			}
			
			tick =-1;
		}
		tick += 1;
		if(leurre){
			
			if(cptleurre == 50){
				if(leurreman ==null){
				leurreman = new Bait(env,new Random(),trace);
				env.addBait(leurreman);
				}
			}
			
			env.dijkstra(leurreman);
			
			if(cptleurre ==1){
				env.dijkstra(this);
				env.removeAgent(leurreman);
				leurreman = null ;
				leurre = false;
				
			}
			cptleurre--;
		}else {
			
			env.dijkstra(this);}

	}
	
}
