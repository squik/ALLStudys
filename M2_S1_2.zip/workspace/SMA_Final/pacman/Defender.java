package pacman;

import java.awt.Color;
import java.util.Random;

import core.*;

/**
* A Defender appear on the map at random and stay for a short among of time. It can be caught by the Avatar.
* 
* @author Marion Tommasi, Guillaume Maitrot
*/
public class Defender extends Agent{

	private EnvPacman env;
	private int age;
	private int lifespan;
	
	public Defender(EnvPacman env, Random rd, boolean trace, int percentWall) {
		super(env, rd, trace, "Defender");
		this.color = Color.orange;
		this.age = 0;
		this.env = (EnvPacman) env;
		this.lifespan = (int) (env.getGridSizeX()+env.getGridSizeY())/2 + percentWall/40;
	}

	@Override
	public void decide() {
		if (age == lifespan){
			env.removeAgent(this);
		}
		age+=1;
	}

}