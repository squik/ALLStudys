package wator;

import core.Agent;
import core.Environnement;

public class EnvSea extends Environnement {
	private SMAWator sma;
	
	public EnvSea(int gridSizeX, int gridSizeY, boolean torus, SMAWator sma){
		super(gridSizeX, gridSizeY, torus);
		this.sma = sma;
	}
	
	
	public void moveAgent(Agent ag,int pasx,int pasy){

		int x1 = ag.getPosX();
		int y1 = ag.getPosY();
		int x2 = (pasx+x1+gridSizeX)%gridSizeX;
		int y2 = (pasy+y1+gridSizeY)%gridSizeY;
		
		
		System.out.println(" x " +x1 +" -> "+x2+" y " +y1 +" -> "+y2);
		
		if(matrice[x2][y2]!=null){
			
			
			System.out.println("\n\n\n Tu ajoute mal " +ag.getType()+" vers " +matrice[x2][y2].getType() +" \n\n\n");
		}
		
		//agent stay in the environnement
		//matrice[x2][y2]=matrice[x1][y1]; //(ag) 
		ag.setPosition(x2, y2);
		
		System.out.println("AFTERMOVE x " +x1 +" -> "+ag.getPosX()+" y " +y1 +" -> "+ag.getPosY());
		addAgent(ag);
		matrice[x1][y1]=null;
	}
	
	
	public void birthAgent(String type, int x, int y){
		Agent child = sma.birthAgent(type, x, y);
		matrice[child.getPosX()][child.getPosY()] = child;
		
	}
	
	public void deleteAgent(Agent ag){
		matrice[ag.getPosX()][ag.getPosY()]=null;
		System.out.println("delete "+ag+" "+matrice[ag.getPosX()][ag.getPosY()]);
		sma.deleteAgent(ag);
		ag = null;
		
	}
	
	public void deletePos(int x,int y){
		matrice[x][y]=null;

	}
	
	public boolean bouree(){
		boolean touva = true;
		
		for(int x =0 ; x<matrice.length;x++){
			for(int y =0 ; y<matrice[0].length;y++){
				Agent ag = matrice[x][y];
				
				if(ag != null){
					if (ag.getPosX()!=x){ touva = false;

					System.out.println("je suis bourre x "+ag+" "+x+" "+ag.getPosX());
					}
					if (ag.getPosY()!=y){ touva = false;

					System.out.println("je suis bourre y "+ag+" "+y+" "+ag.getPosY());
					}
				}
			}
		}
		
		
		return touva;
	}
	
	
}
