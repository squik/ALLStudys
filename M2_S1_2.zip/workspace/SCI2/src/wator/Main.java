package wator;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main{
	
	public static SMAWator readParameterFile(String file) throws IOException{

	    int gridSizeX=40;//40
	    int gridSizeY=40;//40
	    boolean torus=true;
	    int nbFishes=150;//150
	    int nbSharks=10;//10
	    int fishBreedTime=3;//3
	    int sharkBreedTime=12;//12
	    int sharkStarveTime=3;//3
	    int delay=15;
	    int nbTicks=1000;
	    int refresh=1;
	    int seed=0;
	    int canvaSizeX=0;
	    int canvaSizeY=0;
	    boolean grid=false;
	    boolean trace=true;
	    String mode="E";
	    
	    if (file != null){
		FileInputStream flux= new FileInputStream(file);
	    InputStreamReader lecture=new InputStreamReader(flux);
	    BufferedReader buff = new BufferedReader(lecture);
	
	    gridSizeX = Integer.valueOf(buff.readLine());
	    gridSizeY = Integer.valueOf(buff.readLine());
	    torus = Boolean.valueOf(buff.readLine());
	    nbFishes = Integer.valueOf(buff.readLine());
	    nbSharks = Integer.valueOf(buff.readLine());
	    delay = Integer.valueOf(buff.readLine());
	    nbTicks = Integer.valueOf(buff.readLine());
	    refresh = Integer.valueOf(buff.readLine());
	    seed = Integer.valueOf(buff.readLine());
	    canvaSizeX = Integer.valueOf(buff.readLine());
	    canvaSizeY = Integer.valueOf(buff.readLine());
	    grid = Boolean.valueOf(buff.readLine());
	    trace = Boolean.valueOf(buff.readLine());
	    mode = buff.readLine();
	    
	    buff.close();
	    }
	    	
		
	    return new SMAWator(nbSharks, nbFishes, 
	    		fishBreedTime, sharkBreedTime, sharkStarveTime,
	    		gridSizeX, gridSizeY,torus,
	    		grid, canvaSizeX, canvaSizeY,
	    		delay,nbTicks, refresh,
	    		seed, trace, mode);
	}	
	
	public static void main(String[] args){
		//int longueur, int largeur, boolean torus, int nbAgent, int delay, int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY, boolean grid, boolean trace, String mode

		SMAWator sma=null;
		try {
			sma = readParameterFile(null);//"/home/m2mocad/tommasi/Documents/SMA1/wator/Properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		sma.run();
	}
}