package core;


import java.awt.*;
import java.awt.event.*;
import java.io.*;

  /* La classe contient une fonction principale           */
  /* d'utilisation en tant qu'application.                */
  /* Elle etend la classe Frame pour la creation          */
  /* d'une fenetre.                                       */
  /* Elle implemente les interfaces WindowListener et     */
  /* ActionListener                                       */
  /* la gestion des evenements fenetre et action.         */

public class Vue extends Frame implements WindowListener,
											ActionListener{
	

	  /* Objets menu                                          */
	  private MenuBar mb = new MenuBar();
	  private Menu m1 = new Menu("Fichier");
	  //private MenuItem mnj = new MenuItem("Nouveau jeu");
	  private MenuItem mq = new MenuItem("Quitter");
	  /* Description du plateau de jeu                        */
	  private static Agent [][] tst;
	  private boolean grid;

	
	  /* Constructeur                                         */

	  public Vue(Environnement env, int canvaSizeX, int canvaSizeY, boolean grid) {
	  /* Appel au constructeur de la super-classe Frame       */
	  /* pour donner un titre a la fenetre                    */
	    super("Wator");
	  /* Ajout d'un ecouteur de fenetre a la fenetre          */
	  /* pour gerer les evenements fenetre                    */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface WindowListener        */
	    addWindowListener(this);
	  /* Ajout d'un ecouteur de souris a la fenetre           */
	  /* pour gerer les evenements souris                     */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface MouseListener         */
	  /* Ajout d'une barre de menu a la fenetre               */
	    setMenuBar(mb);
	  /* Ajout des menus a la barre de menu                   */
	    mb.add(m1);
	    m1.addSeparator();
	    m1.add(mq);
	  /* Ajout d'un ecouteur d'action aux menus idoines       */
	  /* pour gerer leurs evenements d'activation             */
	  /* L'ecouteur est l'objet Vue                           */
	  /* lui-meme qui etend l'interface ActionListener        */
	    mq.addActionListener(this);
	  /* Le blanc est la couleur de fond de la fenetre        */
	    setBackground(Color.white);
	    tst = env.getState();
	  /* Ajustement de la taille de la fenetre en fonction    */
	  /* de la taille du plateau de jeu                       */
	    if (canvaSizeX == 0 && canvaSizeY == 0) {
	    	setSize(24*env.getGridSizeY()+8,24*env.getGridSizeX()+72);
	    }
	    else {
	    	setSize(canvaSizeX, canvaSizeY);
	    }
	  /* Activation de la fenetre                             */
	    setVisible(true);
	    this.grid = grid;
	  }

	  /* Affichage du plateau de jeu                          */

	  public void paint(Graphics g) {
	    for ( int y = 0 ; y < tst.length ; y++ ) {
	      for ( int x = 0 ; x < tst[0].length ; x++ ) {
	        if (tst[y][x]==null) {
	        	if (grid) g.drawLine(12+24*x,60+24*y,12+24*x,60+24*y);
	        }else{
	        	g.setColor(tst[y][x].getColor());
	        	g.fillOval(10+24*x,58+24*y,20,20);
	        }
	      }
	    }
	  }

	  /* Reactions aux evenements fenetre                     */

	  public void windowActivated(WindowEvent e) {
	  }
	  
	  public void windowClosed(WindowEvent e) {
	  }
	  
	  public void windowClosing(WindowEvent e) {
	  /* Interruption du programme                            */
	    System.exit(0);
	  }
	  
	  public void windowDeactivated(WindowEvent e) {
	  }
	  
	  public void windowDeiconified(WindowEvent e) {
	  }
	  
	  public void windowIconified(WindowEvent e) {
	  }
	  
	  public void windowOpened(WindowEvent e) {
	  }
	    
	  /* Reaction aux evenements action                       */

	  public void actionPerformed(ActionEvent e) {
	  /* Si l'entree de menu "Quitter" est utilisee           */
	    if ( e.getSource() == mq ) {
	  /* Interruption du programme                            */
	      System.exit(0); }
	  }

	  static BufferedReader flux = new BufferedReader(new InputStreamReader(System.in));

	  /* Fonction principale                                  */

	  public Agent [][] initPlateau(Environnement env) throws IOException {
		  tst = env.getState();
		  return tst;
		  
	  }
}