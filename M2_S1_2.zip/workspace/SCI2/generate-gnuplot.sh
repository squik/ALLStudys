#!/bin/bash

if [ $# -ne 7 ]
then
	echo "usage : ./generate-gnuplot.sh titre nameX nameY output.png numberx numbery datafile"
	exit -1
fi

gnuplot <<EOF
set title  '$1'
set xlabel '$2'
set ylabel '$3'

set palette defined (1 "black")

set terminal png
set output '$4'
plot "$7" using $5:$6 with line 
EOF
