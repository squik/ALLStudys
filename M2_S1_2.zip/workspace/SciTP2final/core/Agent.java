package core;

import java.awt.Color;
import java.util.Random;


public abstract class Agent {
	
	protected int posx;
	protected int posy;
	protected Color color;
	protected boolean trace;
	protected Environnement env;
	protected String type;

	public Agent(Environnement env, int seed, boolean trace, String type){
		this.env = env;

		Random rd = null;
		if (seed == 0) {
			rd = new Random();
		}
		else {
			rd = new Random(seed);
		}
		boolean stop =true;
		while (stop) {
			int x = rd.nextInt(env.getGridSizeX());
			int y = rd.nextInt(env.getGridSizeY());
			if( env.cellContent(x,y) == null) {
				this.posx = x;
				this.posy = y;
				stop = false;
			}
		}
		this.trace = trace;
		this.type = type;
	}
	
	public abstract void decide();


	
	public void setPosition(int x, int y){
		this.posx = x;
		this.posy = y;
	}
	
	
	public Color getColor(){
		return color;
	}

	public int getPosX(){
		return posx;
	}
	
	public int getPosY(){
		return posy;
	}

	public String getType(){
		return type;
	}
	
}
