package core;


public abstract class Environnement {
	protected int gridSizeX;
	protected int gridSizeY;
	protected Agent[][] matrice;
	protected boolean torus;

	public Environnement(int gridSizeX, int gridSizeY, boolean torus){
		this.gridSizeY = gridSizeY;
		this.gridSizeX = gridSizeX;
		this.torus = torus;
		this.matrice = new Agent[gridSizeX][gridSizeY];
	}
	
	public void addAgent(Agent ag){
		matrice[ag.getPosX()][ag.getPosY()] = ag;
	}
	public Agent[][] getState(){
		return matrice;
	}

	public int getGridSizeY(){
		return gridSizeY;
	}
	public int getGridSizeX(){
		return gridSizeX;
	}

	public boolean isTorus(){
		return torus;
	}
	
	public boolean isBorderX(int x){
		if (torus) return false;
		return (x < 0 || x == gridSizeX);
	}
	
	public boolean isBorderY(int y){
		if (torus) return false;
		return (y < 0 || y == gridSizeY);
	}
	
	public Agent cellContent(int x, int y){
		return matrice[x][y];
	}
	
	
}
