package wator;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Agent;
import core.Environnement;

public class AgentShark extends Agent{

	private int SharkBreedTime;
	private int SharkStarveTime;
	private int SharkAge;
	private int SharkStarve;
	private EnvSea env;
	private Random rnd;

	public AgentShark(Environnement env, int SharkBreedTime, int SharkStarveTime, int seed, boolean trace) {
		super(env, seed, trace, "Shark");
		this.env = (EnvSea) env;
		this.SharkAge = 0;
		if (seed==0) this.rnd = new Random();
		else this.rnd = new Random(seed);
		this.SharkBreedTime = SharkBreedTime;
		this.SharkStarveTime = SharkStarveTime;
		this.SharkStarve = SharkStarveTime;
		this.color = Color.red;
	}
	public AgentShark(Environnement env, int SharkBreedTime, int SharkStarveTime, int seed, boolean trace, int x, int y) {
		super(env, seed, trace, "Shark");
		this.env = (EnvSea) env;
		if (seed==0) this.rnd = new Random();
		else this.rnd = new Random(seed);
		this.SharkAge = 0;
		this.SharkBreedTime = SharkBreedTime;
		this.SharkStarveTime = SharkStarveTime;
		this.SharkStarve = SharkStarveTime;
		this.posx = x;
		this.posy = y;
		this.color = Color.pink;
	}
	
	public void giveBirth(int x, int y){
		env.birthAgent("Shark", x, y);
		if (trace) System.out.println("Agent;birthShark");
	}
	
	public boolean isdying(){
		return SharkStarve==0;
	}
	
	public void dieStarving(){
		env.deleteAgent(this);
		if (trace) System.out.println("Agent;starvation "+SharkAge);
	}
	
	public void eatFish(AgentFish ag){
		SharkStarve=SharkStarveTime;
		if (trace) System.out.println("Agent;Meal ");
		env.deleteAgent(ag);
	}
	
	public boolean tryToMove(){
		int choixLastX = 42;
		int choixLastY = 42;
		int depX = 42;
		int depY = 42;
		
		//pick a random direction
		ArrayList<Integer> ngb = new ArrayList<Integer>();
		for (int i = 0; i<8; i++) ngb.add(i);
		Collections.shuffle(ngb,rnd);
		for (int ng : ngb){
			switch (ng) {			
			case 0:
				depX = -1;
				depY = -1;
				break;
			case 1:
				depX = -1;
				depY = 0;
				break;
			case 2:
				depX = -1;
				depY = 1;
				break;
			case 3:
				depX = 0;
				depY = -1;
				break;
			case 4:
				depX = 0;
				depY = 1;
				break;
			case 5:
				depX = 1;
				depY = -1;
				break;
			case 6:
				depX = 1;
				depY = 0;
				break;
			case 7:
				depX = 1;
				depY = 1;
				break;
				
			default:
				break;
			}	
			
			//what's on the cell ?
			int gridSizeX = env.getGridSizeX();
			int gridSizeY = env.getGridSizeY();
			Agent ag = env.cellContent((posx+depX+gridSizeX)%gridSizeX,
									   (posy+depY+gridSizeY)%gridSizeY);
			if(ag==null){
				//nothing, the shark can move there
				choixLastY = depY;
				choixLastX = depX;				
				
			}else if(ag.getType()=="Fish"){
				//a fish, the shark will eat it
				eatFish((AgentFish) ag);
				//and move there
				return env.moveAgent(this, depX, depY);
			}
		}
		
		if(choixLastY != 42){
			//if the shark didn't see fish but empty cells
			return env.moveAgent(this, choixLastX, choixLastY);
		}
		//if all cells where full of sharks
		return false;
	}

	
	@Override
	public void decide() {
		
		if (isdying()){
			dieStarving();
		}
		else{
			int posOriginalx = this.posx;
			int posOriginaly = this.posy; 
			if (tryToMove() && SharkAge>=SharkBreedTime) giveBirth(posOriginalx, posOriginaly);
			SharkStarve--;
			SharkAge++;
			this.color = Color.red;
		}
	}

}
