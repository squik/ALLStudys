package wator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Agent;
import core.SMA;
import core.Vue;

public class SMAWator extends SMA {

	private int nbSharks;
	private int nbFishes;
	private ArrayList<Agent> animals;
	private int fishBreedTime;
	private int sharkBreedTime;
	private int sharkStarveTime;
	private Vue vue;
	
	public SMAWator(int nbSharks, int nbFishes,
			int fishBreedTime, int sharkBreedTime, int sharkStarveTime,
			int gridSizeX, int gridSizeY, boolean torus,
			boolean grid, int canvaSizeX, int canvaSizeY,
			int delay, int nbTicks, int refresh,
			int seed, boolean trace, String mode){
		
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.nbFishes = nbFishes;
		this.nbSharks = nbSharks;
		this.env = new EnvSea (gridSizeX, gridSizeY, torus, this);
		this.animals = new ArrayList<Agent>();
		this.fishBreedTime = fishBreedTime;
		this.sharkBreedTime = sharkBreedTime;
		this.sharkStarveTime = sharkStarveTime;
		
		for (int i = 0; i < nbSharks; i++){
			AgentShark ag = new AgentShark(env, sharkBreedTime, sharkStarveTime, seed, trace);
			env.addAgent(ag);
			animals.add(ag);
		}
		for (int i = 0; i < nbFishes; i++){
			AgentFish ag = new AgentFish(env, fishBreedTime, seed, trace);
			env.addAgent(ag);
			animals.add(ag);
		}
		this.vue = new Vue(env, canvaSizeX, canvaSizeY, grid);
	}
	
	public void run() {
		    
	        
			Random rnd = null;
			if (seed==0) rnd = new Random();
			else rnd = new Random(seed);
			
			int step = 0;
			

			FileOutputStream fos = null;

		    try {
		    	fos = new FileOutputStream(new File("plot/donnéesFishShark.txt"));
				while (step < nbTicks && nbSharks>0) {
					ArrayList<Agent> copylist = (ArrayList<Agent>) animals.clone();
					if (this.mode == "A"){
						int choix = (int) (Math.random()* copylist.size());
						copylist.get(choix).decide();
					}else {
						if(this.mode == "E") Collections.shuffle(copylist, rnd);
						for (Agent rd : copylist){
							rd.decide();
						}
					}
					try {
						vue.initPlateau(env);
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (step % refresh == 0) vue.repaint();
					step += 1;

			        String ecrire = step +" "+nbSharks +" "+nbFishes+"\n";
			        fos.write(ecrire.getBytes());
			        if (trace) System.out.println("Tick;"+step+" nbSharks:"+nbSharks+" nbFishes:"+nbFishes);

					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			    }
				if (nbSharks==0){
					System.out.println("RIP les requins !");
				}
				fos.close();
		    }catch (IOException e){} 
	}


	public Agent birthAgent(String type, int x, int y){
		Agent child = null;
		if (type=="Shark") {
			child = new AgentShark(env, sharkBreedTime, sharkStarveTime, seed, trace, x, y);
			nbSharks++;
			animals.add(child);
		}
		else if (type=="Fish") {
			child = new AgentFish(env, seed, fishBreedTime, trace, x, y);
			nbFishes++;
			animals.add(child);
		}
		return child;
	}
	
	public void deleteAgent(Agent ag){
		animals.remove(ag);
		if (ag.getType()=="Shark") nbSharks--;
		else if (ag.getType()=="Fish") nbFishes--;
	}
	
	public boolean existingAgent(Agent ag){
		return animals.contains(ag);
	}
	
}
