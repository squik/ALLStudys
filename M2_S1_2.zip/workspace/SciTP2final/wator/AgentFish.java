package wator;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Agent;
import core.Environnement;

public class AgentFish extends Agent {

	private int FishBreedTime;
	private int FishAge;
	private int seed;
	private EnvSea env;

	public AgentFish(Environnement env,int FishBreedTime, int seed, boolean trace) {
		super(env, seed, trace, "Fish");
		this.env = (EnvSea) env;
		this.FishAge =0;
		this.seed =seed;
		this.FishBreedTime=FishBreedTime;
		this.color = Color.blue;
	}
	public AgentFish(Environnement env,int FishBreedTime, int seed, boolean trace, int x, int y) {
		super(env, seed, trace, "Fish");
		this.env = (EnvSea) env;
		this.FishAge =0;
		this.seed =seed;
		this.FishBreedTime=FishBreedTime;
		this.posx = x;
		this.posy = y;
		this.color = Color.green;
	}
	
	public void giveBirth(int x, int y){
		env.birthAgent("Fish", x, y);
		if (trace) System.out.println("Agent;birthFish ");
	}

	public boolean tryToMove(){
		
		//choose a random direction
		ArrayList<Integer> ngb = new ArrayList<Integer>();
		for (int i = 0; i<8; i++) ngb.add(i);
		Random rnd = null;
		if (seed==0) rnd = new Random();
		else rnd = new Random(seed);
		Collections.shuffle(ngb,rnd);
		for (int ng : ngb){
			int depX = 42;
			int depY = 42;
			switch (ng) {			
			case 0:
				depX = -1;
				depY = -1;
				break;
			case 1:
				depX = -1;
				depY = 0;
				break;
			case 2:
				depX = -1;
				depY = 1;
				break;
			case 3:
				depX = 0;
				depY = -1;
				break;
			case 4:
				depX = 0;
				depY = 1;
				break;
			case 5:
				depX = 1;
				depY = -1;
				break;
			case 6:
				depX = 1;
				depY = 0;
				break;
			case 7:
				depX = 1;
				depY = 1;
				break;
			default:
				break;
			}
			
			int gridSizeX = env.getGridSizeX();
			int gridSizeY = env.getGridSizeY();
			if(env.cellContent((posx+depX+gridSizeX)%gridSizeX,
								(posy+depY+gridSizeY)%gridSizeY) ==null){
				//the cell is empty
				return env.moveAgent(this, depX, depY);
			}
		}
		//no cell is empty
		return false;
	}
	
	@Override
	public void decide() {
		int posOriginalx = this.posx;
		int posOriginaly = this.posy; 
		if (tryToMove() && FishAge>=FishBreedTime) giveBirth(posOriginalx, posOriginaly);
		FishAge++;
		this.color = Color.blue;
	}

}
