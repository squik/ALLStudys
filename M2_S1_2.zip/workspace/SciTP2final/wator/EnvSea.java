package wator;

import core.Agent;
import core.Environnement;

public class EnvSea extends Environnement {
	private SMAWator sma;
	
	public EnvSea(int gridSizeX, int gridSizeY, boolean torus, SMAWator sma){
		super(gridSizeX, gridSizeY, torus);
		this.sma = sma;
	}
	
	
	public boolean moveAgent(Agent ag,int pasx,int pasy){
		int x1 = ag.getPosX();
		int y1 = ag.getPosY();
		int x2 = (pasx+x1+gridSizeX)%gridSizeX;
		int y2 = (pasy+y1+gridSizeY)%gridSizeY;
		
		//agent stay in the environnement
		ag.setPosition(x2, y2);
		addAgent(ag);
		matrice[x1][y1]=null;
		return true;
	}
	
	
	public void birthAgent(String type, int x, int y){
		Agent child = sma.birthAgent(type, x, y);
		matrice[child.getPosX()][child.getPosY()] = child;
		
	}
	
	public void deleteAgent(Agent ag){
		matrice[ag.getPosX()][ag.getPosY()]=null;
		sma.deleteAgent(ag);
	}
	
	@Override
	public Agent cellContent(int x, int y){
		Agent ag = matrice[x][y];
		if (ag !=null && sma.existingAgent(ag)) return ag;
		else matrice[x][y] = null;
		return null;
	}
	
}
