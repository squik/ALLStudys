package particules;

import core.Agent;
import core.Environnement;

public class EnvBilles extends Environnement{

	public EnvBilles(int gridSizeX, int gridSizeY, boolean torus){
		super(gridSizeX, gridSizeY, torus);
	}
	
	public void moveAgent(AgentBille ag){

		int x1 = ag.getPosX();
		
		int y1 = ag.getPosY();
		int x2 = (ag.getPasX()+x1+gridSizeX)%gridSizeX;
		int y2 = (ag.getPasY()+y1+gridSizeY)%gridSizeY;
		//agent stay in the environnement
		ag.setPosition(x2, y2);
		matrice[x2][y2]=matrice[x1][y1];
		matrice[x1][y1]=null;

	}
	

}