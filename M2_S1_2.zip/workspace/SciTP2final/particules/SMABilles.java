package particules;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.SMA;
import core.Vue;

public class SMABilles extends SMA{
	
	private AgentBille[] particles;
	private Vue vue;
	
	public SMABilles(int longueur, int largeur, boolean torus, int nbAgent, int delay,
			int nbTicks, int refresh, int seed, int canvaSizeX, int canvaSizeY,
			boolean grid, boolean trace,String mode) {
		super(delay, nbTicks, refresh, grid, canvaSizeX, canvaSizeY, seed, trace, mode);
		this.particles = new AgentBille[nbAgent];
		EnvBilles env = new EnvBilles (longueur, largeur, torus);
		for (int i = 0; i < nbAgent; i++){
			AgentBille ag = new AgentBille(env, seed, trace);
			env.addAgent(ag);
			particles[i] = ag;
		}
		this.env = env;
		this.vue = new Vue(env, canvaSizeX, canvaSizeY, grid);
	}
	
	
	public void run() {
		ArrayList<Integer> rdlist = new ArrayList<Integer>();
		for (int i = 0; i < particles.length; i++){
			rdlist.add(i);
		}
		Random rnd = null;
		if (seed==0) rnd = new Random();
		else rnd = new Random(seed);
		int step = 0;
		
		while (step < nbTicks) {
			
			if (this.mode == "A"){
				int choix = (int) (Math.random()* rdlist.size());
				particles[choix].decide();
			}else {
				if(this.mode == "E") Collections.shuffle(rdlist, rnd);
				
				for (int rd : rdlist){
					particles[rd].decide();
				}
			}
			//vue.vue(env.getState());
			try {
				vue.initPlateau((EnvBilles) env);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (step % refresh == 0) {
				vue.repaint();
			}
			step += 1;
			if (trace) System.out.println("Tick;"+step);
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}