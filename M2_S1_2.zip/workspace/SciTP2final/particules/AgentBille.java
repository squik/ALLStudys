package particules;
/**
 * 
 * 
 * @author tommasi Maitrot
 */

import java.awt.Color;
import java.util.Random;

import core.Agent;

public class AgentBille extends Agent{
	
	private int nbCol;
	private String name;
	private int pasx;
	private int pasy;
	private EnvBilles env;
	
	public AgentBille(EnvBilles env, int seed, boolean trace){
		super(env, seed, trace, "Bille");
		this.name = ""+posx+"/"+posy;
		this.nbCol = 0;
		this.color = Color.gray;
		this.env = (EnvBilles) env;
		Random rd = null;
		if (seed == 0) {
			rd = new Random();
		}
		else {
			rd = new Random(seed);
		}
		this.pasx = rd.nextInt(3)-1;
		if (pasx == 0){
			int[] choices = {-1,1};
			this.pasy = choices[rd.nextInt(2)];
		}
		else this.pasy = rd.nextInt(3)-1;
	}
		
	public void decide(){
		int x2 = this.posx + this.pasx;
		int y2 = this.posy + this.pasy;
		
		boolean coll = false;
		
		
		// comportement avec la collision d'un mur 
		if (env.isBorderX(x2)){
			this.collision();
			this.pasx *= -1;
			coll = true;
		}
		if (env.isBorderY(y2)){
			this.collision();
			this.pasy *= -1;
			coll = true;
		}
		if (coll) return;
		
		
		// fin comportement 

		x2 = (x2+env.getGridSizeX())%env.getGridSizeX();
		y2 = (y2+env.getGridSizeY())%env.getGridSizeY();
		
		AgentBille ag = (AgentBille) env.cellContent(x2, y2);
		if  (ag != null){
			meetAgent(ag);
			return;
		}
		else {
			env.moveAgent(this);
		}
	}
	
	public void collision(){
		if (trace) System.out.println("Agent;"+this.name+";"+this.pasx+";"+this.pasy+";"+this.posx+";"+this.posy+";"+this.nbCol);
		this.nbCol+=1;
		this.color=Color.red;
	}
	
	public void meetAgent(AgentBille ag){
		this.collision();
		ag.collision();
		
		// comportement quand on entre en collision avec un agent 
		this.inverseDirections();
		ag.inverseDirections();
	}
	
	public String getName(){
		return this.name;
	}
	
	public void inverseDirections(){
		this.pasx *= -1;
		this.pasy *= -1;
	}

	public int getPasX(){
		return pasx;
	}
	
	public int getPasY(){
		return pasy;
	}
	
}